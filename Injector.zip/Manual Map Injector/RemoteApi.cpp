#include "RemoteApi.h"
#include <TlHelp32.h>
#include <cstring>
#include <cwchar>
#include <limits>
#include <vector>

#ifdef INJECTOR_TESTING
RemoteApiTestFault gRemoteApiTestFault = RemoteApiTestFault::None;
size_t gRemoteApiTestIndex = 0;
#define FAULT(name) (gRemoteApiTestFault == RemoteApiTestFault::name)
#define API_FAULT(name) (FAULT(name) && index == gRemoteApiTestIndex)
#else
#define FAULT(name) false
#define API_FAULT(name) false
#endif

namespace {
#ifdef _WIN64
constexpr WORD ExpectedMachine = IMAGE_FILE_MACHINE_AMD64;
#else
constexpr WORD ExpectedMachine = IMAGE_FILE_MACHINE_I386;
#endif
bool Fail(std::string& error, const char* api, const char* detail, DWORD code = ERROR_INVALID_DATA) {
	error = std::string(api) + ": " + detail + " (Win32=" + std::to_string(code) + ")";
	return false;
}
struct Snapshot {
	HANDLE value = INVALID_HANDLE_VALUE;
	~Snapshot() { if (value != INVALID_HANDLE_VALUE) CloseHandle(value); }
};
struct ModuleReference {
	HMODULE value = nullptr;
	~ModuleReference() { if (value) FreeLibrary(value); }
};
struct Image {
	HANDLE process;
	ULONG_PTR base;
	size_t size;
	bool simulateReadFailure = false;
	bool Read(size_t rva, void* data, size_t length) const {
		if (simulateReadFailure) { SetLastError(ERROR_PARTIAL_COPY); return false; }
		if (rva > size || length > size - rva || size > (std::numeric_limits<ULONG_PTR>::max)() - base) {
			SetLastError(ERROR_INVALID_DATA); return false;
		}
		SIZE_T read = 0;
		return ReadProcessMemory(process, reinterpret_cast<const void*>(base + rva), data, length, &read) && read == length;
	}
	template<class T> bool Read(size_t rva, T& data) const { return Read(rva, &data, sizeof(data)); }
	bool Headers(IMAGE_NT_HEADERS& nt) const {
		IMAGE_DOS_HEADER dos{};
		if (!Read(0, dos)) return false;
		if (dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew < static_cast<LONG>(sizeof(dos))) {
			SetLastError(ERROR_INVALID_DATA); return false;
		}
		if (!Read(static_cast<size_t>(dos.e_lfanew), nt)) return false;
		if (nt.Signature != IMAGE_NT_SIGNATURE || nt.FileHeader.Machine != ExpectedMachine ||
			nt.FileHeader.SizeOfOptionalHeader != sizeof(IMAGE_OPTIONAL_HEADER) || nt.OptionalHeader.SizeOfImage != size ||
			nt.OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR_MAGIC ||
			nt.OptionalHeader.NumberOfRvaAndSizes <= IMAGE_DIRECTORY_ENTRY_EXPORT ||
			nt.OptionalHeader.NumberOfRvaAndSizes > IMAGE_NUMBEROF_DIRECTORY_ENTRIES) {
			SetLastError(ERROR_INVALID_DATA); return false;
		}
		return true;
	}
};

bool CheckArchitecture(HANDLE process, std::string& error) {
	using Query = BOOL(WINAPI*)(HANDLE, USHORT*, USHORT*);
	HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
	if (!kernel) return Fail(error, "architecture", "kernel32.dll unavailable", GetLastError());
	auto query = reinterpret_cast<Query>(GetProcAddress(kernel, "IsWow64Process2"));
	if (FAULT(ArchitectureUnavailable)) query = nullptr;
	if (!query) return Fail(error, "architecture", "IsWow64Process2 unavailable; no ambiguous fallback", ERROR_NOT_SUPPORTED);
	USHORT host = 0, hostNative = 0, target = 0, targetNative = 0;
	if (!query(GetCurrentProcess(), &host, &hostNative) || !query(process, &target, &targetNative))
		return Fail(error, "architecture", "IsWow64Process2 failed", GetLastError());
	if (FAULT(ArchitectureMismatch)) targetNative = IMAGE_FILE_MACHINE_ARM64;
	if (hostNative != IMAGE_FILE_MACHINE_AMD64 || targetNative != IMAGE_FILE_MACHINE_AMD64 ||
		(host ? host : hostNative) != ExpectedMachine || (target ? target : targetNative) != ExpectedMachine)
		return Fail(error, "architecture", "requires matching injector/target machine on native AMD64 Windows", ERROR_NOT_SUPPORTED);
	return true;
}

bool ReadModules(DWORD pid, std::vector<MODULEENTRY32W>& modules, std::string& error) {
	Snapshot snapshot;
	for (unsigned attempt = 0; attempt < 3; ++attempt) {
		if (FAULT(SnapshotFailed)) SetLastError(ERROR_ACCESS_DENIED);
		else snapshot.value = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
		if (snapshot.value != INVALID_HANDLE_VALUE || GetLastError() != ERROR_BAD_LENGTH) break;
	}
	if (snapshot.value == INVALID_HANDLE_VALUE) return Fail(error, "modules", "CreateToolhelp32Snapshot failed", GetLastError());
	MODULEENTRY32W entry{}; entry.dwSize = sizeof(entry);
	BOOL first = Module32FirstW(snapshot.value, &entry);
	if (FAULT(EnumerationFailed)) { first = FALSE; SetLastError(ERROR_PARTIAL_COPY); }
	if (!first) return Fail(error, "modules", "Module32FirstW failed", GetLastError());
	do { modules.push_back(entry); } while (Module32NextW(snapshot.value, &entry));
	if (GetLastError() != ERROR_NO_MORE_FILES) return Fail(error, "modules", "Module32NextW failed", GetLastError());
	return true;
}

bool ExportRva(const Image& image, const IMAGE_NT_HEADERS& nt, const char* name, DWORD& rva, std::string& error) {
	const auto& directory = nt.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
	IMAGE_EXPORT_DIRECTORY exports{};
	if (!directory.VirtualAddress || directory.Size < sizeof(exports) || directory.VirtualAddress > image.size ||
		directory.Size > image.size - directory.VirtualAddress) return Fail(error, name, "invalid target export directory");
	if (!image.Read(directory.VirtualAddress, exports)) return Fail(error, name, "target export directory read failed", GetLastError());
	if (!exports.NumberOfFunctions || exports.NumberOfFunctions > image.size / sizeof(DWORD) ||
		exports.NumberOfNames > image.size / sizeof(DWORD) || exports.NumberOfNames > 65536 ||
		exports.AddressOfFunctions > image.size || size_t(exports.NumberOfFunctions) * sizeof(DWORD) > image.size - exports.AddressOfFunctions ||
		exports.AddressOfNames > image.size || size_t(exports.NumberOfNames) * sizeof(DWORD) > image.size - exports.AddressOfNames ||
		exports.AddressOfNameOrdinals > image.size || size_t(exports.NumberOfNames) * sizeof(WORD) > image.size - exports.AddressOfNameOrdinals)
		return Fail(error, name, "invalid target export arrays");
	const size_t length = std::strlen(name) + 1;
	char candidate[64]{};
	if (length > sizeof(candidate)) return Fail(error, name, "unsupported API name length");
	// PE export names are sorted lexically. A bounded binary search avoids
	// thousands of cross-process reads for each API; unsorted data fails closed.
	size_t lo = 0, hi = exports.NumberOfNames;
	while (lo < hi) {
		const size_t i = lo + (hi - lo) / 2;
		DWORD nameRva = 0;
		if (!image.Read(size_t(exports.AddressOfNames) + size_t(i) * sizeof(DWORD), nameRva) ||
			!image.Read(nameRva, candidate, length)) return Fail(error, name, "target export name read failed", GetLastError());
		const int comparison = std::memcmp(candidate, name, length);
		if (comparison < 0) { lo = i + 1; continue; }
		if (comparison > 0) { hi = i; continue; }
		WORD ordinal = 0;
		if (!image.Read(size_t(exports.AddressOfNameOrdinals) + size_t(i) * sizeof(WORD), ordinal) || ordinal >= exports.NumberOfFunctions ||
			!image.Read(size_t(exports.AddressOfFunctions) + size_t(ordinal) * sizeof(DWORD), rva) || !rva || rva >= image.size)
			return Fail(error, name, "invalid target export ordinal/address");
		return true;
	}
	return Fail(error, name, "target owning-module export unavailable", ERROR_PROC_NOT_FOUND);
}

bool CheckApi(HANDLE process, const std::vector<MODULEENTRY32W>& modules, FARPROC address, const char* name,
	size_t index, std::string& error) {
#ifndef INJECTOR_TESTING
	(void)index;
#endif
	ModuleReference owner;
	if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, reinterpret_cast<LPCWSTR>(address), &owner.value))
		return Fail(error, name, "cannot identify local address owner", GetLastError());
	wchar_t localPath[MAX_PATH]{};
	const DWORD pathLength = GetModuleFileNameW(owner.value, localPath, MAX_PATH);
	if (!pathLength || pathLength >= MAX_PATH) return Fail(error, name, "local owner path unavailable or truncated", GetLastError());
	const wchar_t* baseName = std::wcsrchr(localPath, L'\\');
	baseName = baseName ? baseName + 1 : localPath;
	if (_wcsicmp(baseName, L"kernel32.dll") && _wcsicmp(baseName, L"kernelbase.dll") && _wcsicmp(baseName, L"ntdll.dll"))
		return Fail(error, name, "unsupported local address owner", ERROR_NOT_SUPPORTED);
	MODULEENTRY32W remote{};
	bool found = false;
	for (const auto& module : modules) if (!_wcsicmp(module.szModule, baseName)) { remote = module; found = true; break; }
	if (API_FAULT(OwnerMissing)) found = false;
	if (!found) return Fail(error, name, "owning module absent from target", ERROR_MOD_NOT_FOUND);
	if (API_FAULT(PathMismatch)) remote.szExePath[0] = L'?';
	if (_wcsicmp(remote.szExePath, localPath)) return Fail(error, name, "owning module path differs");
	ULONG_PTR targetBase = reinterpret_cast<ULONG_PTR>(remote.modBaseAddr);
	if (API_FAULT(BaseMismatch)) targetBase ^= 0x10000;
	if (targetBase != reinterpret_cast<ULONG_PTR>(owner.value)) return Fail(error, name, "owning module base differs; address reuse rejected");
	const Image local{GetCurrentProcess(), reinterpret_cast<ULONG_PTR>(owner.value), remote.modBaseSize};
	const Image target{process, targetBase, remote.modBaseSize, API_FAULT(ReadFailed)};
	IMAGE_NT_HEADERS localNt{}, targetNt{};
	if (!local.Headers(localNt) || !target.Headers(targetNt)) return Fail(error, name, "owner image header read/validation failed", GetLastError());
	if (API_FAULT(IdentityMismatch)) targetNt.FileHeader.TimeDateStamp ^= 1;
	if (localNt.FileHeader.TimeDateStamp != targetNt.FileHeader.TimeDateStamp ||
		localNt.OptionalHeader.CheckSum != targetNt.OptionalHeader.CheckSum ||
		localNt.OptionalHeader.SizeOfImage != targetNt.OptionalHeader.SizeOfImage)
		return Fail(error, name, "owning module PE identity differs");
	DWORD exportRva = 0;
	const char* lookupName = API_FAULT(ExportMissing) ? "I05_MISSING_EXPORT" : name;
	if (!ExportRva(target, targetNt, lookupName, exportRva, error)) {
		if (lookupName != name) error = std::string(name) + ": " + error;
		return false;
	}
	if (API_FAULT(ExportMismatch)) exportRva ^= 0x10;
	const auto& exports = targetNt.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
	if (API_FAULT(ForwardedExport)) exportRva = exports.VirtualAddress;
	if (exportRva >= exports.VirtualAddress && size_t(exportRva) - exports.VirtualAddress < exports.Size)
		return Fail(error, name, "forwarded export in resolved owner is unsupported", ERROR_NOT_SUPPORTED);
	const ULONG_PTR pointer = reinterpret_cast<ULONG_PTR>(address);
	if (pointer < local.base || pointer - local.base != exportRva)
		return Fail(error, name, "target export RVA differs from local address");
	MEMORY_BASIC_INFORMATION memory{};
	if (!VirtualQueryEx(process, reinterpret_cast<const void*>(pointer), &memory, sizeof(memory)))
		return Fail(error, name, "target address query failed", GetLastError());
	if (API_FAULT(NotExecutable)) memory.Protect = PAGE_NOACCESS;
	const DWORD execute = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
	if (memory.State != MEM_COMMIT || memory.Type != MEM_IMAGE || memory.AllocationBase != remote.modBaseAddr ||
		(memory.Protect & (PAGE_GUARD | PAGE_NOACCESS)) || !(memory.Protect & execute))
		return Fail(error, name, "target export is not executable image memory");
	return true;
}
}

bool VerifyRemoteApis(HANDLE process, bool exceptionSupport, RemoteApiAddresses& addresses, std::string& error) {
	addresses = {}; error.clear();
	const DWORD pid = GetProcessId(process);
	if (!pid) return Fail(error, "process", "GetProcessId failed", GetLastError());
	DWORD code = 0;
	if (!GetExitCodeProcess(process, &code)) return Fail(error, "process", "GetExitCodeProcess failed", GetLastError());
	if (code != STILL_ACTIVE) return Fail(error, "process", "target has exited", ERROR_PROCESS_ABORTED);
	if (!CheckArchitecture(process, error)) return false;
	std::vector<MODULEENTRY32W> modules;
	if (!ReadModules(pid, modules, error)) return false;
	const char* names[] = {"LoadLibraryA", "GetProcAddress", "RtlAddFunctionTable", "RaiseException", "RtlPcToFileHeader"};
	FARPROC resolved[5]{};
	size_t count = 2;
#ifdef _WIN64
	if (exceptionSupport) count = 5;
#else
	(void)exceptionSupport;
#endif
	for (size_t index = 0; index < count; ++index) {
		HMODULE module = GetModuleHandleW(index == 4 ? L"ntdll.dll" : L"kernel32.dll");
		resolved[index] = module ? GetProcAddress(module, names[index]) : nullptr;
		if (API_FAULT(LocalExportMissing)) resolved[index] = nullptr;
		if (!resolved[index]) return Fail(error, names[index], "local export unavailable", ERROR_PROC_NOT_FOUND);
		if (!CheckApi(process, modules, resolved[index], names[index], index, error)) return false;
	}
	addresses = {resolved[0], resolved[1], resolved[2], resolved[3], resolved[4]};
	return true;
}
