#pragma once
#include <Windows.h>
#include <cstddef>
#include <string>

// File bytes are never executed by this validator. Caller owns a readable buffer
// of exactly size bytes and must keep it unchanged until ManualMapDll returns.
bool ValidatePeImage(const BYTE* bytes, size_t size, std::string& error);
bool ValidateMappingRequirements(const BYTE* bytes, size_t size, std::string& error);
#ifdef INJECTOR_TESTING
extern bool InjectorTestFailValidationAllocation;
#endif
