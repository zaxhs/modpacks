#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <limits>

inline bool IsAllDigits(const wchar_t* text) {
	if (!text || !*text) return false;
	for (; *text; ++text) if (*text < L'0' || *text > L'9') return false;
	return true;
}

inline bool ParseTargetPid(const wchar_t* text, DWORD& pid) {
	pid = 0;
	if (!IsAllDigits(text)) return false;
	DWORD value = 0;
	for (; *text; ++text) {
		const DWORD digit = *text - L'0';
		if (value > ((std::numeric_limits<DWORD>::max)() - digit) / 10) return false;
		value = value * 10 + digit;
	}
	if (!value) return false;
	pid = value;
	return true;
}

// The same enumerator is exercised with synthetic first/next callbacks in tests.
template<class First, class Next>
DWORD FindProcessEntry(HANDLE snapshot, const wchar_t* name, First first, Next next) {
	PROCESSENTRY32W entry{};
	entry.dwSize = sizeof(entry);
	if (snapshot == INVALID_HANDLE_VALUE || !name || !first(snapshot, &entry)) return 0;
	do {
		if (_wcsicmp(entry.szExeFile, name) == 0) return entry.th32ProcessID;
	} while (next(snapshot, &entry));
	return 0;
}

template<class First, class Next>
DWORD FindUniqueProcessEntry(HANDLE snapshot, const wchar_t* name, First first, Next next, size_t& matches) {
	matches = 0;
	PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
	if (snapshot == INVALID_HANDLE_VALUE || !name || !first(snapshot, &entry)) return 0;
	DWORD pid = 0;
	do {
		if (_wcsicmp(entry.szExeFile, name) == 0) { ++matches; pid = entry.th32ProcessID; }
	} while (next(snapshot, &entry));
	return matches == 1 ? pid : 0;
}
