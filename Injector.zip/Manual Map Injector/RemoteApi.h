#pragma once
#include <Windows.h>
#include <string>

struct RemoteApiAddresses {
	FARPROC loadLibraryA = nullptr;
	FARPROC getProcAddress = nullptr;
	FARPROC rtlAddFunctionTable = nullptr;
	FARPROC raiseException = nullptr;
	FARPROC rtlPcToFileHeader = nullptr;
};

// Verifies that the local numeric addresses denote the same direct exports in
// the target. No remote allocation, writes, or execution. Outputs stay null on
// failure. This is a point-in-time check, not a code-integrity guarantee.
bool VerifyRemoteApis(HANDLE process, bool exceptionSupport, RemoteApiAddresses& addresses, std::string& error);

#ifdef INJECTOR_TESTING
enum class RemoteApiTestFault {
	None, ArchitectureUnavailable, ArchitectureMismatch, SnapshotFailed, EnumerationFailed,
	LocalExportMissing, OwnerMissing, PathMismatch, BaseMismatch, IdentityMismatch,
	ReadFailed, ExportMissing, ExportMismatch, ForwardedExport, NotExecutable
};
extern RemoteApiTestFault gRemoteApiTestFault;
extern size_t gRemoteApiTestIndex;
#endif
