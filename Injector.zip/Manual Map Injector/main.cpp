#include "injector.h"
#include "TargetInput.h"
#include "PeValidation.h"
#include <new>
#include <climits>
#include <stdexcept>
#include <vector>

namespace {
struct ProcessHandle {
	HANDLE value = nullptr;
	~ProcessHandle() { if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value); }
};
void WindowsError(const wchar_t* operation, DWORD code) {
	wchar_t* message = nullptr;
	FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
	    nullptr, code, 0, reinterpret_cast<wchar_t*>(&message), 0, nullptr);
	printf("%ls failed: Win32 %lu (0x%lX). %ls\n", operation, code, code, message ? message : L"No system message available.");
	if (message) LocalFree(message);
}
void Usage() {
	printf("Simple Manual Map Injector - reviewed native x64 DLLs\n"
	    "Usage:\n"
	    "  Injector-x64.exe                         Interactive DLL and target selection\n"
	    "  Injector-x64.exe dll_path [PID|name]      Map into your running developer test host\n"
	    "  Injector-x64.exe --list                  List process PIDs and names (read only)\n"
	    "  Injector-x64.exe --check dll_path        Validate file/features without loading it\n"
	    "  Injector-x64.exe --help\n"
	    "TLS, load-config/CFG, language-specific exception handlers, and unload are unsupported.\n"
	    "Suspended startup (--spawn) is unsupported. No target is selected automatically.\n");
}
bool ReadSelection(const wchar_t* prompt, std::wstring& value) {
	printf("%ls", prompt); fflush(stdout);
	DWORD mode = 0;
	if (GetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), &mode)) {
	    value.clear();
	    for (;;) {
	        wchar_t buffer[512]{}; DWORD read = 0;
	        if (!ReadConsoleW(GetStdHandle(STD_INPUT_HANDLE), buffer, 511, &read, nullptr) || !read) return false;
	        value.append(buffer, read);
	        if (value.back() == L'\n') break;
	    }
	    while (!value.empty() && (value.back() == L'\n' || value.back() == L'\r')) value.pop_back();
	} else {
	    std::string input;
	    if (!std::getline(std::cin, input)) return false;
	    if (!input.empty() && input.back() == '\r') input.pop_back();
	    if (input.empty()) { value.clear(); return true; }
	    if (input.size() > INT_MAX) return false;
	    const int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, input.data(), static_cast<int>(input.size()), nullptr, 0);
	    if (!count) { printf("Input is not valid UTF-8.\n"); return false; }
	    value.resize(count);
	    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, input.data(), static_cast<int>(input.size()), value.data(), count);
	}
	const auto first = value.find_first_not_of(L" \t");
	if (first == std::wstring::npos) { value.clear(); return true; }
	value = value.substr(first, value.find_last_not_of(L" \t") - first + 1);
	if (value.size() >= 2 && value.front() == L'"' && value.back() == L'"') value = value.substr(1, value.size() - 2);
	return true;
}
int ListProcesses() {
	ProcessHandle snapshot{CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)};
	if (snapshot.value == INVALID_HANDLE_VALUE) { WindowsError(L"Process snapshot", GetLastError()); return -2; }
	PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
	if (!Process32FirstW(snapshot.value, &entry)) { WindowsError(L"Process enumeration", GetLastError()); return -2; }
	printf("PID         Process name\n");
	do { printf("%-11lu %ls\n", entry.th32ProcessID, entry.szExeFile); } while (Process32NextW(snapshot.value, &entry));
	if (GetLastError() != ERROR_NO_MORE_FILES) { WindowsError(L"Process enumeration", GetLastError()); return -2; }
	return 0;
}
DWORD ResolveTargetPid(const std::wstring& target) {
	if (IsAllDigits(target.c_str())) {
	    DWORD pid = 0;
	    if (!ParseTargetPid(target.c_str(), pid)) printf("Invalid PID: expected 1..4294967295.\n");
	    return pid;
	}
	ProcessHandle snapshot{CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)};
	if (snapshot.value == INVALID_HANDLE_VALUE) { WindowsError(L"Process snapshot", GetLastError()); return 0; }
	size_t matches = 0;
	const DWORD pid = FindUniqueProcessEntry(snapshot.value, target.c_str(), Process32FirstW, Process32NextW, matches);
	if (GetLastError() != ERROR_NO_MORE_FILES) { WindowsError(L"Process enumeration", GetLastError()); return 0; }
	if (matches > 1) printf("Multiple processes match this name. Use --list and select an explicit PID.\n");
	else if (!matches) printf("No process matches this name. Use --list or an explicit PID.\n");
	return pid;
}
int Run(int argc, wchar_t** argv) {
	if (argc == 2 && (!_wcsicmp(argv[1], L"--help") || !wcscmp(argv[1], L"/?"))) { Usage(); return 0; }
	if (argc == 2 && !_wcsicmp(argv[1], L"--list")) return ListProcesses();
	if (argc >= 2 && !_wcsicmp(argv[1], L"--spawn")) {
	    printf("Unsupported suspended startup: start your owned test host normally and select its PID. No process was launched.\n");
	    return -11;
	}
	const bool checkOnly = argc == 3 && !_wcsicmp(argv[1], L"--check");
	if ((!checkOnly && argc > 3) || (argc >= 2 && argv[1][0] == L'-' && !checkOnly)) { Usage(); return -10; }
	std::wstring dllPath = checkOnly ? argv[2] : (argc >= 2 ? argv[1] : L"");
	const bool interactive = !checkOnly && argc < 3;
	if (dllPath.empty() && (!ReadSelection(L"DLL path (blank cancels): ", dllPath) || dllPath.empty())) {
	    printf("Cancelled before opening a target process.\n"); return 0;
	}
	const DWORD attributes = GetFileAttributesW(dllPath.c_str());
	if (attributes == INVALID_FILE_ATTRIBUTES || (attributes & FILE_ATTRIBUTE_DIRECTORY)) {
	    WindowsError(L"DLL file selection", attributes == INVALID_FILE_ATTRIBUTES ? GetLastError() : ERROR_DIRECTORY); return -4;
	}
	std::ifstream file(dllPath, std::ios::binary | std::ios::ate);
	if (!file) { printf("DLL file cannot be opened for reading.\n"); return -5; }
	const auto size = file.tellg();
	if (size <= 0 || static_cast<unsigned long long>(size) > 512ull * 1024 * 1024) {
	    printf("DLL file size is invalid or exceeds 512 MiB.\n"); return -6;
	}
	std::vector<BYTE> source(static_cast<size_t>(size));
	file.seekg(0); file.read(reinterpret_cast<char*>(source.data()), size);
	if (!file || file.gcount() != size) { printf("DLL read failed or the file changed during reading.\n"); return -6; }
	std::string error;
	if (!ValidateMappingRequirements(source.data(), source.size(), error)) {
	    printf("DLL rejected: %s\n", error.c_str()); return -6;
	}
	if (checkOnly) {
	    printf("PE and supported-feature checks passed. No DLL code was executed.\n"
	        "Review source requirements and verify initialization in your controlled host before relying on compatibility.\n");
	    return 0;
	}
	std::wstring target = argc == 3 ? argv[2] : L"";
	if (interactive && (!ReadSelection(L"Target PID or unique process name (blank cancels): ", target) || target.empty())) {
	    printf("Cancelled before opening a target process.\n"); return 0;
	}
	const DWORD pid = ResolveTargetPid(target);
	if (!pid) return -1;
	printf("DLL: %ls\nTarget PID: %lu\n", dllPath.c_str(), pid);
	if (interactive) {
	    std::wstring answer;
	    if (!ReadSelection(L"Initialize this reviewed DLL in your owned test host? [y/N]: ", answer) || _wcsicmp(answer.c_str(), L"y")) {
	        printf("Cancelled before opening a target process.\n"); return 0;
	    }
	}
	constexpr DWORD access = PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ | SYNCHRONIZE;
	ProcessHandle process{OpenProcess(access, FALSE, pid)};
	if (!process.value) { WindowsError(L"OpenProcess", GetLastError()); return -2; }
	DWORD exitCode = 0;
	if (!GetExitCodeProcess(process.value, &exitCode) || exitCode != STILL_ACTIVE) {
	    printf("Target process has exited or cannot be queried.\n"); return -2;
	}
	printf("Validating target APIs and initializing DLL...\n");
	if (!ManualMapDll(process.value, source.data(), source.size())) {
	    printf("Operation failed; no success is reported. Initialization may have partially run.\n"
	        "Close your owned host before retrying; automatic rollback/unload is unavailable.\n"); return -8;
	}
	printf("DLL entry point completed successfully. Mapped storage remains until the target exits.\n");
	return 0;
}
}
int wmain(int argc, wchar_t** argv) try {
	return Run(argc, argv);
} catch (const std::bad_alloc&) {
	printf("Host memory allocation failed. Operation stopped without reporting success.\n"); return -7;
} catch (const std::length_error&) {
	printf("Host allocation size limit exceeded. Operation stopped without reporting success.\n"); return -7;
}
