#include "PeValidation.h"
#include <algorithm>
#include <cstring>
#include <limits>
#include <new>
#include <stdexcept>
#include <vector>

#ifdef INJECTOR_TESTING
bool InjectorTestFailValidationAllocation = false;
#endif

namespace {
bool Fits(size_t offset, size_t length, size_t total) {
	return offset <= total && length <= total - offset;
}
template<class T> bool Read(const BYTE* data, size_t size, size_t offset, T& out) {
	if (!Fits(offset, sizeof(T), size)) return false;
	std::memcpy(&out, data + offset, sizeof(T));
	return true;
}
bool StringAt(const std::vector<BYTE>& image, size_t offset) {
	return offset < image.size() &&
		std::memchr(image.data() + offset, 0, image.size() - offset) != nullptr;
}
}

bool ValidatePeImage(const BYTE* bytes, size_t size, std::string& error) try {
	error.clear();
	auto fail = [&](const char* why) { error = why; return false; };
	IMAGE_DOS_HEADER dos{};
	if (!bytes || !Read(bytes, size, 0, dos) || dos.e_magic != IMAGE_DOS_SIGNATURE)
		return fail("Missing or truncated DOS header");
	if (dos.e_lfanew < static_cast<LONG>(sizeof(dos))) return fail("Invalid NT header offset");
	const size_t ntOffset = static_cast<size_t>(dos.e_lfanew);
	DWORD signature = 0;
	IMAGE_FILE_HEADER file{};
	if (!Read(bytes, size, ntOffset, signature) || signature != IMAGE_NT_SIGNATURE ||
		!Fits(ntOffset, sizeof(DWORD) + sizeof(file), size) ||
		!Read(bytes, size, ntOffset + sizeof(DWORD), file)) return fail("Invalid NT signature or file header");
#ifdef _WIN64
	constexpr WORD machine = IMAGE_FILE_MACHINE_AMD64;
	constexpr WORD magic = IMAGE_NT_OPTIONAL_HDR64_MAGIC;
#else
	constexpr WORD machine = IMAGE_FILE_MACHINE_I386;
	constexpr WORD magic = IMAGE_NT_OPTIONAL_HDR32_MAGIC;
#endif
	if (file.Machine != machine || !(file.Characteristics & IMAGE_FILE_DLL))
		return fail("Expected a DLL matching the injector architecture");
	const size_t optOffset = ntOffset + sizeof(DWORD) + sizeof(file);
	IMAGE_OPTIONAL_HEADER opt{};
	if (file.SizeOfOptionalHeader != sizeof(opt) || !Read(bytes, size, optOffset, opt) || opt.Magic != magic)
		return fail("Invalid or unsupported optional header");
	if (opt.NumberOfRvaAndSizes > IMAGE_NUMBEROF_DIRECTORY_ENTRIES)
		return fail("Too many data directories");
	if (!file.NumberOfSections || file.NumberOfSections > 96) return fail("Invalid section count");
	const size_t sectionsOffset = optOffset + file.SizeOfOptionalHeader;
	const size_t sectionsSize = size_t(file.NumberOfSections) * sizeof(IMAGE_SECTION_HEADER);
	if (!Fits(sectionsOffset, sectionsSize, size) || !opt.SizeOfHeaders ||
		opt.SizeOfHeaders > size || !Fits(sectionsOffset, sectionsSize, opt.SizeOfHeaders))
		return fail("Truncated headers or section table");
	// Explicit resource limit, not a PE-format claim. Avoid attacker-sized allocations.
	if (opt.SizeOfImage < opt.SizeOfHeaders || opt.SizeOfImage > 512u * 1024u * 1024u)
		return fail("Invalid image size or image exceeds the 512 MiB diagnostic limit");
	if (!opt.SectionAlignment || !opt.FileAlignment ||
		(opt.SectionAlignment & (opt.SectionAlignment - 1)) ||
		(opt.FileAlignment & (opt.FileAlignment - 1)) || opt.SectionAlignment < opt.FileAlignment ||
		opt.SizeOfImage % opt.SectionAlignment || opt.SizeOfHeaders % opt.FileAlignment)
		return fail("Invalid PE alignment");
	if (opt.ImageBase > (std::numeric_limits<ULONG_PTR>::max)() - opt.SizeOfImage)
		return fail("Image address range overflows");
	std::vector<IMAGE_SECTION_HEADER> sections(file.NumberOfSections);
	std::memcpy(sections.data(), bytes + sectionsOffset, sectionsSize);
	size_t previousEnd = opt.SizeOfHeaders;
	bool executableEntry = opt.AddressOfEntryPoint == 0;
	for (const auto& s : sections) {
		const size_t extent = (std::max)(s.Misc.VirtualSize, s.SizeOfRawData);
		if (s.VirtualAddress < previousEnd || s.VirtualAddress % opt.SectionAlignment ||
			!Fits(s.VirtualAddress, extent, opt.SizeOfImage)) return fail("Invalid or overlapping virtual section");
		if (s.SizeOfRawData && (s.PointerToRawData < opt.SizeOfHeaders ||
			s.PointerToRawData % opt.FileAlignment || !Fits(s.PointerToRawData, s.SizeOfRawData, size)))
			return fail("Section raw data is outside the file or misaligned");
		for (const auto& other : sections) {
			if (&other == &s || !s.SizeOfRawData || !other.SizeOfRawData) continue;
			if (size_t(s.PointerToRawData) < size_t(other.PointerToRawData) + other.SizeOfRawData &&
				size_t(other.PointerToRawData) < size_t(s.PointerToRawData) + s.SizeOfRawData)
				return fail("Overlapping raw sections");
		}
		if ((s.Characteristics & IMAGE_SCN_MEM_EXECUTE) && opt.AddressOfEntryPoint >= s.VirtualAddress &&
			size_t(opt.AddressOfEntryPoint) - s.VirtualAddress < s.SizeOfRawData) executableEntry = true;
		previousEnd = size_t(s.VirtualAddress) + extent;
	}
	if (!executableEntry) return fail("Entry point is outside executable file-backed data");
#ifdef INJECTOR_TESTING
	if (InjectorTestFailValidationAllocation) throw std::bad_alloc();
#endif
	for (DWORD i = 0; i < IMAGE_NUMBEROF_DIRECTORY_ENTRIES; ++i) {
		const auto& d = opt.DataDirectory[i];
		if (i >= opt.NumberOfRvaAndSizes && (d.Size || d.VirtualAddress))
			return fail("Data beyond the declared directory count");
		if (!d.Size && !d.VirtualAddress) continue;
		if (!d.Size || !d.VirtualAddress) return fail("Incomplete data directory");
		const size_t limit = i == IMAGE_DIRECTORY_ENTRY_SECURITY ? size : opt.SizeOfImage;
		if (!Fits(d.VirtualAddress, d.Size, limit)) return fail("Data directory is out of bounds");
	}
	if (opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR].Size ||
		opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT].Size)
		return fail("CLR and delay imports are unsupported by this mapper");
	std::vector<BYTE> image;
	try { image.resize(opt.SizeOfImage); }
	catch (const std::bad_alloc&) { return fail("Cannot allocate validation image"); }
	std::memcpy(image.data(), bytes, opt.SizeOfHeaders);
	for (const auto& s : sections) if (s.SizeOfRawData)
		std::memcpy(image.data() + s.VirtualAddress, bytes + s.PointerToRawData, s.SizeOfRawData);
	auto readImage = [&](size_t rva, auto& value) { return Read(image.data(), image.size(), rva, value); };
	struct Range { size_t start, length; };
	auto overlaps = [](Range a, Range b) {
		return a.length && b.length && a.start < b.start + b.length && b.start < a.start + a.length;
	};
	std::vector<Range> relocTargets;
	std::vector<Range> immutable{{0, opt.SizeOfHeaders}};
	std::vector<Range> iatRanges;
	for (DWORD index : {DWORD(IMAGE_DIRECTORY_ENTRY_IMPORT), DWORD(IMAGE_DIRECTORY_ENTRY_BASERELOC),
		DWORD(IMAGE_DIRECTORY_ENTRY_EXCEPTION), DWORD(IMAGE_DIRECTORY_ENTRY_EXPORT)}) {
		const auto& d = opt.DataDirectory[index];
		immutable.push_back({d.VirtualAddress, d.Size});
	}
	const auto& reloc = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
	for (size_t used = 0; used < reloc.Size;) {
		IMAGE_BASE_RELOCATION block{};
		if (!Fits(used, sizeof(block), reloc.Size) || !readImage(size_t(reloc.VirtualAddress) + used, block) ||
			block.SizeOfBlock < sizeof(block) || !Fits(used, block.SizeOfBlock, reloc.Size) ||
			(block.SizeOfBlock - sizeof(block)) % sizeof(WORD)) return fail("Malformed relocation block");
		for (size_t pos = sizeof(block); pos < block.SizeOfBlock; pos += sizeof(WORD)) {
			WORD fixup = 0;
			readImage(size_t(reloc.VirtualAddress) + used + pos, fixup);
			const WORD type = fixup >> 12;
			if (type == IMAGE_REL_BASED_ABSOLUTE) continue;
#ifdef _WIN64
			if (type != IMAGE_REL_BASED_DIR64) return fail("Unsupported relocation type");
#else
			if (type != IMAGE_REL_BASED_HIGHLOW) return fail("Unsupported relocation type");
#endif
			const size_t target = size_t(block.VirtualAddress) + (fixup & 0xfff);
			if (target < opt.SizeOfHeaders || !Fits(target, sizeof(ULONG_PTR), image.size()))
				return fail("Relocation target is outside section memory");
			relocTargets.push_back({target, sizeof(ULONG_PTR)});
		}
		used += block.SizeOfBlock;
	}
	const auto& imports = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	bool importTerminated = !imports.Size;
	for (size_t used = 0; Fits(used, sizeof(IMAGE_IMPORT_DESCRIPTOR), imports.Size); used += sizeof(IMAGE_IMPORT_DESCRIPTOR)) {
		IMAGE_IMPORT_DESCRIPTOR d{};
		readImage(size_t(imports.VirtualAddress) + used, d);
		if (!d.Name) { importTerminated = true; break; }
		if (!StringAt(image, d.Name) || !d.FirstThunk) return fail("Invalid import module name or IAT");
		immutable.push_back({d.Name, std::strlen(reinterpret_cast<const char*>(image.data() + d.Name)) + 1});
		size_t source = d.OriginalFirstThunk ? d.OriginalFirstThunk : d.FirstThunk;
		size_t dest = d.FirstThunk;
		for (;;) {
			ULONG_PTR thunk = 0;
			if (!readImage(source, thunk) || !Fits(dest, sizeof(thunk), image.size()))
				return fail("Unterminated or out-of-bounds import thunk array");
			if (d.OriginalFirstThunk) immutable.push_back({source, sizeof(thunk)});
			iatRanges.push_back({dest, sizeof(thunk)});
			if (!thunk) break;
			if (!IMAGE_SNAP_BY_ORDINAL(thunk) &&
				(!Fits(thunk, sizeof(WORD) + 1, image.size()) || !StringAt(image, thunk + sizeof(WORD))))
				return fail("Invalid import function name");
			if (!IMAGE_SNAP_BY_ORDINAL(thunk)) immutable.push_back({thunk,
				sizeof(WORD) + std::strlen(reinterpret_cast<const char*>(image.data() + thunk + sizeof(WORD))) + 1});
			source += sizeof(thunk); dest += sizeof(thunk);
		}
	}
	if (!importTerminated) return fail("Unterminated import descriptor array");
	std::sort(iatRanges.begin(), iatRanges.end(), [](Range a, Range b) { return a.start < b.start; });
	for (size_t i = 1; i < iatRanges.size(); ++i)
		if (overlaps(iatRanges[i - 1], iatRanges[i])) return fail("Overlapping import address tables");
	const auto& tls = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS];
	if (tls.Size) {
		IMAGE_TLS_DIRECTORY t{};
		if (tls.Size < sizeof(t) || !readImage(tls.VirtualAddress, t)) return fail("Truncated TLS directory");
		auto vaFits = [&](ULONGLONG va, size_t length) {
			return va >= opt.ImageBase && va - opt.ImageBase <= image.size() &&
				length <= image.size() - static_cast<size_t>(va - opt.ImageBase);
		};
		if (t.EndAddressOfRawData < t.StartAddressOfRawData ||
			((t.StartAddressOfRawData || t.EndAddressOfRawData) &&
				!vaFits(t.StartAddressOfRawData, static_cast<size_t>(t.EndAddressOfRawData - t.StartAddressOfRawData))) ||
			!vaFits(t.AddressOfIndex, sizeof(DWORD))) return fail("Invalid TLS template or index");
		if (t.AddressOfCallBacks) {
			if (!vaFits(t.AddressOfCallBacks, sizeof(ULONG_PTR))) return fail("Invalid TLS callback array");
			size_t pos = static_cast<size_t>(t.AddressOfCallBacks - opt.ImageBase);
			for (;;) {
				ULONG_PTR callback = 0;
				if (!readImage(pos, callback)) return fail("Unterminated TLS callback array");
				if (!callback) break;
				if (!vaFits(callback, 1)) return fail("TLS callback is outside the image");
				pos += sizeof(callback);
			}
		}
	}
#ifdef _WIN64
	const auto& exceptions = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
	if (exceptions.Size % sizeof(RUNTIME_FUNCTION)) return fail("Partial exception table record");
	DWORD lastEnd = 0;
	for (size_t used = 0; used < exceptions.Size; used += sizeof(RUNTIME_FUNCTION)) {
		RUNTIME_FUNCTION f{};
		readImage(size_t(exceptions.VirtualAddress) + used, f);
		if (f.BeginAddress < lastEnd || f.EndAddress <= f.BeginAddress ||
			!Fits(f.BeginAddress, size_t(f.EndAddress) - f.BeginAddress, image.size()) ||
			!Fits(f.UnwindData, 4, image.size())) return fail("Invalid exception table bounds");
		lastEnd = f.EndAddress;
		DWORD visited[32]{};
		for (size_t depth = 0;; ++depth) {
			if (depth == 32 || f.UnwindData % 4) return fail("Unsupported unwind chain depth or alignment");
			for (size_t i = 0; i < depth; ++i) if (visited[i] == f.UnwindData) return fail("Cyclic unwind chain");
			visited[depth] = f.UnwindData;
			BYTE header[4]{};
			if (!Read(image.data(), image.size(), f.UnwindData, header)) return fail("Truncated unwind header");
			const BYTE flags = header[0] >> 3;
			if ((header[0] & 7) != 1 || (flags != 0 && flags != 4))
				return fail("Unsupported unwind version or language-specific exception handler (version 1/chain only)");
			const size_t codes = header[2];
			const size_t tail = (4 + codes * 2 + 3) & ~size_t(3);
			if (!Fits(f.UnwindData, tail + (flags == 4 ? sizeof(f) : 0), image.size()))
				return fail("Truncated unwind codes or chain record");
			immutable.push_back({f.UnwindData, tail + (flags == 4 ? sizeof(f) : 0)});
			for (size_t index = 0; index < codes;) {
				const BYTE* code = image.data() + f.UnwindData + 4 + index * 2;
				const BYTE op = code[1] & 15, info = code[1] >> 4;
				size_t slots = 1;
				if (op == 1) {
					if (info > 1) return fail("Invalid large unwind allocation operand");
					slots = info == 0 ? 2 : 3;
				} else if (op == 4 || op == 8) slots = 2;
				else if (op == 5 || op == 9) slots = 3;
				else if (op == 6 || op == 7 || op > 10 || (op == 3 && info) || (op == 10 && info > 1))
					return fail("Unsupported or invalid unwind opcode");
				if (code[0] > header[1] || slots > codes - index) return fail("Invalid unwind code extent");
				index += slots;
			}
			if (flags == 0) break;
			readImage(size_t(f.UnwindData) + tail, f);
			if (f.EndAddress <= f.BeginAddress || !Fits(f.BeginAddress, size_t(f.EndAddress) - f.BeginAddress, image.size()))
				return fail("Invalid chained runtime function range");
		}
	}
#endif
	for (const auto& target : relocTargets) {
		for (const auto& metadata : immutable) if (overlaps(target, metadata)) return fail("Relocation overwrites parser metadata");
		for (const auto& iat : iatRanges) if (overlaps(target, iat)) return fail("Relocation overwrites an import thunk");
	}
	for (const auto& iat : iatRanges) for (const auto& metadata : immutable)
		if (overlaps(iat, metadata)) return fail("IAT overwrites parser metadata");
	return true;
} catch (const std::bad_alloc&) {
	error = "PE validation memory allocation failed";
	return false;
} catch (const std::length_error&) {
	error = "PE validation allocation size exceeds container limits";
	return false;
}

bool ValidateMappingRequirements(const BYTE* bytes, size_t size, std::string& error) {
	if (!ValidatePeImage(bytes, size, error)) return false;
	const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(bytes);
	const auto& opt = reinterpret_cast<const IMAGE_NT_HEADERS*>(bytes + dos->e_lfanew)->OptionalHeader;
	if (opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size) error = "Unsupported TLS requirements; mapping is blocked";
	else if (opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG].Size || (opt.DllCharacteristics & IMAGE_DLLCHARACTERISTICS_GUARD_CF))
		error = "Unsupported load-config/CFG requirements; use a reviewed DLL without these features";
	else return true;
	return false;
}
