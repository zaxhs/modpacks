# Compatibility and boundaries — 2026-10-22

## Windows and PE constraints

Primary target: native Windows 10/11 on AMD64. Runtime evidence currently covers
only unelevated Windows 11 Pro 10.0.26300, build 26300, with MSVC 19.51.36260.
Windows 10, other Windows 11 builds, ARM64/emulation, protected targets, different
owners/security policies, and Win32 runtime remain unverified.

The mapper accepts DLLs matching its build architecture with the expected PE
optional-header layout, bounded aligned sections, up to 96 sections, and an image
of at most 512 MiB. The CLI also limits input files to 512 MiB. Entry RVA zero is
accepted; a nonzero entry must be in file-backed executable section data. Imported
modules/symbols must resolve. Relocation types are DIR64 for x64, HIGHLOW for
Win32, and ABSOLUTE padding. An image without relocations fails if its allocated
base differs from the preferred base; preferred-base allocation is not retried.
CLR and delay imports are rejected. The certificate directory is a file range;
certificates/signatures are not authenticated by this validator.

All TLS-bearing DLLs are rejected, including when TLSSupport=false. The old
undocumented ntdll routine, assumed loader offsets, and stack loader-entry
lifetime have not been validated. The old README's broad TLS compatibility matrix
was removed. No new pattern or undocumented replacement was introduced.

Public Windows APIs used remotely are resolved locally, then independently checked
against the target before allocation. All five relevant APIs are covered, including
RaiseException/RtlPcToFileHeader addresses embedded in support code. Actual owning
module path/base and PE identity fields must match, its named direct target export
must have the same RVA, and the address must be committed executable MEM_IMAGE
memory in that allocation. Failure produces a named diagnostic and no remote work.
See FIXES.md for the complete pointer/caller trace.

Local GetProcAddress can resolve a public forwarder to kernel32, KernelBase, or
ntdll. The final owner must expose the same name as a direct export in the target.
An additional owner forwarder, changed base/path/identity, unknown owner, missing
module/API, read/query failure, or unstable/uninitialized snapshot is rejected.
There is no remote address-rebasing or forwarder-resolution fallback. Optional
exception APIs are not required when that feature is explicitly disabled.

Architecture checks use IsWow64Process2, available according to Microsoft's
[contract](https://learn.microsoft.com/en-us/windows/win32/api/wow64apiset/nf-wow64apiset-iswow64process2)
from Windows 10 version 1709. Missing API or failed architecture query is rejected;
no older-Windows compatibility is claimed. Native ARM64 and emulated/mismatched
architectures are outside this policy. The x64 build requires native AMD64 OS and
AMD64 host/target. Win32-on-AMD64 same-I386 behavior remains runtime-unverified.

The check establishes point-in-time address/module/export consistency on a stable
developer target. It is not cryptographic code authentication, a guarantee against
concurrent module remapping/modification, or verification of all instructions an
API may execute internally. No target module pinning or process suspension is
added. Current runtime evidence remains limited to Windows 11 build 26300.

The supported DLL class is reviewed native x64 code whose initialization contract
does not require normal loader registration, DLL thread notifications, or other
unsupported loader services. File acceptance alone cannot establish these source
requirements. The x64 exception path registers RUNTIME_FUNCTION tables and retains
the existing CxxThrowException/RtlPcToFileHeader support pages. Registration is
exercised, but general C++ throwing/catching, /MT-/MD-runtime combinations, SEH
unwinding and RTTI are not verified.

Version-1 handler-free unwind records and bounded CHAININFO are accepted after
checking record/code extents, recognized opcode widths, chain alignment, cycles,
and a maximum depth of 32. IAT/relocation writes cannot overlap parsed unwind
metadata. This checks structural requirements, not all unwind semantics or code
instructions. Language-specific handler flags, unknown unwind versions/opcodes,
load-config directories or GUARD_CF are explicitly rejected before allocation.
The mapper does not supply their security-cookie/CFG/language-runtime services.
Do not disable required security/runtime features just to obtain acceptance.
TLS, CLR and delay imports remain rejected. PE validation is not a code sandbox
or Windows-loader parity; executable source must be reviewed separately.

The build uses /MD for the production Release CLI, and Debug depends on debug
runtime libraries. The Release imports include KERNEL32, MSVCP140, VCRUNTIME140,
VCRUNTIME140_1, and UCRT API sets; final dumpbin reports are saved in the audit
folder. The old ADVAPI32 token-adjustment dependency is no longer imported.

The developer Release package includes those three Microsoft x64 release CRT
DLLs (14.51.36247.0) copied unchanged from the installed VS redistributable
directory. Their app-local load paths were observed in the extracted-package
process. KERNEL32 and UCRT are supplied by Windows; no system DLL or debug CRT
is redistributed. A clean separate Windows installation was not tested. See
RELEASE_GUIDE.md and BUILD-INFO.json for deployment/provenance.

## Initialization and shutdown

The PE entrypoint receives DLL_PROCESS_ATTACH. A custom entrypoint is permissible
if the DLL itself satisfies its initialization contract; the mapper does not
automatically supply CRT startup for a DLL that deliberately bypasses it. FALSE
is a failure. Entry success proves the entrypoint returned successfully, not that
hooks, worker threads, or application features work.

Header/section metadata is preserved. The mapper does not insert the image into
the normal loader's module bookkeeping. It does not offer a verified general
unload/detach contract, reverse dependency loading, or unregister all function
tables. The tested shutdown is normal exit of the owned host process, not a DLL
detach notification. After execution, image/support pages live until target exit;
timeouts additionally retain executable scratch and parameters. A timeout is an
unknown initialization outcome and is not safe grounds for a blind retry.

The --spawn suspended-startup path is explicitly rejected without launching a
process. Start owned test hosts normally and select a PID. Existing
legacy tests contain UI, hardcoded author-specific log paths, or worker-thread
joins in DllMain; their build success does not make them appropriate unattended
runtime tests. Only the new reviewed payload was executed.

## Static Osiris assessment

Accessible binaries were read without loading them. The identified Release
candidate is `C:\Users\zacha\Documents\Projekt\Osiris-master\build\phase1-vs2026\Source\Release\Osiris.dll`.
At the final inspection it is 261632 bytes, SHA256
`520E0D4AD8CEDD4DE554539F845C3EDBF10727ACBE417A2743116EAF244A9E2D`.
This identifies the inspected file, not proof that it represents a current
reproducible source revision. No Osiris source, build configuration or DLL was
modified, rebuilt, or executed.

| Property | Verified Release metadata and implication |
|---|---|
| Architecture | AMD64 machine 0x8664, PE32+; necessary architecture requirement met |
| Entry point | RVA 0x2C0F0; fits executable file-backed data. This does not establish its initialization contract |
| Imports | Static import directory empty; no external imported runtime DLL requirement observed. Dynamically resolved dependencies are not inferable from that absence |
| TLS | Directory absent; current TLS gate does not block this hash |
| CLR / delay imports / load-config | All absent; these unsupported features do not block this hash |
| Exception directory | RVA 0x147000, size 0x2E98: 994 runtime-function records; 386 version-1 flags-0 headers and 608 version-1 CHAININFO headers |
| Handler metadata | No language-handler flags in those records; final structural preflight accepts the bounded code/chain metadata |
| Final --check | Passed PE and supported-feature checks; no DLL code executed and no target opened |
| Initialization and shutdown | Source contract, host requirements, asynchronous readiness, worker ownership and teardown still need review and controlled verification |

The file changed externally during this task. The first inspected snapshot was
217088 bytes, SHA256
`23C09EDF7A4DD804B3A1C881AAF4DEE75E074F67816FB5D5327AD9A94A1FA108`,
entry RVA 0x23B80, exception directory 0x13C000/0x27CC, and 849 records
(332 flags-0, 517 CHAININFO); it also passed static preflight. The final snapshot
above was independently re-inspected and passed, with the same absent TLS,
import, CLR, delay and load-config directories. This task only read the external
files; it did not perform the intervening build/change. Original evidence is
retained and `osiris-release-current-*` identifies the final inspection. Future
changes invalidate a hash-specific conclusion and need a fresh static check.

The Debug candidate at the adjacent `Debug\Osiris.dll` is 1978368 bytes,
SHA256 `8DA4D1C509F391462245EEA0FB4E4E59B5268C4EAB7D9D5A340A2B8DD4E91237`.
It has debug CRT/KERNEL32 imports, a load-config directory (RVA 0x1AE4C0,
size 0x140), and is rejected first for unsupported unwind/language-handler
metadata. Do not substitute it for the assessed Release candidate. Two older
accessible binaries were inventoried separately in osiris-inventory.json; their
folder names do not establish source identity or release suitability.

Evidence is hash-specific under `audit-2026-10-22/release-run/osiris-*`:
inventory, dumpbin /headers /imports /loadconfig outputs, unwind summary and
Release/Debug preflight diagnostics. Static acceptance removes the identified
TLS/load-config/handler-format blockers for this Release file only. It does not
prove general exception handling, module lookup, initialization, application
behavior, safe shutdown, or any target/game compatibility.

Later controlled compatibility work needs a fixed reviewed source revision and
build recipe matched to the DLL hash; an explicit entrypoint/async-readiness,
dependency, metadata/module-registration, worker and shutdown contract; and an
owned isolated host that can satisfy that contract and expose an observable
initialization result. A successful entrypoint alone is insufficient. If the
component requires a game environment, an ordinary fixture cannot establish its
game behavior; that remains a separate unverified activity, not a release claim.

This work establishes no VAC safety, detection outcome, or CS2 runtime
compatibility. No CS2, game, anti-cheat-protected process, bypass, driver, process
hiding, or new concealment mechanism was involved.
