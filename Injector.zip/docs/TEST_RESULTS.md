# Actual build and test results — 2026-10-22

## Latest result: final developer release

**Release 144 passed / 0 failed; Debug 144 passed / 0 failed.** All 108 previous
checks remain, with 36 release checks added. The ZIP-extracted production Release
CLI also passes the full 144-check Release suite. Only freshly source-built
reviewed tests, their owned children, and the production injector ran. Osiris
was read statically only; no game/protected/third-party target was used.

Evidence: `audit-2026-10-22/release-run/`. Final script logs/provenance are copied
there as `final-*`; `artifacts/` retains the normal script outputs. The original
82-check and I-05 108-check milestone evidence is retained in earlier directories.

### Commands and environment

PowerShell in the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
.\audit-2026-10-22\release-run\build-normal.ps1
.\audit-2026-10-22\release-run\analyze.cmd
.\audit-2026-10-22\release-run\package.ps1
.\audit-2026-10-22\release-run\test-package.ps1
```

Packaging refuses to overwrite an existing release directory/ZIP/extraction.
The exact native MSBuild /m /t:Rebuild commands are in build-normal.ps1. Its
normal-Release.log and normal-Debug.log each end with 0 warnings and 0 errors.
No AuditBuildRoot, toolset/SDK override, include/library alteration, security
setting change, or project modification is required for normal solution builds.
The standard test script sets AuditBuildRoot for output separation only.

Unchanged installed toolchain: VS Community 2026, v145, MSVC 19.51.36260,
VCToolsVersion 14.51.36231, SDK 10.0.26100.0. The project still requests SDK
10.0. build-properties.json and sdk-selected-paths.json record actual selected
paths; sdk-gdi32.json confirms the installed x64 library. Earlier gdi32 detection
failures did not prove a missing SDK; their exact transient cause remains unknown.
Build/test success uses the native installed toolchain context, not a replacement
SDK or detection workaround. Runtime OS remains unelevated Windows 11 Pro
10.0.26300 AMD64; no wider OS runtime result is claimed.

### Added checks and observed behavior

| Coverage | Evidence |
|---|---|
| Validation allocation and mapper host allocation failures | Test-only bad_alloc injection, false result/diagnostic, unchanged target allocation inventory |
| Each of five remote allocation stages | Deterministic failure before selected real allocation; earlier allocations released before execution |
| Process exit during initialization | Reviewed payload ExitProcess(73); prompt false result and explicit exit diagnostic, no success |
| Supported/unsupported unwind metadata | Simple/chained version-1 accepted; language handlers, cycles, unsupported version and partial multi-slot operation rejected |
| Selection and cancellation | Duplicate-name fixture, read-only process list, help/invalid arguments, blank DLL/target and declined confirmation; unchanged target allocations |
| File-only preflight | Source-built payload accepted without event signal; malformed/wrong-architecture/TLS/load-config fixtures rejected with useful text |
| Production CLI initialization | Two successful calls each independently signal a target-owned named event; failed entrypoint returns nonzero and failure diagnostic |
| Exited CLI target | Owned child's process object retained after shutdown; CLI reports exited target and -2 without mapping |
| Unsupported suspended startup | --spawn returns -11 and states that no process was launched |
| Existing lifecycle/address failures | Earlier 108 checks retained, including missing APIs/modules/imports, denied read access, real 30-second timeout and safe eventual thread completion |

Low-memory tests are deterministic failure-path tests, not global RAM exhaustion.
Error construction inside validation may itself allocate; the mapper/CLI outer
boundary prints a literal allocation diagnostic. No allocator-completeness or
arbitrary hostile-input safety claim is made. Repeated initialization proves two
independent mappings, not idempotence or unloading. General C++ throw/catch,
loader notifications, arbitrary mitigations, and unload remain untested.

### Analysis and intermediate failures

Final production main.cpp, PeValidation.cpp, injector.cpp and RemoteApi.cpp
passes use `/W4 /WX /analyze /c /EHsc /std:c++17 /GS-`, matching the existing
remote-code project's /GS- choice. Commands/output: analyze.cmd and analysis.log.
No application analysis/compiler warning remains. Main's analysis command alone
uses `/wd28286`: SDK 10.0.26100.0 consoleapi.h:236 contains the malformed SAL
expression `sizeof(TCHAR%)` on ReadConsoleW. The initial C28286 log is retained
as analysis-initial-sdk-sal-failure.log. No SDK header or production warning
configuration was edited. This is an analysis limitation, not an SDK build fix.
Earlier I-05 production/test verifier analysis remains in i05-run.

An initial function-try-block around ManualMapDll made MSVC treat following
optimization pragmas as inside the function (C2156/C4081). Moving try/catch into
the ordinary function body fixed compilation; no copied code was changed.
The first 143-check Release/Debug run passed. Adding the exited-target test first
expected OpenProcess to fail, but Windows could open the retained process object;
the CLI correctly reported its exited state. The assertion now checks that
observed stage/text. The 143/1 log is retained, followed by final 144/0 runs.
No failure assertion was removed or bypassed.

### Package and static DLL evidence

Package: `releases/Injector-x64-20261022/` and adjacent ZIP/.sha256. It contains
10 files: executable, three release CRT DLLs, README, LICENSE, runtime notice,
BUILD-INFO.json, SOURCE-MANIFEST.json and SHA256SUMS.txt. No test payload, PDB,
intermediate output, debug runtime, Osiris binary or private test data is included.
CRT files are unchanged from the installed official x64 redistributable
directory, version 14.51.36247.0. dumpbin dependencies require those three files
plus Windows KERNEL32/UCRT. App-local module paths were observed in a live owned
package process; a clean separate Windows installation was not tested.

package-verification.json records every ZIP-entry hash and extracted-file match.
test-package.ps1 uses INJECTOR_TEST_CLI_PATH only in the test runner to select
the extracted executable; source payloads/hosts still come from artifacts/Release.
tests-extracted-package.txt ends 144/0, and package-runtime-modules.json records
all three DLL paths within extracted-release. Source manifest SHA256 is the local
revision identifier; package executable bytes match the fully tested artifact.
See RELEASE_GUIDE.md for executable/source/ZIP SHA256 values.

Osiris inventory, dumpbin headers/imports/loadconfig, unwind counts and final
file-only preflight outputs are saved as osiris-* evidence. The identified
Release DLL passes metadata policy; the Debug DLL is rejected for a language
handler/unsupported unwind requirement. Neither was loaded or modified. Exact
hashes, fields and remaining initialization obligations are in COMPATIBILITY.md.
The external Release DLL changed during final verification. The original
849-record hash and final 994-record hash were independently assessed and both
passed static preflight. Current-snapshot reports have the osiris-release-current
prefix; no injector/package change was needed. This task did not rebuild or write
the external project, and does not claim its binary stayed unchanged throughout.

## Historical result: I-05 completed

The full existing 82 checks plus 26 new I-05 checks pass: **108 passed, 0 failed
in each x64 Release and Debug configuration**. Final normal solution rebuilds
and the standard test-script builds each report zero compiler/linker warnings
and errors. Only reviewed source-built components and their owned children ran.
The original audit and unrelated loader features were not reworked.

Evidence directory: `audit-2026-10-22/i05-run/`. Its starting-state manifest
confirms all 25 previous milestone file hashes matched before this task. The
normal-final-Release.log and normal-final-Debug.log show default solution output
paths, with no AuditBuildRoot, SDK-installation, or toolset overrides. Exact
PowerShell command from the outer workspace, repeated for Debug:

```powershell
& 'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe' `
  '.\Simple-Manual-Map-Injector-master\Manual Map Injector.sln' `
  /t:Rebuild /m /p:Configuration=Release /p:Platform=x64 /nologo /verbosity:minimal
```

Those normal-output binaries also passed the complete 108-check suite before the
final analyzer null-guard correction; tests-Release.txt/tests-Debug.txt in i05-run
preserve that run. After the correction, both normal configurations were rebuilt
again and the unchanged standard script was run to verify the final source:

```powershell
.\Simple-Manual-Map-Injector-master\tests\run-tests.ps1 -Configuration Both
```

This script uses AuditBuildRoot only to separate build output paths under
artifacts/. It does not override PlatformToolset, SDK selection, detection flags,
include/library paths, or compiler safety settings. Final logs/provenance are
in artifacts/ and copied into i05-run as final-script-* evidence; both runs are
108/0. Final binary hashes and changed-source inventory are also saved there.

### New controlled checks

AddressTests in regression_tests.cpp checks all five required API locations in a
real owned target. On this Windows build, the observed owners were KERNEL32 for
LoadLibraryA, GetProcAddress, RtlAddFunctionTable, and RaiseException; ntdll owned
RtlPcToFileHeader. These are observations, not assumed universal owner mappings.

Twenty-one test-only simulated API results/observations cover missing architecture
query, unsupported architecture, snapshot/enumeration failure, absent owner,
path/base/PE-identity mismatch, failed memory reads, absent target export, an
unsupported resolved-owner forwarder, non-executable memory, all five missing
local exports, and four additional API-specific RVA mismatches. Each case also
calls the mapper to verify rejection before allocation, useful diagnostics,
all-null output addresses, balanced handles, and a healthy unchanged child.
The other new checks cover all-five success, explicitly disabled optional APIs,
real PROCESS_VM_READ denial (Win32=5), an invalid handle, and an exited owned child.
Simulated ARM64/missing-API observations are rejection-branch tests, not runtime
tests on those operating systems. No target Windows module was modified.

### Static analysis

MSVC /W4 /WX /analyze /c /EHsc /std:c++17 was run on RemoteApi.cpp in production
and INJECTOR_TESTING modes using the native x64 developer environment. Both final
passes exit zero with no warnings. The exact wrapper and output are analyze.cmd
and static-analysis.txt in i05-run. A first wrapper had an incorrect relative
source path (C1083); that log is preserved. Analysis then found C6387 on an
unchecked GetModuleHandleW result before GetProcAddress. An explicit null guard
was added, followed by clean analysis, rebuilds, and complete regression tests.
The warning log is static-analysis-before-null-guard.txt. This is focused analysis
of the new verifier, not a new whole-loader static audit.

### SDK/build environment clarification

Native build properties select v145, VCToolsVersion 14.51.36231, MSVC
19.51.36260, and SDK 10.0.26100.0 from the existing installation. The project
continues to request WindowsTargetPlatformVersion 10.0. The installed x64
gdi32.lib is 138880 bytes, SHA-256
FB44EF338E7F43E859D749DA5F8CE3C5743A16DAFE067C52E5C5E5625FE1D2B2.
Its current native metadata and toolchain properties are captured in
native-gdi32.json and native-toolchain-properties.json. It is also readable in
the restricted view now (restricted-sdk-view.json).

The previous run's initial restricted SDK checks reported MSB8037/MSB8036 and its
file lookup returned absent; later restricted builds also had locked outputs and
a PDB mismatch. Those observations did not establish a machine-wide missing SDK.
The exact cause of the earlier transient visibility/locking has not been
reconstructed. SDK-detection-flag overrides were attempted diagnostically in that
restricted run, but the successful native baseline did not use them. The current
normal solution builds also use none. Moving compilation outside the restricted
execution context was the execution workaround; no SDK/library fabrication,
project retargeting, toolchain installation, registry change, antivirus exclusion,
or persistent SDK detection override was performed by either task. Separate output
folders were used previously for evidence/lock isolation, and are not required
for the current normal solution builds.

Compatibility evidence remains Windows 11 Pro build 26300 only. Existing TLS,
general EH/unload, unsupported loader-format, and other-Windows limitations remain.

## Environment and provenance

Native Windows 11 Pro 10.0.26300 (build 26300), AMD64, unelevated token.
Visual Studio Community 2026 18.10.12224.181 (display 18.10.3), v145,
MSVC 19.51.36260, Windows SDK 10.0.26100.0. MSBuild and dumpbin were taken from
the installed Visual Studio directory, not downloaded substitutes.
Machine-readable record: `audit-2026-10-22/repair-run/environment.json`.

Only reviewed source-built RegressionTests.exe, its own --host children,
Injector-x64.exe against those children, and TestPayload.dll were executed.
The payload was inspected with dumpbin: AMD64, custom TestDllMain entry, KERNEL32
Sleep import, no TLS directory, no CRT dependency. Its source includes an absolute
data pointer so the relocation path is genuinely exercised. Its normal entrypoint
can delay, accept, or reject initialization through fixture-owned control data.
No bundled or legacy DLL was executed. No game or protected process was targeted.

## Baseline before edits

The original x64 Release and Debug solution builds both succeeded natively with
zero compiler/linker warnings or errors. Logs are `baseline-native-Release.log`
and `baseline-native-Debug.log` in the repair-run folder. Original executable
headers/imports are in `baseline-imports.txt` (AMD64 console executable).

Restricted-environment attempts first reported MSB8037/MSB8036 SDK discovery
failures, then locked linker outputs/C1083 and LNK1101 MSPDB mismatch. The complete
installed toolchain succeeded outside that environment, with no source changes,
SDK override, toolchain installation, antivirus change, or security exclusion.
The unsuccessful diagnostic logs remain alongside successful native logs. They
are environment results, not evidence that the original source failed to compile.

Native baseline command, in PowerShell from the outer workspace (repeat with
Debug and a separate Debug OutDir/IntDir):

```powershell
& 'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe' `
  '.\Simple-Manual-Map-Injector-master\Manual Map Injector.sln' `
  /t:Rebuild /m /p:Configuration=Release /p:Platform=x64 `
  '/p:OutDir=C:\Users\zacha\Documents\Projekt\Simple-Manual-Map-Injector-master\Simple-Manual-Map-Injector-master\audit-2026-10-22\repair-run\baseline-native\Release\' `
  '/p:IntDir=C:\Users\zacha\Documents\Projekt\Simple-Manual-Map-Injector-master\Simple-Manual-Map-Injector-master\audit-2026-10-22\repair-run\baseline-native\Release\obj\' `
  /nologo /verbosity:minimal
```

## Previous safety-milestone build and runtime results

PowerShell, from the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

The script records its exact compiler/linker invocations in the build logs. It
uses MSBuild /m /t:Build /p:Platform=x64 /p:Configuration=Release or Debug,
and /p:AuditBuildRoot with the absolute artifacts directory. Clean Rebuilds of
both configurations also passed during milestones.

| Final configuration | Build | Runtime regression result |
|---|---|---|
| x64 Release | Pass; 0 warnings, 0 errors | 82 passed, 0 failed |
| x64 Debug | Pass; 0 warnings, 0 errors | 82 passed, 0 failed |

Historical 82-check logs are `audit-2026-10-22/repair-run/final-tests-Release.txt`
and `final-tests-Debug.txt`. That milestone's executable imports/headers and
binary hashes are also preserved in `repair-run/`. The artifacts/ directory now
contains the I-05 results above. Release imports are AMD64 KERNEL32, MSVC runtime
DLLs, and UCRT API sets. Debug imports include the corresponding debug runtimes.
Neither final executable imports the old ADVAPI32 privilege-adjustment path.

Coverage includes valid/small PE input; all 1024 truncation boundaries of the
synthetic fixture; 2000 seeded mutations per configuration; invalid headers,
section/file/image ranges, certificate file bounds, import tables, thunk/name
ranges, overlapping IATs, relocation sizes/targets/self-overwrites, TLS bounds,
exception record lengths, >20 MiB virtual section, null pointers, PID boundaries,
first/subsequent process entries, pattern overflow and no-access-page boundaries.

Runtime cases include controlled attach/import/relocation, FALSE entrypoint,
missing module/symbol, allocation denial, deterministic pre-thread failure,
remote allocation inventories, thread handle counts, metadata preservation,
exception-support allocation/registration, repeated isolated children, healthy
host shutdown, and actual production CLI success/overflow/missing-file results.
Each configuration includes a real 30-second mapper timeout and a delayed
entrypoint which safely completes afterward; retained scratch memory is required.

Earlier results were 53/0, then 69/1 in each configuration, then 74/0, then final
82/0. The 69/1 failure was an incorrect fault-fixture assumption: a restricted
process handle still allowed thread creation on this host. The fixture now uses
an explicit INJECTOR_TESTING-only failure, retaining the real remote allocations,
writes, and cleanup assertions. No test was disabled to obtain success.
Earlier result files are retained as milestone evidence.

## Existing test sources: compilation only

`audit-2026-10-22/repair-run/build-legacy.ps1` contains exact commands and records
results in `legacy-builds/`. The original TLS project requests v143 and fails with
MSB8020 because that toolset is not installed. The same unchanged project builds
with command-line PlatformToolset=v145. Trivial, TLS-log, TLS-noworkers, and all
five exception variants (EHsc_MT, EHa_MT, EHac_MT, EHsc_MD, EHa_MD) build with v145.
EHsc and EHac variants warn C4297 at exc_test.cpp:400-403 because exported extern
"C" functions throw under /EHc. The legacy source was left intact; warnings are
recorded, not suppressed. Worker joins in DllMain, message boxes, and hardcoded
author-specific log paths make those examples unsuitable for the new unattended
suite. Their TLS requirements are blocked by the current mapper anyway.

## Limits of the evidence

Hosted CI has been configured but not run. Win32, Windows 10/other builds,
--spawn suspended startup, general DLL detach/unload, actual C++ throws/SEH across
mapped frames, induced unwind-registration failure, every Win32 API failure,
low-memory STL allocation failures, and complete malformed unwind/load-config
semantics remain untested. This is controlled developer testing evidence, not
arbitrary-DLL, Osiris, CS2, VAC, or universal Windows compatibility certification.
