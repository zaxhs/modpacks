# Developer release — 2026-10-22

Final executable relative to the nested solution directory:
`releases/Injector-x64-20261022/Injector-x64.exe`.
ZIP: `releases/Injector-x64-20261022.zip`; adjacent `.zip.sha256` records its hash.
Extract the complete ZIP and keep the runtime DLLs next to the executable.
No installation, security exclusion, privilege escalation or game launch is needed.

| Identity | SHA256 |
|---|---|
| Release ZIP | `F429BF7D0287F78471ADBAF77FD75ACADA852B827BB5CFDED4C3D6EF910E8BF9` |
| Injector-x64.exe | `C1E44E26AC7732A131F417E2A36FC64BDF83F7B0479A644713D924A0DC2273FF` |
| SOURCE-MANIFEST.json | `707D7AA8033C8897CC31F795E7FB923F3CB79F570E330264DF336C4C53052D7C` |

The source manifest fingerprints production/test source, headers, project files,
solution and test script. It is a local source revision identifier, not a Git
commit. Documentation and generated logs are tracked separately in the final
audit manifest. Package bytes match the tested artifacts/Release executable;
bit-for-bit rebuild reproducibility across paths/machines is not claimed.

## Use from PowerShell

```powershell
.\Injector-x64.exe --help
.\Injector-x64.exe --check "C:\DeveloperTests\OwnedFixture.dll"
.\Injector-x64.exe --list
.\Injector-x64.exe
```

Replace example paths with a reviewed source-built component. Preflight executes
no DLL code and opens no target. Interactive mode asks for file, PID/unique name
and confirmation; blank/EOF cancels before OpenProcess. Start your owned host
normally, then select its PID. --spawn is unsupported and launches nothing.
For an unattended operation explicitly pass both arguments:

```powershell
.\Injector-x64.exe "C:\DeveloperTests\OwnedFixture.dll" 12345
```

Replace 12345 with that owned host's PID. Duplicate names fail rather than picking
the first process. The program requests only its specific process rights and runs
asInvoker; denied access is diagnosed without automatically elevating.

| Exit code | Meaning |
|---|---|
| 0 | Requested check/list/help/initialization completed, or interactive cancellation |
| -1 | Invalid or unresolved target selection |
| -2 | Snapshot, OpenProcess, or target-alive query failure |
| -4 / -5 | Invalid/missing file selection / unreadable file |
| -6 | File-size/read/PE/unsupported-feature rejection |
| -7 | Host allocation failure/size limit |
| -8 | Mapping/initialization/protection/cleanup failed; some code may have run |
| -10 / -11 | Invalid arguments / unsupported suspended startup |

Windows tools may display negative codes as their unsigned 32-bit value.
Success confirms initialization returned successfully, not asynchronous readiness
or complete application behavior. Verify a separate observable host result.

## Scope and boundaries

Reviewed native AMD64 PE32+ DLLs, <=512 MiB file/image, supported ordinary imports
and DIR64 relocations, and structurally bounded version-1 handler-free/chained
unwind metadata. The source contract must not require normal loader module
registration, DLL thread notifications, or other unimplemented loader services.
TLS, CLR, delay imports, load-config/CFG, language handlers and unknown unwind
formats are rejected. Do not disable required features to bypass this policy.
Validation is not a sandbox or a complete semantic PE verifier.

General C++ EH/RTTI/unwinding behavior is not established by successful function-
table registration. There is no general unload/detach, rollback or dependency
reversal. After execution, image/support state lives until target exit; timeout
also keeps temporary code/data. Failure can leave partial initialization. Close
the owned host before retrying after failure/timeout. Successful repeated calls
create independent mappings and consume additional host memory.

Only Windows 11 Pro 10.0.26300 native AMD64 was runtime verified. Other Windows
versions, x86, ARM64/emulation and different target mitigations remain unverified.
I-05 checks require stable matching system modules/API exports; they are point-in-
time checks, not cryptographic code authentication or atomic remapping protection.

## Evidence and deployment

Build verified: x64 Release and Debug, installed v145/MSVC 19.51.36260 and SDK
10.0.26100.0, zero normal build warnings/errors, no SDK/toolset changes or build
workaround. Automated tests verified: 144/0 each, retaining the original 108.
Isolated runtime verified: reviewed source payloads and owned hosts, production
CLI event-observed initialization/rejection and extracted-package 144/0.
Relevant production /analyze checks pass with the SDK SAL exception documented
in TEST_RESULTS.md. Analysis does not establish arbitrary runtime correctness.

The package includes msvcp140.dll, vcruntime140.dll and vcruntime140_1.dll version
14.51.36247.0 from VS's official installed x64 redistributable directory. Their
hashes/versions are in BUILD-INFO.json. dumpbin dependency closure and observed
app-local module paths were checked. KERNEL32/UCRT come from Windows. No debug
CRT, system DLL, payload or PDB is bundled. A clean separate machine was not
tested. Microsoft runtime distribution remains subject to applicable terms;
see RUNTIME-NOTICE.txt and Microsoft's
[redistribution documentation](https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files?view=msvc-170).
App-local runtime servicing requires redeploying updated runtime files; see
[deployment guidance](https://learn.microsoft.com/en-us/cpp/windows/deployment-in-visual-cpp?view=msvc-170).

Osiris static compatibility assessed: identified Release hash passes file-only
metadata preflight. Osiris runtime compatibility unverified. CS2 runtime
compatibility and VAC safety unverified. No Osiris binary was executed or changed.
See COMPATIBILITY.md for exact candidate fields and source-level obligations.

For a later controlled compatibility check, first bind the reviewed source and
build recipe to the DLL hash and define entrypoint/async readiness, dependency,
module metadata, worker ownership and shutdown requirements. Then use an owned
isolated host capable of meeting those requirements and record an observable
initialization result and clean process exit. If those requirements need a game,
this fixture evidence cannot establish game behavior. No such runtime test is
part of this release. No additional injector feature is essential now; pause
development unless a concrete requirement or reproducible defect appears.

Reproduction/evidence scripts and logs are under audit-2026-10-22/release-run.
package.ps1 intentionally refuses to overwrite existing outputs. A new release
needs a new identity, updated manifests and corresponding verification.
