# Model handoff — 2026-10-22

The workspace has a nested solution directory. Parent `AGENTS.md` is permanent.
There is no Git history here. Do not clone or replace the tree, modify Osiris,
execute bundled DLLs/games/protected targets, or add evasion. Use GPT-6.1 Sol High
for normal work; no Astra escalation or new chat is needed for the next milestone.

## Released state

Final developer release is complete: `releases/Injector-x64-20261022/Injector-x64.exe`
and `releases/Injector-x64-20261022.zip`. Read RELEASE_GUIDE.md for hashes, usage,
supported scope and required runtime files. Final source/build/test fingerprints
are in SOURCE-MANIFEST.json; its SHA256 is the local revision identifier because
this checkout has no Git history. Keep package files together.

Current results are **144/0 x64 Release, 144/0 x64 Debug**, preserving the previous
108 and adding 36 release checks. The extracted package's production CLI also
passes 144/0; its three Microsoft runtime DLLs load from that extracted folder.
Event signaling from the owned target confirms production CLI initialization.
Normal solution builds pass without SDK overrides, with zero warnings/errors.
Production main/PE/mapper/address-verifier analysis passes /W4 /WX; main alone
excludes C28286 from malformed SDK consoleapi.h SAL during analysis. See the
recorded initial warning and final commands; no SDK or production warning setting
was changed. The toolset remains v145/MSVC 19.51.36260/SDK 10.0.26100.0.

Latest evidence is `audit-2026-10-22/release-run/`: before snapshots and 27-entry
starting-state check, final logs/provenance, normal builds, analysis, Osiris static
inventory/preflight, packaging/extraction hashes, app-local runtime paths, and
final-manifest.json/source-changes.patch. Earlier stage evidence is preserved.
package.ps1 refuses overwrite; test-package.ps1 retests the existing extracted
package. Do not rerun packaging into the same destination or alter released bytes
without a new package identity and appropriate retest.

Current console workflow: no arguments for file/target/confirmation prompts,
explicit `dll_path PID` for unattended operation, --list for read-only listing,
--check for file-only preflight, --help for usage. Blank/EOF cancels before target
opening; ambiguous names require a PID. --spawn is now explicitly unsupported.
The program remains asInvoker with specific rights and no debug privilege.

The accepted native x64 DLL class requires reviewed initialization that does not
depend on unsupported normal-loader services. Version-1 handler-free/bounded
chained unwind data is structurally checked. Language-specific handlers,
unknown unwind formats, load-config/CFG, TLS, CLR and delay imports fail closed.
Do not weaken these gates or strip required security features for compatibility.
General exception semantics, DLL thread notifications, loader module registration,
unload/detach/rollback and arbitrary mitigations remain unsupported/unverified.

Host bad_alloc/length_error boundaries now return useful failure. Deterministic
test-only hooks exercise host/validator allocation failure and all five remote
allocation stages with actual pre-execution cleanup. Process death during DLL
initialization reports failure after thread signal. Resource ownership after
execution is unchanged; false can leave partially initialized state. The copied
Shellcode body and public ManualMapDll signature remain unchanged in this stage.

The accessible Osiris Release candidate at the path/hash in COMPATIBILITY.md
passes static preflight, including its final 994 simple/chained runtime-function
records. No TLS/static imports/load-config/CLR/delay imports were present in
that hash. Debug is rejected for unsupported handler metadata and also has
load-config/debug runtime requirements. No Osiris code was changed or loaded.
Actual initialization, worker readiness/shutdown, Osiris/CS2 behavior and VAC
safety remain unverified. The external Release file changed during this task;
both the initial 849-record snapshot and final 994-record snapshot are recorded
by hash. Do not turn metadata acceptance into a runtime claim.

No further injector task is essential for the supported developer scope.
Recommend pausing after this delivered release. Later controlled compatibility
requires source/hash/build provenance, explicit source initialization/worker/
shutdown obligations, and an owned host that can expose an observable result.
There is no documented blocker requiring Extra High/Ultra/Astra or a new chat.

## Earlier milestones and reproduction

Original source: `audit-2026-10-22/repair-run/before/` with starting-state.json.
Earlier audit backups remain untouched. Source/configuration differences and new
file inventory are in FIXES.md and the final audit manifest/patch.

Installed native tools: Visual Studio Community 2026 18.10.12224.181, v145,
MSVC 19.51.36260, Windows SDK 10.0.26100.0. Tested unelevated on Windows 11 Pro
10.0.26300 AMD64. Restricted shell builds showed misleading SDK/PDB/locked-output
errors; native installed-toolchain builds succeeded. No SDK/security settings were
changed. Native MSBuild path:
`C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe`.

PowerShell from the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

Safety milestone: Release 82/0, Debug 82/0. I-05 result: **108/0 in both**,
retaining all 82 checks and adding 26. Normal default-output solution rebuilds
and standard-script builds have zero warnings/errors. Focused /analyze /W4 /WX
passes for new verifier production and test modes after fixing C6387.
The suite takes roughly a minute for both configurations because each includes
a real 30-second timeout. Binaries/logs/hashes are in artifacts/. Earlier milestone
failures and legacy-build evidence are under audit-2026-10-22/repair-run/.
I-05 snapshots, normal build commands/logs, analysis, tests, and SDK clarification
are under audit-2026-10-22/i05-run/. gdi32.lib exists in the installed SDK and both
execution views now; no SDK/toolset retargeting or persistent detection workaround
is needed. The exact historical transient visibility/locking cause is unproven;
see TEST_RESULTS.md rather than repeating a claim that the machine lacked the SDK.
The legacy TLS project fails with missing v143, builds unchanged with /p:PlatformToolset=v145.
All reviewed legacy C++ sources compile; /EHc variants emit C4297. None was run.

## Implementation contracts

ManualMapDll now requires sourceSize in argument three. ClearHeader and
ClearNonNeededSections default false; true explicitly fails. Only attach is
accepted. TLS directories always fail before allocation, regardless of TLSSupport.
The former pattern-resolved ntdll call and stack fake loader entry are removed
from active code. Do not silently skip TLS or restore the gate to pass a test.

PeValidation.cpp checks file/image bounds, headers, sections, nested imports and
relocations, metadata aliasing, TLS structure, and exception tables/unwind-chain
extents. Host allocation exceptions are handled; complete unwind semantics and
arbitrary PE/loader requirements are not established. Language handlers and
load-config/CFG are rejected. Input buffers must be readable and unchanged.

RemoteResources releases recorded allocations before thread creation. After the
thread starts, image/support allocations live until target exit. Scratch is freed
only after the thread handle signals. Timeout keeps all storage; never blindly
free it, terminate an existing target, or retry assuming nothing initialized.
There is no general rollback/unload/detach implementation. Function-table and
dependency side effects can persist. Protection/cleanup failure also returns false
after successful entry; false therefore does not mean no code ran.

MappingStatus plus thread exit code reports initialization results. `.mmap$a` and
`.mmap$z` delimit copied code; recheck generated instructions if changing compiler,
optimization, runtime checks, or remote function contents. The production CLI is
tested independently of the mapper compiled into RegressionTests.

INJECTOR_TESTING fault variables exist only in the regression build. A prior
test attempted to deny CreateRemoteThread with handle rights but still created
a thread on this host, yielding a genuine failing resource assertion. It was
replaced by explicit API-failure simulation with real remote allocation cleanup;
do not remove that assertion or mislabel the old run as an injector leak.

## I-05 contracts and completion

I-05 is completed as a checked precondition, not a loader rewrite. RemoteApi.cpp
resolves local addresses, verifies native AMD64/matching process machines using
IsWow64Process2, enumerates target modules, and checks the actual local owner's
path/base/PE identity, independently read target direct-export RVA, and committed
executable MEM_IMAGE memory. The full five-pointer/caller trace is in FIXES.md.
The output bundle stays entirely null on failure; diagnostics name API/stage,
reason, and Win32 error. ManualMapDll invokes this before its first allocation.
Both LoadLibraryA and GetProcAddress are required; RtlAddFunctionTable,
RaiseException, and RtlPcToFileHeader are required only with x64 exception support.
Both addresses embedded in existing stubs now come from that verified bundle.

Actual owners may be kernel32, KernelBase, or ntdll; never hardcode a universal
owner based on one Windows build. Local standard forwarding is allowed to resolve
the actual owner; another forwarder in that owner, a different base, identity,
path, missing export, read/query error, or unsupported architecture fails closed.
Snapshot ERROR_BAD_LENGTH retries are bounded. No remote base translation or
forwarder resolution was added. Module checks do not authenticate code and are
not atomic against concurrent target remapping; use stable owned developer hosts.
lpReserved is still an opaque target address supplied by the caller, not a local
pointer to reinterpret automatically. Remote-allocated pointers and dependency
exports obtained inside the target retain their existing contracts.

INJECTOR_TESTING-only RemoteApiTestFault hooks alter API results or observation
copies, never target system modules. Tests cover useful diagnostics, all-null
outputs, zero remote side effects, balanced handles, optional APIs, actual denied
read access, invalid handles, and exited owned processes. Production has no fault
controls. No codegen or shellcode-body changes were made for I-05.

No next coding task is essential for the current controlled no-TLS goals.
**Recommend pausing injector development.** Resume for a concrete observed
failure/new requirement, not speculative TLS/EH/unload expansion. Existing deeper
PE, TLS, general EH, ownership/rollback, and Windows-version limits remain recorded
without turning them into automatic new work. No Astra blocker was found.

The earlier report-only Osiris assessment is superseded by the hash-specific
static inspection in COMPATIBILITY.md. Source-level initialization/shutdown and
runtime behavior remain unverified. There is no VAC/CS2 runtime result.
