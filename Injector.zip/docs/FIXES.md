# Implemented corrections — 2026-10-22

## Finalization and developer release

All earlier safety and I-05 corrections are retained. The release-run snapshot
verified 27 existing manifest entries against the previous milestone before
editing. This stage fixes release reliability and usability; it does not repeat
the audit or add a general Windows loader.

### Findings and decisions

| Finding | Classification and resolution |
|---|---|
| A returned entrypoint result alone gives no independent fixture evidence | Required before release: source-built payload signals a named event from the owned target; production CLI success and rejection are exercised |
| Allocation exceptions outside the image-vector resize could escape | Required before release: host mapper, validator, and CLI boundaries catch bad_alloc/length_error; deterministic test faults exercise failure reporting and unchanged target allocations |
| Target death after thread creation lacked a direct process-state diagnostic | Required before release: query target after thread signal, fail explicitly on exit/query failure; owned payload ExitProcess(73) exercises the path |
| Name selection could pick the first of duplicate names; no safe interactive workflow | Required before release: unique-name selection or explicit PID, file/target prompts and final confirmation, blank/EOF cancellation before OpenProcess, --help/--list/--check |
| Nested unwind metadata was incompletely bounded | Required for accepted DLL class: bounded version-1 unwind-code/chain walk, cycle/depth/alignment checks; protect those spans against IAT/relocation writes |
| Language-specific EH, TLS, load-config/CFG, delay imports and CLR are not implemented reliably | Optional other DLL types: explicitly reject detectable cases before allocation. No speculative implementation or security-feature-removal instructions |
| Suspended --spawn may run before target module state is ready | Unsupported workflow: explicit diagnostic and no child launch; use a normally started owned host |
| General unload/detach, rollback and dependency reversal | Documented limit: process exit remains release boundary; no automatic retry after failure/timeout |
| Separate Osiris Release candidate has simple/chained unwind records | File-specific static requirement: accepted by final preflight; no TLS/load-config/language-handler blocker found in that hash. Initialization/runtime needs remain unverified |

### Source references for this stage

- `PeValidation.cpp:28,205-264`: allocation boundary and bounded unwind/chain
  validation. Only version 1 with flags 0 or CHAININFO is accepted; maximum 32
  chain records. Recognized code widths are checked, including multi-slot extent.
  This does not verify complete unwind semantics or executable instructions.
- `PeValidation.cpp:266-275`: shared supported-feature policy used by both
  CLI preflight and mapping. Existing CLR/delay rejection remains at 106-108.
- `injector.cpp:18-36,54-67,318-324,369-376`: existing resource ownership with
  test-only allocation faults, host exception boundary, and target-exit failure.
  Trampoline allocation failure now has a named diagnostic at 202.
- `main.cpp:32-59,61-85,86-159`: console selection/listing, strict unique process
  matching, file-only preflight, cancellation, explicit unsupported spawn,
  Win32 error messages, specific access rights, and allocation-error exit code.
  `TargetInput.h:39` adds unique enumeration without removing the old helper.
- `regression_tests.cpp:363,398,449`: captured production-console harness,
  reliability tests, and observable end-to-end tests. `test_payload.cpp:4-30`
  implements reviewed event/rejection/exit behaviors. Test-only environment
  controls belong to the payload; production injector has no such controls.

The public ManualMapDll signature and copied Shellcode body are unchanged.
The existing two exception support pages remain for compatibility with the
previous implementation/tests; their presence is not a claim of general C++ EH.
Metadata, TLS fail-closed behavior, 30-second wait, and post-execution retention
remain intact. No Osiris file was modified or loaded.

Final result: **144/0 Release and 144/0 Debug** (108 retained + 36 new checks).
The extracted Release package also passes 144/0. See TEST_RESULTS.md and
RELEASE_GUIDE.md for exact evidence, package hashes and the SDK SAL caveat.

## I-05 follow-up: verified address reuse

The original safety milestone below is preserved. This historical follow-up changed I-05
only. All 25 source/configuration/documentation hashes matched the saved milestone
before edits; see `audit-2026-10-22/i05-run/starting-state.json` and `before/`.

Root cause: a pointer obtained in the injector names a location in that process.
Matching DLL architecture, a familiar Windows module name, or a successful
earlier child test does not prove that the same number names the same target
export. An invalid non-null bootstrap pointer can fault before the remote code
can report an import error. Two such pointers were embedded inside support code,
outside MANUAL_MAPPING_DATA, and also needed verification.

### Address trace in current source

| Address | Setup and remote caller in injector.cpp |
|---|---|
| LoadLibraryA | Verified bundle assigned at 110; remote import-module call at 437 |
| GetProcAddress | Assigned at 111; ordinal/name import calls at 451 and 484 |
| RtlAddFunctionTable | Assigned at 113 when x64 exception support is requested; calls at 504 and 514 |
| RaiseException | Verified bundle read at 132; absolute address embedded in existing support code at 166-168 |
| RtlPcToFileHeader | Verified bundle read at 198; original address embedded in existing trampoline at 222-225 |

`RemoteApi.cpp:197-223` resolves the required local exports and publishes the
bundle only after all checks pass. `injector.cpp:87-91` invokes it before the first
remote allocation and logs `API address verification failed: <API/stage>: <reason>
(Win32=<code>)` on failure. No address rebasing or remote resolver was added.
The ManualMapDll signature, status protocol, shellcode body, TLS gate, metadata
policy, and remote resource-lifetime rules remain unchanged.

### Checks and deliberate failure policy

`RemoteApi.cpp:68-82` uses IsWow64Process2 to require matching process machine types
on native AMD64 Windows. Absence/failure is explicit; it does not use the old
ambiguous WOW64 boolean as a fallback. The x64 build requires AMD64 processes.
The existing Win32 build can pass only matching I386 processes under AMD64 WOW64;
that path is compiled by CI but has no new runtime compatibility claim.

`ReadModules` at 85-100 checks module snapshot/enumeration errors and limits
ERROR_BAD_LENGTH retries to three. `CheckApi` at 137-194 obtains the actual local
address owner with GetModuleHandleEx, balances its reference, and finds that module
in the target snapshot. Owners are restricted to kernel32, KernelBase, and ntdll.
Full paths (case-insensitive), bases, machine/header layout, SizeOfImage,
TimeDateStamp, and CheckSum must match. These are identity fields, not a signature
or cryptographic integrity check.

`Image` at 36-65 bounds and checks exact ReadProcessMemory reads. `ExportRva` at
102-135 independently reads the target owner's export table with bounded arrays
and lexical binary search. The named direct export must equal the local address
offset. Ordinary local GetProcAddress forwarding can select the final owner;
another forwarder in that resolved target owner is rejected, not followed.
VirtualQueryEx must identify committed executable MEM_IMAGE memory belonging to
the expected allocation, without PAGE_GUARD/PAGE_NOACCESS. Null, absent, changed,
unreadable, unsupported, and mismatched observations all fail before execution.
The two bootstrap APIs are always required; the other three are required only
when the x64 exception-support path is requested. No optional API is silently
skipped while its feature remains enabled. Outputs are all null on failure.

Other address contracts were traced without changing them: target image/support/
parameter/code addresses come from VirtualAllocEx; the entrypoint is target base
plus validated RVA; dependency exports come from GetProcAddress executed inside
the target. lpReserved remains an opaque caller-supplied target address (null by
default), not a local pointer converted by the mapper. IsWow64Process2 itself is
called locally and is not transferred. The old TLS function pointer remains unused.

### Verification and limitations

The complete 82-check suite is retained. AddressTests adds 26 checks, including
21 simulated observation/API failures through test-only hooks, positive all-five
verification, optional-feature behavior, real denied ReadProcessMemory access,
invalid handles, and an exited owned child. Each simulated rejection also invokes
ManualMapDll and checks diagnostics, cleared outputs, unchanged target private
allocations, balanced host handles, and a live target. No target system module or
API code was patched for a negative test. Production has no test fault controls.
See TEST_RESULTS.md for final counts and static analysis.

This converts I-05's unchecked equality assumption into a checked precondition for
the supported stable developer target. It intentionally rejects a legitimate
different base, unfamiliar owner/forwarder, identity mismatch, unavailable API,
or uninitialized/unstable module snapshot instead of extending the loader.
Checks are point-in-time: the target must not concurrently unload/remap/modify
those modules. They do not authenticate code bytes, inspect every instruction or
internal call, or guarantee behavior against a malicious target. No process
suspension or target module pinning was introduced. TLS/EH/unload limitations from
the safety milestone are unchanged.

I-05 files: new `Manual Map Injector/RemoteApi.cpp` and `RemoteApi.h`; modified
`injector.cpp`, injector vcxproj, regression vcxproj, and regression_tests.cpp.
The five requested progress/results/compatibility/handoff documents are updated;
README and only the I-05 audit subsection are refreshed to remove stale claims.
No toolset, SDK selection, project dependencies, Osiris, or remote loader algorithm
was changed.

## Safety changes

`ValidatePeImage` in `Manual Map Injector/PeValidation.cpp` operates on an explicit
byte count. Header reads use memcpy after subtraction-based range checks.
Validation builds a bounded local image for nested RVA checks, checks sections
before copying, bounds import descriptors/thunks/strings and relocation blocks,
and rejects parser-metadata overwrites and overlapping IATs. Image size is limited
to 512 MiB, sections to 96, and unsupported CLR/delay-import input is rejected.
TLS structure and exception-record bounds are checked, without claiming complete
validation of Windows' nested unwind/language-specific formats.

`ManualMapDll` now takes sourceSize as its third argument and validates before
remote allocation. Header copying uses validated SizeOfHeaders. The CLI checks
file size, nonthrowing source-buffer allocation, and complete reads. Valid caller
buffers must remain readable and unchanged for the duration of the call.

The fixed 20 MiB erase buffer and header/section/code erasure were removed.
ClearHeader/ClearNonNeededSections default to false; requests to enable them fail
explicitly. The eight-byte section names use bounded printf formatting. These are
intentional API behavior changes to preserve metadata and diagnostics.

Shellcode(nullptr) returns InvalidData without writing through the null pointer.
The remote function has the actual DWORD WINAPI thread-start signature. Ordered
`.mmap$a`/`.mmap$z` code sections and an end marker define the copied extent,
replacing the unbounded assumption that 4096 bytes always describe that function.
The extent is sanity-checked and instruction caches are flushed before execution.
This remains MSVC/code-generation-sensitive; production Release and Debug CLI
paths are tested, not just a test copy of the mapper.

Pattern.h additionally rejects null patterns and overflowing decimal ranges,
bounds wildcard loops, validates the entire scan window for readability, uses an
iterative memory-range walk, and bounds section-name comparison. It is no longer
used to resolve TLS in the mapper. Module helpers still expect a valid loaded
module; they are not arbitrary untrusted pointer parsers. Concurrent protection
changes can invalidate a prior VirtualQuery check.

## Resource-lifetime model

| State | Owner and permitted cleanup |
|---|---|
| Validation | Local buffers only; no remote allocations |
| Before thread creation | RemoteResources records image, two optional support pages, mapping data, code; destructor releases all on failure |
| Thread running | Image/support and scratch storage may be in use; thread handle remains owned by the host |
| Thread signaled | Read exit code/status, free code and parameter scratch; close handle through RAII |
| Initialized | Keep image and support pages until target exit; apply requested protections and report failures |
| Initialization failed after execution | Free scratch only after signal; retain image/support and dependency side effects until target exit |
| Timeout/wait failure | Close the host thread handle, retain all remote storage; do not stop the thread or guess at unload safety |

The model deliberately does not promise rollback or unloading. Registered function
tables, DLL-created state, and imported dependencies can outlive the mapper call.
A failed result can leave a partially initialized image. After timeout there is no
background reclamation owner; process exit is the supported release boundary.

`MappingStatus` distinguishes Pending, Initialized, InvalidData, missing module,
missing symbol, exception-registration failure, unavailable TLS, TLS initialization
failure (reserved), and rejected entrypoint. Remote failures also return a nonzero
thread exit code. The host requires an initialized status, zero thread exit code,
and the expected module base. Failed support writes/allocations are no longer
treated as successful reduced operation. Cleanup/protection failure returns false
even if the entrypoint already succeeded; callers must not blindly retry.

The TLS implementation was stopped at a safety boundary: any TLS directory is
rejected before allocation. The pattern lookup and fake stack loader entry were
removed from active code. This is a mitigation with a documented compatibility
regression, not a repair or validation of static TLS.

## Input, tests, and build integration

`TargetInput.h` provides overflow-safe decimal PID parsing and a first/next process
enumerator used by both production and fixture tests. Process snapshot creation
is checked. Numeric input no longer falls back to process-name lookup. The CLI
requests the process rights used by its APIs and no longer enables SeDebugPrivilege.
Interactive pause calls were removed. The earlier spawn quoting/ResumeThread
checks have been superseded by explicit unsupported-spawn rejection at release.

The solution adds an isolated regression executable and a minimal, reviewed DLL
with a custom entrypoint, no CRT/static TLS, and a deliberate relocation plus
Sleep import. Test children are the same source-built executable in --host mode.
All terminations are restricted to processes created by the fixture. The
INJECTOR_TESTING-only fault hook simulates CreateRemoteThread failure while real
allocations/writes and cleanup execute against the controlled child; it is absent
from the production project. A rights-only fixture had failed to induce that API
failure, and the original failed run is retained in the evidence folder.

`tests/run-tests.ps1` discovers the installed Visual Studio toolchain, builds the
existing solution, records payload/runner hashes, and propagates failures. CI now
executes x64 Release and Debug tests and uploads logs. x86 remains build-only in
CI; no x86 runtime result was obtained locally.

## Exact edited/added files

Paths below are relative to the nested solution directory, except the first:

- `../AGENTS.md` (new workspace-wide instructions).
- `Manual Map Injector/injector.cpp`, `injector.h`, `main.cpp`, `Pattern.h`, `Manual Map Injector.vcxproj`.
- `Manual Map Injector/PeValidation.cpp`, `PeValidation.h`, `TargetInput.h` (new).
- `Manual Map Injector.sln`, `.gitignore`, `.github/workflows/build.yml`, `README.md`.
- `tests/run-tests.ps1` (new).
- `tests/regression/RegressionTests.vcxproj`, `TestPayload.vcxproj`, `regression_tests.cpp`, `test_payload.cpp`, `TestControl.h` (new).
- `docs/INJECTOR_AUDIT.md`, `FIXES.md`, `TEST_RESULTS.md`, `COMPATIBILITY.md`, `PROGRESS.md`, `MODEL_HANDOFF.md` (new).

Generated binaries, compiler logs, provenance records, source backups, build
diagnostic scripts, and the final patch/hash inventory are evidence rather than
additional production source changes. No separate Osiris files or bundled DLLs
were modified by this work.
