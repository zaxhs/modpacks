$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
$package = Join-Path $PSScriptRoot 'extracted-release'
$exe = Join-Path $package 'Injector-x64.exe'
$expected = Get-Content -LiteralPath (Join-Path $package 'BUILD-INFO.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $exe).Hash -ne $expected.ExecutableSHA256) { throw 'Extracted executable hash changed.' }
$start = [Diagnostics.ProcessStartInfo]::new($exe)
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardInput = $true
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$owned = [Diagnostics.Process]::Start($start)
try {
    $runtimeNames = @('msvcp140.dll','vcruntime140.dll','vcruntime140_1.dll')
    $started = [Diagnostics.Stopwatch]::StartNew()
    do {
        $owned.Refresh()
        $modules = @($owned.Modules | Where-Object ModuleName -in $runtimeNames | Select-Object ModuleName,FileName)
        if ($modules.Count -eq 3) { break }
        Start-Sleep -Milliseconds 50
    } while (!$owned.HasExited -and $started.ElapsedMilliseconds -lt 3000)
    if ($modules.Count -ne 3) { throw 'Could not observe all three release runtime modules.' }
    foreach ($module in $modules) {
        if ([IO.Path]::GetDirectoryName($module.FileName) -ne $package) { throw "Runtime was not loaded app-locally: $($module.FileName)" }
    }
    $modules | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'package-runtime-modules.json')
    $owned.StandardInput.Close()
    if (!$owned.WaitForExit(3000) -or $owned.ExitCode) { throw 'Extracted CLI cancellation failed.' }
    $owned.StandardOutput.ReadToEnd() | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'package-console-cancellation.txt')
} finally {
    if (!$owned.HasExited) { $owned.Kill(); $owned.WaitForExit() }
    $owned.Dispose()
}
$previousOverride = $env:INJECTOR_TEST_CLI_PATH
try {
    $env:INJECTOR_TEST_CLI_PATH = $exe
    & (Join-Path $projectRoot 'artifacts\Release\RegressionTests.exe') 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'tests-extracted-package.txt')
    if ($LASTEXITCODE) { throw 'Extracted-package regression failed.' }
} finally { $env:INJECTOR_TEST_CLI_PATH = $previousOverride }
if ((Get-FileHash -LiteralPath $exe).Hash -ne $expected.ExecutableSHA256) { throw 'Tested package executable changed.' }
'PASS: extracted CLI full suite and three observed app-local runtime module paths.' |
    Set-Content -LiteralPath (Join-Path $PSScriptRoot 'package-runtime-result.txt')
