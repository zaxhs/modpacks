# Simple Manual Map Injector — x64 developer release

Extract the complete ZIP into one folder. Run `Injector-x64.exe` from a normal
PowerShell terminal. Administrator privileges are not requested automatically.
Use only reviewed DLL source and your own ordinary Windows x64 test hosts.

## Use

```powershell
.\Injector-x64.exe --help
.\Injector-x64.exe --check "C:\DeveloperTests\OwnedFixture.dll"
.\Injector-x64.exe --list
.\Injector-x64.exe
```

`--check` reads and validates the file without executing DLL code or opening a
target. No-argument mode asks for a DLL path, target PID or unique process name,
and confirmation. Blank input cancels before a target is opened. Prefer a PID
from your own host; duplicate process names are rejected.

For an unattended operation, explicitly supply both arguments:

```powershell
.\Injector-x64.exe "C:\DeveloperTests\OwnedFixture.dll" 12345
```

Replace the example path and PID with your reviewed component and owned host.
No target is selected automatically. `--spawn` is explicitly unsupported; start
the host normally first. A successful operation returns exit code 0. A failure
returns a nonzero code and a diagnostic; interactive cancellation returns 0.

## Supported scope

This release is for reviewed native AMD64 PE32+ DLLs whose source initialization
contract fits manual mapping: bounded headers/sections, ordinary resolvable
imports, supported DIR64 relocations, and version-1 handler-free or bounded
chained unwind records. File and image size are each limited to 512 MiB.
The file must not require TLS, CLR, delay imports, load-config/CFG processing,
language-specific exception handlers, normal loader module registration, or
DLL thread notifications. These advanced loader requirements are unsupported;
detectable TLS/CLR/delay/load-config/CFG/handler cases fail before target work.
Do not remove required security or runtime features merely to pass preflight.
Validation is not a sandbox and cannot infer every source-level requirement.

Only Windows 11 Pro 10.0.26300 on native AMD64 was runtime tested. Windows 10,
other Windows versions, ARM64/emulation, x86, different target mitigations,
and arbitrary third-party DLLs are unverified. Target system modules and API
addresses must pass the explicit cross-process checks and remain stable.

Success confirms that initialization returned successfully. Verify a separate
observable result in your own host for application behavior. After execution
starts, mapped image/support allocations remain until target exit. A timeout
(30 seconds) also retains temporary code/data so a live thread can finish.
Failure may mean partially completed initialization. Close your owned host
before retrying after failure or timeout. There is no general unload, detach,
rollback, or dependency-side-effect reversal. Repeated successful operations
create separate mappings; the application does not deduplicate them.

## Evidence and dependencies

Release and Debug: 144 checks passed in each configuration, preserving all
previous 108 checks. Tests use source-built payloads and owned test children;
production CLI initialization is observed through a target-signaled event.
The extracted package is separately exercised with the Release suite.
Osiris Release metadata was assessed statically; Osiris and CS2 runtime
compatibility and any VAC safety are unverified. No game was used in testing.

Keep the three bundled Microsoft release runtime DLLs beside the executable:
`msvcp140.dll`, `vcruntime140.dll`, `vcruntime140_1.dll`. They come from the
installed Visual Studio 2026 x64 redistributable directory. Windows supplies
KERNEL32 and the Universal CRT. Debug runtimes are not included. App-local
runtime updates require replacing these files from an authorized Microsoft
redistributable source. See `RUNTIME-NOTICE.txt` and `LICENSE`.

`BUILD-INFO.json` identifies the toolchain, tested source manifest hash, and
executable hash. `SOURCE-MANIFEST.json` fingerprints the relevant source/build
inputs; it is a local revision identifier, not a Git commit or a reproducible-
build claim. `SHA256SUMS.txt` fingerprints the other package files. The ZIP
SHA256 is supplied alongside the ZIP. The executable is not code-signed.
