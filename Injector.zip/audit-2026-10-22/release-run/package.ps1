$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
$releaseName = 'Injector-x64-20261022'
$releaseParent = Join-Path $projectRoot 'releases'
$releaseDirectory = Join-Path $releaseParent $releaseName
$zipPath = Join-Path $releaseParent ($releaseName + '.zip')
$extractedDirectory = Join-Path $PSScriptRoot 'extracted-release'
foreach ($path in @($releaseDirectory, $zipPath, $extractedDirectory)) {
    if (Test-Path -LiteralPath $path) { throw "Refusing to overwrite existing release output: $path" }
}
foreach ($configuration in @('Release', 'Debug')) {
    $log = Join-Path $projectRoot "artifacts\tests-$configuration.txt"
    if ((Get-Content -LiteralPath $log | Select-Object -Last 1) -ne 'RESULT: 144 passed, 0 failed') {
        throw "Final $configuration regression result is not present."
    }
}
New-Item -ItemType Directory -Path $releaseDirectory | Out-Null
$inputs = @(
    Get-ChildItem -LiteralPath (Join-Path $projectRoot 'Manual Map Injector') -File | Where-Object Extension -in '.cpp','.h','.vcxproj'
    Get-ChildItem -LiteralPath (Join-Path $projectRoot 'tests\regression') -File | Where-Object Extension -in '.cpp','.h','.vcxproj'
    Get-Item -LiteralPath (Join-Path $projectRoot 'Manual Map Injector.sln'),(Join-Path $projectRoot 'tests\run-tests.ps1')
) | Sort-Object FullName
$sourceManifest = @($inputs | ForEach-Object {
    [ordered]@{ Path = $_.FullName.Substring($projectRoot.Length + 1).Replace('\','/'); SHA256 = (Get-FileHash -LiteralPath $_.FullName).Hash }
})
$manifestPath = Join-Path $releaseDirectory 'SOURCE-MANIFEST.json'
$sourceManifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding utf8
$revision = (Get-FileHash -LiteralPath $manifestPath).Hash
$testedExe = Join-Path $projectRoot 'artifacts\Release\Injector-x64.exe'
Copy-Item -LiteralPath $testedExe -Destination (Join-Path $releaseDirectory 'Injector-x64.exe')
Copy-Item -LiteralPath (Join-Path $projectRoot 'LICENSE') -Destination $releaseDirectory
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'package-README.md') -Destination (Join-Path $releaseDirectory 'README.md')
$redist = 'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Redist\MSVC\14.51.36231\x64\Microsoft.VC145.CRT'
$runtimeRecords = @(foreach ($name in @('msvcp140.dll','vcruntime140.dll','vcruntime140_1.dll')) {
    $runtime = Get-Item -LiteralPath (Join-Path $redist $name)
    Copy-Item -LiteralPath $runtime.FullName -Destination $releaseDirectory
    [ordered]@{ Name = $name; Version = $runtime.VersionInfo.FileVersion; SHA256 = (Get-FileHash -LiteralPath $runtime.FullName).Hash; Copyright = $runtime.VersionInfo.LegalCopyright }
})
@'
The three Microsoft runtime DLLs are Microsoft Corporation components, not
covered by the injector's MIT license. Copied unchanged from the installed
Visual Studio 2026 Community VC/Redist/MSVC/14.51.36231/x64/Microsoft.VC145.CRT
directory for app-local deployment. File versions and hashes are in BUILD-INFO.json.
Use and redistribution remain subject to the applicable Microsoft license terms.
No Windows system DLLs or debug runtimes are included.
Microsoft deployment information:
https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files?view=msvc-170
https://learn.microsoft.com/en-us/cpp/windows/deployment-in-visual-cpp?view=msvc-170
'@ | Set-Content -LiteralPath (Join-Path $releaseDirectory 'RUNTIME-NOTICE.txt') -Encoding utf8
[ordered]@{
    Release = $releaseName
    CreatedUtc = [DateTime]::UtcNow.ToString('o')
    SourceRevisionKind = 'SHA256 of SOURCE-MANIFEST.json; no Git repository'
    SourceRevision = $revision
    ExecutableSHA256 = (Get-FileHash -LiteralPath $testedExe).Hash
    Build = 'tests/run-tests.ps1 -Configuration Both; existing solution, x64 Release /MD'
    Toolset = 'v145'; Compiler = 'MSVC 19.51.36260'; VCToolsDirectoryVersion = '14.51.36231'; WindowsSDK = '10.0.26100.0'
    TestedOS = 'Windows 11 Pro 10.0.26300 native AMD64; unelevated'
    RegressionResults = @{ Release = '144 passed, 0 failed'; Debug = '144 passed, 0 failed' }
    Scope = 'Reviewed native x64 DLLs; see README.md. Osiris/CS2 runtime unverified.'
    RuntimeSource = 'Visual Studio 2026 VC/Redist/MSVC/14.51.36231/x64/Microsoft.VC145.CRT'
    Runtimes = $runtimeRecords
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $releaseDirectory 'BUILD-INFO.json') -Encoding utf8
$files = @(Get-ChildItem -LiteralPath $releaseDirectory -File | Sort-Object Name | ForEach-Object {
    [ordered]@{ Name = $_.Name; SHA256 = (Get-FileHash -LiteralPath $_.FullName).Hash; Length = $_.Length }
})
$files | ForEach-Object { '{0}  {1}' -f $_.SHA256,$_.Name } | Set-Content -LiteralPath (Join-Path $releaseDirectory 'SHA256SUMS.txt') -Encoding utf8
Compress-Archive -Path (Join-Path $releaseDirectory '*') -DestinationPath $zipPath -CompressionLevel Optimal
$expected = @($files) + @([ordered]@{Name='SHA256SUMS.txt';SHA256=(Get-FileHash -LiteralPath (Join-Path $releaseDirectory 'SHA256SUMS.txt')).Hash;Length=(Get-Item -LiteralPath (Join-Path $releaseDirectory 'SHA256SUMS.txt')).Length})
$archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if ($archive.Entries.Count -ne $expected.Count) { throw 'Unexpected ZIP entry count.' }
    foreach ($record in $expected) {
        $entry = $archive.GetEntry($record.Name)
        if (!$entry -or $entry.Length -ne $record.Length) { throw "Missing/changed ZIP entry $($record.Name)" }
        $stream = $entry.Open(); $sha = [Security.Cryptography.SHA256]::Create()
        try { $hash = [Convert]::ToHexString($sha.ComputeHash($stream)) } finally { $stream.Dispose(); $sha.Dispose() }
        if ($hash -ne $record.SHA256) { throw "ZIP hash mismatch: $($record.Name)" }
    }
} finally { $archive.Dispose() }
Expand-Archive -LiteralPath $zipPath -DestinationPath $extractedDirectory
foreach ($record in $expected) {
    if ((Get-FileHash -LiteralPath (Join-Path $extractedDirectory $record.Name)).Hash -ne $record.SHA256) { throw "Extracted hash mismatch: $($record.Name)" }
}
$zipHash = (Get-FileHash -LiteralPath $zipPath).Hash
"$zipHash  $releaseName.zip" | Set-Content -LiteralPath ($zipPath + '.sha256') -Encoding utf8
[ordered]@{ Zip = $zipPath; SHA256 = $zipHash; SourceRevision = $revision; Entries = $expected; ExtractedDirectory = $extractedDirectory; Status = 'ZIP entries and extracted files match source package hashes' } |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'package-verification.json') -Encoding utf8
Write-Output "Package created and hash-verified: $zipPath"
Write-Output "ZIP SHA256: $zipHash"
