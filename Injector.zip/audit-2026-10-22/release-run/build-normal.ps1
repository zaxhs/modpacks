$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
$msbuild = 'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe'
foreach ($configuration in @('Release', 'Debug')) {
    & $msbuild (Join-Path $projectRoot 'Manual Map Injector.sln') /m /t:Rebuild "/p:Configuration=$configuration" /p:Platform=x64 /nologo /verbosity:minimal "/flp:logfile=$PSScriptRoot\normal-$configuration.log;verbosity=normal"
    if ($LASTEXITCODE) { throw "$configuration normal solution build failed." }
}
& $msbuild (Join-Path $projectRoot 'Manual Map Injector\Manual Map Injector.vcxproj') /p:Configuration=Release /p:Platform=x64 /getProperty:PlatformToolset,VCToolsVersion,WindowsTargetPlatformVersion,WindowsSdkDir,OutDir,IntDir | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'build-properties.json')
if ($LASTEXITCODE) { throw 'Build property query failed.' }
Get-Item -LiteralPath 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64\gdi32.lib' | Select-Object FullName,Length | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'sdk-gdi32.json')
