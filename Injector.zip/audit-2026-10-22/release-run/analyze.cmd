@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
rem SDK 10.0.26100.0 consoleapi.h:236 has malformed sizeof(TCHAR%%) SAL.
rem Ignore only the SDK annotation-parser diagnostic for this analysis command.
cl /nologo /W4 /WX /wd28286 /analyze /c /EHsc /std:c++17 /GS- /DUNICODE /D_UNICODE /Fo"main-analysis.obj" "..\..\Manual Map Injector\main.cpp"
if errorlevel 1 exit /b 1
cl /nologo /W4 /WX /analyze /c /EHsc /std:c++17 /GS- /DUNICODE /D_UNICODE /Fo"PeValidation-analysis.obj" "..\..\Manual Map Injector\PeValidation.cpp"
if errorlevel 1 exit /b 1
cl /nologo /W4 /WX /analyze /c /EHsc /std:c++17 /GS- /DUNICODE /D_UNICODE /Fo"injector-analysis.obj" "..\..\Manual Map Injector\injector.cpp"
if errorlevel 1 exit /b 1
cl /nologo /W4 /WX /analyze /c /EHsc /std:c++17 /GS- /DUNICODE /D_UNICODE /Fo"RemoteApi-analysis.obj" "..\..\Manual Map Injector\RemoteApi.cpp"
exit /b %errorlevel%
