# Model handoff — 2026-10-22

The workspace has a nested solution directory. Parent `AGENTS.md` is permanent.
There is no Git history here. Do not clone or replace the tree, modify Osiris,
execute bundled DLLs/games/protected targets, or add evasion. Use GPT-6.1 Sol High
for normal work; no Astra escalation or new chat is needed for the next milestone.

## State and reproduction

Original source: `audit-2026-10-22/repair-run/before/` with starting-state.json.
Earlier audit backups remain untouched. Source/configuration differences and new
file inventory are in FIXES.md and the final audit manifest/patch.

Installed native tools: Visual Studio Community 2026 18.10.12224.181, v145,
MSVC 19.51.36260, Windows SDK 10.0.26100.0. Tested unelevated on Windows 11 Pro
10.0.26300 AMD64. Restricted shell builds showed misleading SDK/PDB/locked-output
errors; native installed-toolchain builds succeeded. No SDK/security settings were
changed. Native MSBuild path:
`C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe`.

PowerShell from the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

Safety milestone: Release 82/0, Debug 82/0. Latest I-05 result: **108/0 in both**,
retaining all 82 checks and adding 26. Normal default-output solution rebuilds
and standard-script builds have zero warnings/errors. Focused /analyze /W4 /WX
passes for new verifier production and test modes after fixing C6387.
The suite takes roughly a minute for both configurations because each includes
a real 30-second timeout. Binaries/logs/hashes are in artifacts/. Earlier milestone
failures and legacy-build evidence are under audit-2026-10-22/repair-run/.
I-05 snapshots, normal build commands/logs, analysis, tests, and SDK clarification
are under audit-2026-10-22/i05-run/. gdi32.lib exists in the installed SDK and both
execution views now; no SDK/toolset retargeting or persistent detection workaround
is needed. The exact historical transient visibility/locking cause is unproven;
see TEST_RESULTS.md rather than repeating a claim that the machine lacked the SDK.
The legacy TLS project fails with missing v143, builds unchanged with /p:PlatformToolset=v145.
All reviewed legacy C++ sources compile; /EHc variants emit C4297. None was run.

## Implementation contracts

ManualMapDll now requires sourceSize in argument three. ClearHeader and
ClearNonNeededSections default false; true explicitly fails. Only attach is
accepted. TLS directories always fail before allocation, regardless of TLSSupport.
The former pattern-resolved ntdll call and stack fake loader entry are removed
from active code. Do not silently skip TLS or restore the gate to pass a test.

PeValidation.cpp checks file/image bounds, headers, sections, nested imports and
relocations, metadata aliasing, TLS structure, and exception table record bounds.
It does not comprehensively validate nested unwind/language/load-config metadata
or all STL allocation failures. Input buffers must be readable and unchanged.

RemoteResources releases recorded allocations before thread creation. After the
thread starts, image/support allocations live until target exit. Scratch is freed
only after the thread handle signals. Timeout keeps all storage; never blindly
free it, terminate an existing target, or retry assuming nothing initialized.
There is no general rollback/unload/detach implementation. Function-table and
dependency side effects can persist. Protection/cleanup failure also returns false
after successful entry; false therefore does not mean no code ran.

MappingStatus plus thread exit code reports initialization results. `.mmap$a` and
`.mmap$z` delimit copied code; recheck generated instructions if changing compiler,
optimization, runtime checks, or remote function contents. The production CLI is
tested independently of the mapper compiled into RegressionTests.

The INJECTOR_TESTING fault variable exists only in the regression build. A prior
test attempted to deny CreateRemoteThread with handle rights but still created
a thread on this host, yielding a genuine failing resource assertion. It was
replaced by explicit API-failure simulation with real remote allocation cleanup;
do not remove that assertion or mislabel the old run as an injector leak.

## I-05 contracts and completion

I-05 is completed as a checked precondition, not a loader rewrite. RemoteApi.cpp
resolves local addresses, verifies native AMD64/matching process machines using
IsWow64Process2, enumerates target modules, and checks the actual local owner's
path/base/PE identity, independently read target direct-export RVA, and committed
executable MEM_IMAGE memory. The full five-pointer/caller trace is in FIXES.md.
The output bundle stays entirely null on failure; diagnostics name API/stage,
reason, and Win32 error. ManualMapDll invokes this before its first allocation.
Both LoadLibraryA and GetProcAddress are required; RtlAddFunctionTable,
RaiseException, and RtlPcToFileHeader are required only with x64 exception support.
Both addresses embedded in existing stubs now come from that verified bundle.

Actual owners may be kernel32, KernelBase, or ntdll; never hardcode a universal
owner based on one Windows build. Local standard forwarding is allowed to resolve
the actual owner; another forwarder in that owner, a different base, identity,
path, missing export, read/query error, or unsupported architecture fails closed.
Snapshot ERROR_BAD_LENGTH retries are bounded. No remote base translation or
forwarder resolution was added. Module checks do not authenticate code and are
not atomic against concurrent target remapping; use stable owned developer hosts.
lpReserved is still an opaque target address supplied by the caller, not a local
pointer to reinterpret automatically. Remote-allocated pointers and dependency
exports obtained inside the target retain their existing contracts.

INJECTOR_TESTING-only RemoteApiTestFault hooks alter API results or observation
copies, never target system modules. Tests cover useful diagnostics, all-null
outputs, zero remote side effects, balanced handles, optional APIs, actual denied
read access, invalid handles, and exited owned processes. Production has no fault
controls. No codegen or shellcode-body changes were made for I-05.

No next coding task is essential for the current controlled no-TLS goals.
**Recommend pausing injector development.** Resume for a concrete observed
failure/new requirement, not speculative TLS/EH/unload expansion. Existing deeper
PE, TLS, general EH, ownership/rollback, and Windows-version limits remain recorded
without turning them into automatic new work. No Astra blocker was found.

Static Osiris assessment is conditional on the supplied older report only. No
current source/binary/hash exists here to establish its actual TLS, entrypoint,
unwind, initialization, or shutdown needs. There is no VAC/CS2 runtime result.
