# Simple Manual Map Injector

Windows native C++ manual mapping study project. Current safety work targets
Windows 10/11 AMD64 using the existing Visual Studio solution and v145 toolset.
The original source is preserved in `audit-2026-10-22/repair-run/before/`.

## Current behavior

The mapper validates file length, PE headers, section bounds, imports,
relocations, TLS structure, and exception-table record bounds before allocation.
It preserves PE metadata, waits for actual thread termination, and checks
initialization status instead of treating a published pointer as success.

**TLS-bearing DLLs are currently rejected.** The previous undocumented
`LdrpHandleTlsData` integration has an unresolved loader-entry lifetime contract.
The gate also applies when `TLSSupport=false`; skipping TLS cannot imply success.

Metadata-erasure options default to false. Explicit requests to clear headers or
sections fail before allocation. `ManualMapDll` now requires a source length;
update custom callers. Attach is the only accepted reason.

After execution starts, image and support pages remain until target exit. On a
timeout, temporary code and parameters also remain because they may still be in
use. There is no general verified detach/unload operation. Successful attach
does not prove that all DLL functionality works.

## Build and isolated tests

Use PowerShell with an installed Visual Studio C++ v145 toolchain and Windows SDK:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

This builds the existing solution into `artifacts/Release` and `artifacts/Debug`,
then runs reviewed source-built tests against their own ordinary Windows child
processes. Each configuration includes a 30-second timeout case. Logs and binary
hashes are stored under `artifacts/`. Bundled precompiled DLLs are not executed.
Legacy examples remain in `tests/`; compiling them is not a runtime test result.

## Existing command line

`Injector-x64.exe dll_path [target]` accepts a process name or decimal PID in
1..4294967295. Numeric overflow is rejected without falling back to a name.
The CLI requests specific process rights and does not enable SeDebugPrivilege.
Use only developer-owned ordinary test applications.

`Injector-x64.exe --spawn dll_path exe_path` remains available, but its suspended
startup path is not covered by this runtime suite. It is not a verified workaround
for loader or TLS issues. Error paths return without interactive pause commands.

## Evidence and limitations

See [verified audit](docs/INJECTOR_AUDIT.md), [changes](docs/FIXES.md),
[actual results](docs/TEST_RESULTS.md), [compatibility](docs/COMPATIBILITY.md),
[progress](docs/PROGRESS.md), and [handoff](docs/MODEL_HANDOFF.md).

Cross-process Windows API address reuse now requires explicit target module,
export, architecture, and executable-page verification; mismatches fail before
allocation. The check requires stable target modules and does not authenticate
code bytes. Full C++ EH,
all unwind metadata, arbitrary DLLs, every Windows version, and general unload
are not verified. Validation is not a sandbox for executable DLL code.
This work establishes neither VAC safety nor Osiris/CS2 runtime compatibility.

The previous README attributed bundled Hello World samples to
[carterjones/hello-world-dll](https://github.com/carterjones/hello-world-dll).
Their binary provenance was not independently established here. The license remains.
