# Project instructions

Reply in Swedish unless the user writes in English or asks for another language.
Use concrete, natural language and distinguish source/build evidence from runtime evidence.

The solution is in `Simple-Manual-Map-Injector-master/Manual Map Injector.sln`.
This is a Windows native C++ project. Windows 10/11 AMD64 is the primary scope;
do not promise ARM64, Linux, Proton, or Win32 runtime support from x64 tests.
Prefer the installed Visual Studio v145 toolchain and Windows SDK. Do not clone,
replace, or broadly refactor the project. Keep local naming, tabs, and Win32 APIs.
Preserve an inspectable source baseline and a hash/diff before substantial changes.
This checkout has no Git history; see the audit folder and docs for snapshots.

Read `docs/PROGRESS.md`, `docs/TEST_RESULTS.md`, and `docs/MODEL_HANDOFF.md` inside
the nested project before continuing. Keep documentation consistent with current code.
Changes to the ManualMapDll signature require updating every caller and test.

Only execute reviewed, source-built regression binaries and their owned ordinary
Windows child processes. Use `tests/run-tests.ps1` in PowerShell for x64 Release
and Debug. Do not execute bundled precompiled DLLs, games, CS2, or protected targets.
Do not modify Osiris, disable security software, add exclusions, or add anti-cheat
bypasses, hiding, metadata erasure, or detection-evasion features.

PE validation is not a sandbox for DLL code. Preserve PE metadata. TLS-bearing
images currently fail closed because the previous undocumented loader-entry
lifetime has not been established. Do not remove this gate to obtain green tests.
Never free remote code or parameters while its thread might still execute.
After execution starts, registered/image/support storage may need to survive until
process exit, including on failure; do not claim general unload/rollback support.
Fault-injection hooks must be test-only and absent from production builds.

Build and run relevant regression tests after each coherent milestone. Record
failures and their causes; never disable tests merely to pass. Obtain compiler
versions and exact commands from the actual toolchain. Test provenance, hashes,
and compilation do not establish runtime compatibility with another project.

Use GPT-6.1 Sol High for normal work; stay in the current chat unless asked to
create another. Avoid redundant investigations and unsolicited sub-agents.
Use Extra High only for a specific difficult ownership/internals question.
Before proposing Astra, write the precise unresolved question, files/functions,
investigations, failed approaches, and narrow task into the handoff. If Astra is
authorized, require persistent detailed notes. Never claim a model change that
was not actually made.
