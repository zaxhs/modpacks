#include "injector.h"
#include "PeValidation.h"
#include <vector>
#ifdef INJECTOR_TESTING
extern bool InjectorTestFailThreadCreation;
#endif

namespace {
// Before execution these allocations are exclusively host-owned. Once a remote
// thread starts, the image and support pages may be referenced by Windows or DLL
// code. They must survive success, failure, and timeout until target exit.
struct RemoteResources {
	HANDLE process;
	std::vector<void*> allocations;
	bool executionStarted = false;
	explicit RemoteResources(HANDLE handle) : process(handle) { allocations.reserve(5); }
	void* allocate(size_t size, DWORD protection) {
		void* address = VirtualAllocEx(process, nullptr, size, MEM_COMMIT | MEM_RESERVE, protection);
		if (address) allocations.push_back(address);
		return address;
	}
	~RemoteResources() {
		if (!executionStarted) for (void* address : allocations)
			VirtualFreeEx(process, address, 0, MEM_RELEASE);
	}
};
struct ThreadHandle {
	HANDLE value;
	~ThreadHandle() { if (value) CloseHandle(value); }
};
}

#if defined(DISABLE_OUTPUT)
#define ILog(data, ...)
#else
#define ILog(text, ...) printf(text, ##__VA_ARGS__);
#endif

#ifdef _WIN64
#define CURRENT_ARCH IMAGE_FILE_MACHINE_AMD64
#else
#define CURRENT_ARCH IMAGE_FILE_MACHINE_I386
#endif

bool ManualMapDll(HANDLE hProc, BYTE* pSrcData, size_t sourceSize, bool ClearHeader, bool ClearNonNeededSections, bool AdjustProtections, bool SEHExceptionSupport, bool TLSSupport, DWORD fdwReason, LPVOID lpReserved) {
	IMAGE_NT_HEADERS* pOldNtHeader = nullptr;
	IMAGE_OPTIONAL_HEADER* pOldOptHeader = nullptr;
	IMAGE_FILE_HEADER* pOldFileHeader = nullptr;
	BYTE* pTargetBase = nullptr;

	std::string validationError;
	if (!ValidatePeImage(pSrcData, sourceSize, validationError)) {
		ILog("Invalid PE: %s\n", validationError.c_str());
		return false;
	}
	if (!hProc || hProc == INVALID_HANDLE_VALUE || ClearHeader || ClearNonNeededSections || fdwReason != DLL_PROCESS_ATTACH) {
		ILog("Invalid process handle, destructive cleanup request, or unsupported reason (attach only)\n");
		return false;
	}

	pOldNtHeader = reinterpret_cast<IMAGE_NT_HEADERS*>(pSrcData + reinterpret_cast<IMAGE_DOS_HEADER*>(pSrcData)->e_lfanew);
	pOldOptHeader = &pOldNtHeader->OptionalHeader;
	pOldFileHeader = &pOldNtHeader->FileHeader;

	if (pOldFileHeader->Machine != CURRENT_ARCH) {
		ILog("Invalid platform\n");
		return false;
	}

	ILog("File ok\n");

	if (pOldOptHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size) {
		ILog("TLS mapping is blocked pending validation of the undocumented loader-entry lifetime\n");
		return false;
	}
	RemoteResources resources(hProc);
	pTargetBase = reinterpret_cast<BYTE*>(resources.allocate(pOldOptHeader->SizeOfImage, PAGE_READWRITE));
	if (!pTargetBase) {
		ILog("Target process memory allocation failed (ex) 0x%X\n", GetLastError());
		return false;
	}

	DWORD oldp = 0;
	if (!VirtualProtectEx(hProc, pTargetBase, pOldOptHeader->SizeOfImage, PAGE_EXECUTE_READWRITE, &oldp)) {
		ILog("Cannot set initial image protection: 0x%lX\n", GetLastError());
		return false;
	}
	if (!pOldOptHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size &&
		reinterpret_cast<ULONG_PTR>(pTargetBase) != pOldOptHeader->ImageBase) {
		ILog("Image requires its preferred base and has no relocations\n");
		return false;
	}

	MANUAL_MAPPING_DATA data{ 0 };
	data.pLoadLibraryA   = LoadLibraryA;
	data.pGetProcAddress = GetProcAddress;
#ifdef _WIN64
	data.pRtlAddFunctionTable = (f_RtlAddFunctionTable)RtlAddFunctionTable;

#else
	SEHExceptionSupport = false;
#endif
	data.pbase = pTargetBase;
	data.fdwReasonParam = fdwReason;
	data.reservedParam = lpReserved;
	data.SEHSupport = SEHExceptionSupport;
	data.TLSSupport = TLSSupport;

#ifdef _WIN64
	// Build the _CxxThrowException replacement stub. x64 calling convention:
	// rcx = exception object, rdx = ThrowInfo*. We assemble a 4-slot params
	// array on the stack and call RaiseException with our correct ImageBase
	// in slot 3 — that's the bit the original _CxxThrowException can't fill
	// in for a manually-mapped DLL, because RtlPcToFileHeader can't find us.
	data.pCxxThrowStub = nullptr;
	if (SEHExceptionSupport) {
		HMODULE hK32 = GetModuleHandleW(L"kernel32.dll");
		FARPROC pRaiseEx = hK32 ? GetProcAddress(hK32, "RaiseException") : nullptr;
		void* stubMem = pRaiseEx
			? resources.allocate(0x1000, PAGE_EXECUTE_READWRITE)
			: nullptr;

		if (!stubMem) {
			ILog("Cannot allocate requested exception support\n");
			return false;
		} else {
			// One page in the target holds three things:
			//   offset 0x000: stub code         (79 bytes)
			//   offset 0x080: UNWIND_INFO       (8 bytes)
			//   offset 0x0A0: RUNTIME_FUNCTION  (12 bytes)
			// The shellcode then RtlAddFunctionTable's the RUNTIME_FUNCTION so
			// the OS unwinder can walk past the stub's frame when looking for
			// a C++ EH handler in the caller.
			BYTE blob[0xB0] = {};
			BYTE stub[] = {
				0x48, 0x83, 0xEC, 0x48,                                  // sub  rsp, 0x48
				0xC7, 0x44, 0x24, 0x20, 0x20, 0x05, 0x93, 0x19,          // mov  [rsp+0x20], 0x19930520 (EH_MAGIC_NUMBER1)
				0xC7, 0x44, 0x24, 0x24, 0x00, 0x00, 0x00, 0x00,          // mov  [rsp+0x24], 0
				0x48, 0x89, 0x4C, 0x24, 0x28,                            // mov  [rsp+0x28], rcx ; obj
				0x48, 0x89, 0x54, 0x24, 0x30,                            // mov  [rsp+0x30], rdx ; ThrowInfo
				0x48, 0xB8, 0,0,0,0,0,0,0,0,                             // movabs rax, IMAGE_BASE  (patched at offset 32)
				0x48, 0x89, 0x44, 0x24, 0x38,                            // mov  [rsp+0x38], rax  ; param[3]
				0xB9, 0x63, 0x73, 0x6D, 0xE0,                            // mov  ecx, 0xE06D7363
				0xBA, 0x01, 0x00, 0x00, 0x00,                            // mov  edx, 1 (NONCONTINUABLE)
				0x41, 0xB8, 0x04, 0x00, 0x00, 0x00,                      // mov  r8d, 4
				0x4C, 0x8D, 0x4C, 0x24, 0x20,                            // lea  r9, [rsp+0x20]
				0x48, 0xB8, 0,0,0,0,0,0,0,0,                             // movabs rax, RaiseException (patched at offset 68)
				0xFF, 0xD0,                                              // call rax
				0xCC,                                                    // int3 (never reached)
			};
			ULONG_PTR imageBase = (ULONG_PTR)pTargetBase;
			ULONG_PTR raiseExceptionAddr = (ULONG_PTR)pRaiseEx;
			memcpy(stub + 32, &imageBase, 8);
			memcpy(stub + 68, &raiseExceptionAddr, 8);
			memcpy(blob, stub, sizeof(stub));

			// UNWIND_INFO at offset 0x80:
			//   Version=1 Flags=0 | SizeOfProlog=4 | CountOfCodes=1 | FrameRegister=0
			//   UnwindCode: { CodeOffset=4, UnwindOp=UWOP_ALLOC_SMALL(2), OpInfo=(0x48/8)-1=8 }
			blob[0x80] = 0x01;        // Version 1, flags 0
			blob[0x81] = 0x04;        // SizeOfProlog (sub rsp, 0x48 is 4 bytes)
			blob[0x82] = 0x01;        // CountOfCodes
			blob[0x83] = 0x00;        // FrameRegister/FrameOffset
			blob[0x84] = 0x04;        // CodeOffset
			blob[0x85] = 0x82;        // (OpInfo=8 << 4) | UWOP_ALLOC_SMALL(2)

			// RUNTIME_FUNCTION at offset 0xA0: { BeginAddr, EndAddr, UnwindData } as RVAs from stubMem.
			DWORD beginAddr = 0;
			DWORD endAddr   = (DWORD)sizeof(stub);
			DWORD unwindRva = 0x80;
			memcpy(blob + 0xA0, &beginAddr, 4);
			memcpy(blob + 0xA4, &endAddr,   4);
			memcpy(blob + 0xA8, &unwindRva, 4);

			if (WriteProcessMemory(hProc, stubMem, blob, sizeof(blob), nullptr)) {
				data.pCxxThrowStub = stubMem;
			} else {
				ILog("Cannot write requested exception support\n");
				return false;
			}
		}

		// RtlPcToFileHeader trampoline
		HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
		FARPROC pOrigRtlPc = hNtdll ? GetProcAddress(hNtdll, "RtlPcToFileHeader") : nullptr;
		if (!pOrigRtlPc) return false;
		if (pOrigRtlPc) {
			void* trMem = resources.allocate(0x1000, PAGE_EXECUTE_READWRITE);
			if (!trMem) return false;
			if (trMem) {
				BYTE tr[0x40] = {};
				BYTE code[] = {
					0x48, 0xB8, 0,0,0,0,0,0,0,0,     // movabs rax, pBase
					0x48, 0x39, 0xC1,                 // cmp rcx, rax
					0x72, 0x18,                       // jb +24
					0x49, 0xB8, 0,0,0,0,0,0,0,0,     // movabs r8, pBase_end
					0x4C, 0x39, 0xC1,                 // cmp rcx, r8
					0x73, 0x09,                       // jae +9
					0x48, 0x85, 0xD2,                 // test rdx, rdx
					0x74, 0x03,                       // jz +3
					0x48, 0x89, 0x02,                 // mov [rdx], rax
					0xC3,                             // ret
					// not_ours:
					0x48, 0xB8, 0,0,0,0,0,0,0,0,     // movabs rax, pOrigRtlPc
					0xFF, 0xE0                        // jmp rax
				};
				ULONG_PTR imgBase = (ULONG_PTR)pTargetBase;
				ULONG_PTR imgEnd  = imgBase + pOldOptHeader->SizeOfImage;
				ULONG_PTR origAddr = (ULONG_PTR)pOrigRtlPc;
				memcpy(code + 2,    &imgBase, 8);   // pBase inside movabs rax
				memcpy(code + 0x11, &imgEnd,  8);   // pBase_end inside movabs r8
				memcpy(code + 0x29, &origAddr, 8);  // original inside movabs rax
				memcpy(tr, code, sizeof(code));

				if (WriteProcessMemory(hProc, trMem, tr, sizeof(tr), nullptr)) {
					data.pRtlPcTrampoline = trMem;
				} else {
					ILog("Cannot write requested exception trampoline\n");
					return false;
				}
			}
		}
	}
#endif


	//File header
	if (!WriteProcessMemory(hProc, pTargetBase, pSrcData, pOldOptHeader->SizeOfHeaders, nullptr)) {
		ILog("Can't write file header 0x%X\n", GetLastError());
		return false;
	}

	IMAGE_SECTION_HEADER* pSectionHeader = IMAGE_FIRST_SECTION(pOldNtHeader);
	for (UINT i = 0; i != pOldFileHeader->NumberOfSections; ++i, ++pSectionHeader) {
		if (pSectionHeader->SizeOfRawData) {
			if (!WriteProcessMemory(hProc, pTargetBase + pSectionHeader->VirtualAddress, pSrcData + pSectionHeader->PointerToRawData, pSectionHeader->SizeOfRawData, nullptr)) {
				ILog("Can't map sections: 0x%x\n", GetLastError());
				return false;
			}
		}
	}

	//Mapping params
	BYTE* MappingDataAlloc = reinterpret_cast<BYTE*>(resources.allocate(sizeof(MANUAL_MAPPING_DATA), PAGE_READWRITE));
	if (!MappingDataAlloc) {
		ILog("Target process mapping allocation failed (ex) 0x%X\n", GetLastError());
		return false;
	}

	if (!WriteProcessMemory(hProc, MappingDataAlloc, &data, sizeof(MANUAL_MAPPING_DATA), nullptr)) {
		ILog("Can't write mapping 0x%X\n", GetLastError());
		return false;
	}

	//Shell code
	const auto shellcodeBegin = reinterpret_cast<ULONG_PTR>(&Shellcode);
	const auto shellcodeEnd = reinterpret_cast<ULONG_PTR>(&ShellcodeEnd);
	if (shellcodeEnd <= shellcodeBegin || shellcodeEnd - shellcodeBegin > 0x10000) {
		ILog("Invalid compiled shellcode extent\n");
		return false;
	}
	const size_t shellcodeSize = shellcodeEnd - shellcodeBegin;
	void* pShellcode = resources.allocate(shellcodeSize, PAGE_EXECUTE_READWRITE);
	if (!pShellcode) {
		ILog("Memory shellcode allocation failed (ex) 0x%X\n", GetLastError());
		return false;
	}

	if (!WriteProcessMemory(hProc, pShellcode, reinterpret_cast<const void*>(shellcodeBegin), shellcodeSize, nullptr)) {
		ILog("Can't write shellcode 0x%X\n", GetLastError());
		return false;
	}
	if (!FlushInstructionCache(hProc, nullptr, 0)) {
		ILog("Instruction-cache flush failed: 0x%lX\n", GetLastError());
		return false;
	}

	ILog("Mapped DLL at %p\n", pTargetBase);
	ILog("Mapping info at %p\n", MappingDataAlloc);
	ILog("Shell code at %p\n", pShellcode);

	ILog("Data allocated\n");

	HANDLE hThread = nullptr;
#ifdef INJECTOR_TESTING
	if (InjectorTestFailThreadCreation) SetLastError(ERROR_ACCESS_DENIED);
	else
#endif
		hThread = CreateRemoteThread(hProc, nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(pShellcode), MappingDataAlloc, 0, nullptr);
	if (!hThread) {
		ILog("Thread creation failed 0x%X\n", GetLastError());
		return false;
	}
	resources.executionStarted = true;
	ThreadHandle thread{hThread};

	ILog("Thread created at: %p, waiting for return...\n", pShellcode);

	const DWORD kInjectTimeoutMs = 30000;
	const DWORD waited = WaitForSingleObject(hThread, kInjectTimeoutMs);
	if (waited != WAIT_OBJECT_0) {
		ILog("Remote thread did not stop (wait=0x%lX error=0x%lX). Allocations retained until target exit.\n", waited, GetLastError());
		return false;
	}
	DWORD threadExit = 0;
	MANUAL_MAPPING_DATA result{};
	const bool gotResult = GetExitCodeThread(hThread, &threadExit) &&
		ReadProcessMemory(hProc, MappingDataAlloc, &result, sizeof(result), nullptr);
	bool cleaned = true;
	if (!VirtualFreeEx(hProc, pShellcode, 0, MEM_RELEASE)) cleaned = false;
	if (!VirtualFreeEx(hProc, MappingDataAlloc, 0, MEM_RELEASE)) cleaned = false;
	if (!gotResult || threadExit != 0 || result.status != static_cast<DWORD>(MappingStatus::Initialized) ||
		result.hMod != reinterpret_cast<HINSTANCE>(pTargetBase)) {
		ILog("Initialization failed: status=%lu threadExit=0x%lX resultRead=%d. Image/support retained until target exit.\n", result.status, threadExit, gotResult);
		return false;
	}

	if (AdjustProtections) {
		pSectionHeader = IMAGE_FIRST_SECTION(pOldNtHeader);
		for (UINT i = 0; i != pOldFileHeader->NumberOfSections; ++i, ++pSectionHeader) {
			if (pSectionHeader->Misc.VirtualSize) {
				DWORD old = 0;
				DWORD newP = PAGE_READONLY;

				if ((pSectionHeader->Characteristics & (IMAGE_SCN_MEM_WRITE | IMAGE_SCN_MEM_EXECUTE)) ==
					(IMAGE_SCN_MEM_WRITE | IMAGE_SCN_MEM_EXECUTE)) {
					newP = PAGE_EXECUTE_READWRITE;
				}
				else if ((pSectionHeader->Characteristics & IMAGE_SCN_MEM_WRITE) > 0) {
					newP = PAGE_READWRITE;
				}
				else if ((pSectionHeader->Characteristics & IMAGE_SCN_MEM_EXECUTE) > 0) {
					newP = PAGE_EXECUTE_READ;
				}
				if (VirtualProtectEx(hProc, pTargetBase + pSectionHeader->VirtualAddress, pSectionHeader->Misc.VirtualSize, newP, &old)) {
					ILog("section %.8s set as %lX\n", (char*)pSectionHeader->Name, newP);
				}
				else {
					ILog("FAIL: section %.8s not set as %lX\n", (char*)pSectionHeader->Name, newP);
					cleaned = false;
				}
			}
		}
		DWORD old = 0;
		if (!VirtualProtectEx(hProc, pTargetBase, pOldOptHeader->SizeOfHeaders, PAGE_READONLY, &old)) cleaned = false;
	}

	if (!cleaned) ILog("Initialization completed, but protection/temporary-allocation cleanup failed\n");
	return cleaned;
}

#define RELOC_FLAG32(RelInfo) ((RelInfo >> 0x0C) == IMAGE_REL_BASED_HIGHLOW)
#define RELOC_FLAG64(RelInfo) ((RelInfo >> 0x0C) == IMAGE_REL_BASED_DIR64)

#ifdef _WIN64
#define RELOC_FLAG RELOC_FLAG64
#else
#define RELOC_FLAG RELOC_FLAG32
#endif

#if defined(__clang__)
#pragma clang optimize off
#else
#pragma runtime_checks( "", off )
#pragma optimize( "", off )
#endif

// Ordered sections give a measured code extent instead of a fixed 4 KiB read.
#pragma code_seg(push, ".mmap$a")
__declspec(safebuffers) __declspec(noinline)
DWORD WINAPI Shellcode(LPVOID parameter) {
	auto* pData = static_cast<MANUAL_MAPPING_DATA*>(parameter);
	if (!pData) {
		return static_cast<DWORD>(MappingStatus::InvalidData);
	}

	BYTE* pBase = pData->pbase;
	auto* pOpt = &reinterpret_cast<IMAGE_NT_HEADERS*>(pBase + reinterpret_cast<IMAGE_DOS_HEADER*>((uintptr_t)pBase)->e_lfanew)->OptionalHeader;

	auto _LoadLibraryA = pData->pLoadLibraryA;
	auto _GetProcAddress = pData->pGetProcAddress;
#ifdef _WIN64
	auto _RtlAddFunctionTable = pData->pRtlAddFunctionTable;
#endif
	auto _DllMain = reinterpret_cast<f_DLL_ENTRY_POINT>(pBase + pOpt->AddressOfEntryPoint);

	ULONG_PTR LocationDelta = reinterpret_cast<ULONG_PTR>(pBase) - pOpt->ImageBase;
	if (LocationDelta) {
		if (pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size) {
			auto* pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(pBase + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress);
			const auto* pRelocEnd = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<uintptr_t>(pRelocData) + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size);
			while (pRelocData < pRelocEnd && pRelocData->SizeOfBlock) {
				UINT AmountOfEntries = (pRelocData->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
				WORD* pRelativeInfo = reinterpret_cast<WORD*>(pRelocData + 1);

				for (UINT i = 0; i != AmountOfEntries; ++i, ++pRelativeInfo) {
					if (RELOC_FLAG(*pRelativeInfo)) {
						UINT_PTR* pPatch = reinterpret_cast<UINT_PTR*>(pBase + pRelocData->VirtualAddress + ((*pRelativeInfo) & 0xFFF));
						*pPatch += LocationDelta;
					}
				}
				pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<BYTE*>(pRelocData) + pRelocData->SizeOfBlock);
			}
		}
	}

	if (pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size) {
		auto* pImportDescr = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(pBase + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
		while (pImportDescr->Name) {
			char* szMod = reinterpret_cast<char*>(pBase + pImportDescr->Name);
			HINSTANCE hDll = _LoadLibraryA(szMod);
			if (!hDll) {
				pData->status = static_cast<DWORD>(MappingStatus::ImportModuleFailed);
				return pData->status;
			}

			ULONG_PTR* pThunkRef = reinterpret_cast<ULONG_PTR*>(pBase + pImportDescr->OriginalFirstThunk);
			ULONG_PTR* pFuncRef = reinterpret_cast<ULONG_PTR*>(pBase + pImportDescr->FirstThunk);

			if (!pImportDescr->OriginalFirstThunk)
				pThunkRef = pFuncRef;

			for (; *pThunkRef; ++pThunkRef, ++pFuncRef) {
				if (IMAGE_SNAP_BY_ORDINAL(*pThunkRef)) {
					*pFuncRef = (ULONG_PTR)_GetProcAddress(hDll, reinterpret_cast<char*>(*pThunkRef & 0xFFFF));
				}
				else {
					auto* pImport = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(pBase + (*pThunkRef));
#ifdef _WIN64
					// Detect "_CxxThrowException" by name (char-by-char to avoid
					// referencing string literals from the injector's .rdata).
					const char* n = pImport->Name;
					bool isCxxThrow =
						pData->pCxxThrowStub &&
						n[0] == '_' && n[1] == 'C' && n[2] == 'x' && n[3] == 'x' &&
						n[4] == 'T' && n[5] == 'h' && n[6] == 'r' && n[7] == 'o' &&
						n[8] == 'w' && n[9] == 'E' && n[10] == 'x' && n[11] == 'c' &&
						n[12] == 'e' && n[13] == 'p' && n[14] == 't' && n[15] == 'i' &&
						n[16] == 'o' && n[17] == 'n' && n[18] == '\0';
					// Detect "RtlPcToFileHeader" by name. Routing it through
					// our trampoline makes /MT's static _CxxThrowException
					// see our pBase as the ImageBase, so RTTI-based catch
					// works the same way as under /MD.
					bool isRtlPc =
						pData->pRtlPcTrampoline &&
						n[0] == 'R' && n[1] == 't' && n[2] == 'l' && n[3] == 'P' &&
						n[4] == 'c' && n[5] == 'T' && n[6] == 'o' && n[7] == 'F' &&
						n[8] == 'i' && n[9] == 'l' && n[10] == 'e' && n[11] == 'H' &&
						n[12] == 'e' && n[13] == 'a' && n[14] == 'd' && n[15] == 'e' &&
						n[16] == 'r' && n[17] == '\0';
					if (isCxxThrow) {
						*pFuncRef = (ULONG_PTR)pData->pCxxThrowStub;
					} else if (isRtlPc) {
						*pFuncRef = (ULONG_PTR)pData->pRtlPcTrampoline;
					} else
#endif
					{
						*pFuncRef = (ULONG_PTR)_GetProcAddress(hDll, pImport->Name);
					}
				}
				if (!*pFuncRef) {
					pData->status = static_cast<DWORD>(MappingStatus::ImportSymbolFailed);
					return pData->status;
				}
			}
			++pImportDescr;
		}
	}

	// --- .pdata registration (DLL's unwind info) -----------------------
	// Must happen BEFORE any DLL code runs, so that C++ exceptions thrown
	// from TLS callbacks (which execute first) find valid handlers.
	bool EarlyEHRegFailed = false;
#ifdef _WIN64
	if (pData->SEHSupport) {
		auto excep0 = pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
		if (excep0.Size) {
			if (!_RtlAddFunctionTable(
				reinterpret_cast<IMAGE_RUNTIME_FUNCTION_ENTRY*>(pBase + excep0.VirtualAddress),
				excep0.Size / sizeof(IMAGE_RUNTIME_FUNCTION_ENTRY), (DWORD64)pBase)) {
				EarlyEHRegFailed = true;
			}
		}
		// Also register the CxxThrowException stub's RUNTIME_FUNCTION
		// (same reason: it can fire from the very first TLS callback).
		if (pData->pCxxThrowStub) {
			BYTE* stubBase = static_cast<BYTE*>(pData->pCxxThrowStub);
			if (!_RtlAddFunctionTable(
				reinterpret_cast<IMAGE_RUNTIME_FUNCTION_ENTRY*>(stubBase + 0xA0),
				1, (DWORD64)stubBase)) EarlyEHRegFailed = true;
		}
	}
#endif
	if (EarlyEHRegFailed) {
		pData->status = static_cast<DWORD>(MappingStatus::ExceptionRegistrationFailed);
		return pData->status;
	}

	if (pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size) {
		pData->status = static_cast<DWORD>(MappingStatus::TlsUnavailable);
		return pData->status;
	}

	if (pOpt->AddressOfEntryPoint && !_DllMain(pBase, pData->fdwReasonParam, pData->reservedParam)) {
		pData->status = static_cast<DWORD>(MappingStatus::EntryPointFailed);
		return pData->status;
	}
	pData->hMod = reinterpret_cast<HINSTANCE>(pBase);
	pData->status = static_cast<DWORD>(MappingStatus::Initialized);
	return 0;
}
#pragma code_seg(pop)
#pragma code_seg(push, ".mmap$z")
__declspec(noinline) void ShellcodeEnd() {}
#pragma code_seg(pop)

#if defined(__clang__)
#pragma clang optimize on
#else
#pragma optimize( "", on )
#pragma runtime_checks( "", restore )
#endif
