#include "injector.h"
#include "TargetInput.h"
#include <limits>
#include <new>
#include <memory>


#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

bool IsCorrectTargetArchitecture(HANDLE hProc) {
	BOOL bTarget = FALSE;
	if (!IsWow64Process(hProc, &bTarget)) {
		printf("Can't confirm target process architecture: 0x%X\n", GetLastError());
		return false;
	}

	BOOL bHost = FALSE;
	if (!IsWow64Process(GetCurrentProcess(), &bHost)) return false;

	return (bTarget == bHost);
}

DWORD GetProcessIdByName(wchar_t* name) {
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (snapshot == INVALID_HANDLE_VALUE) {
		printf("Process snapshot failed: 0x%lX\n", GetLastError());
		return 0;
	}
	const DWORD pid = FindProcessEntry(snapshot, name, Process32FirstW, Process32NextW);
	CloseHandle(snapshot);
	return pid;
}


static DWORD ResolveTargetPid(wchar_t* target) {
	if (IsAllDigits(target)) {
		DWORD pid = 0;
		if (!ParseTargetPid(target, pid)) printf("Invalid PID: expected 1..4294967295\n");
		return pid;
	}
	return GetProcessIdByName(target);
}

static HANDLE SpawnSuspended(wchar_t* exePath, PROCESS_INFORMATION* outPi) {
	STARTUPINFOW si{};
	si.cb = sizeof(si);
	ZeroMemory(outPi, sizeof(*outPi));

	// Mutable copy for CreateProcessW (the lpCommandLine buffer may be
	// modified by the API).
	std::wstring cmd = L"\"" + std::wstring(exePath) + L"\"";

	BOOL ok = CreateProcessW(
		exePath, cmd.data(), nullptr, nullptr, FALSE,
		CREATE_SUSPENDED, nullptr, nullptr, &si, outPi);

	if (!ok) {
		printf("CreateProcessW failed: 0x%X\n", GetLastError());
		return nullptr;
	}
	printf("Dummy process launched suspended. PID=%u TID=%u\n",
	       outPi->dwProcessId, outPi->dwThreadId);
	return outPi->hProcess;
}

int wmain(int argc, wchar_t* argv[], wchar_t* envp[]) {

	wchar_t* dllPath = nullptr;
	DWORD PID = 0;
	PROCESS_INFORMATION spawnedPi{};
	bool spawnMode = false;
	HANDLE hProc = nullptr;

	if (argc == 4 && _wcsicmp(argv[1], L"--spawn") == 0) {
		dllPath = argv[2];
		spawnMode = true;
		hProc = SpawnSuspended(argv[3], &spawnedPi);
		if (!hProc) {
			
			return -2;
		}
		PID = spawnedPi.dwProcessId;
	}
	else if (argc == 3) {
		dllPath = argv[1];
		PID = ResolveTargetPid(argv[2]);
	}
	else if (argc == 2) {
		dllPath = argv[1];
		std::string pname;
		printf("Process (name or PID):\n");
		std::getline(std::cin, pname);

		char* vIn = (char*)pname.c_str();
		wchar_t* vOut = new wchar_t[strlen(vIn) + 1];
		mbstowcs_s(NULL, vOut, strlen(vIn) + 1, vIn, strlen(vIn));
		PID = ResolveTargetPid(vOut);
		delete[] vOut;
	}
	else {
		printf("Invalid Params\n");
		printf("Usage:\n");
		printf("  Injector dll_path [target]            (target: process name or PID)\n");
		printf("  Injector --spawn dll_path exe_path    (launches a suspended dummy process)\n");
		
		return 0;
	}

	if (!spawnMode && PID == 0) {
		printf("Process not found\n");
		
		return -1;
	}

	printf("Process pid: %d\n", PID);

	if (!spawnMode) {
		constexpr DWORD access = PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
			PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ | SYNCHRONIZE;
		hProc = OpenProcess(access, FALSE, PID);
	}
	if (!hProc) {
		DWORD Err = GetLastError();
		printf("OpenProcess failed: 0x%X\n", Err);
		if (spawnMode && spawnedPi.hThread) {
			TerminateProcess(spawnedPi.hProcess, 1);
			CloseHandle(spawnedPi.hThread);
			CloseHandle(spawnedPi.hProcess);
		}
		
		return -2;
	}

	// Clean close + terminate for error paths in spawn mode: a suspended
	// process with closed handles stays alive (and stuck) until something
	// executes its first thread or kills it.
	auto cleanupTarget = [&]() {
		if (spawnMode) {
			TerminateProcess(hProc, 1);
			if (spawnedPi.hThread)  CloseHandle(spawnedPi.hThread);
			if (spawnedPi.hProcess) CloseHandle(spawnedPi.hProcess);
			spawnedPi.hThread = spawnedPi.hProcess = nullptr;
		} else if (hProc) {
			CloseHandle(hProc);
		}
		hProc = nullptr;
	};

	if (!IsCorrectTargetArchitecture(hProc)) {
		printf("Invalid Process Architecture.\n");
		cleanupTarget();
		
		return -3;
	}

	if (GetFileAttributes(dllPath) == INVALID_FILE_ATTRIBUTES) {
		printf("Dll file doesn't exist\n");
		cleanupTarget();
		
		return -4;
	}

	std::ifstream File(dllPath, std::ios::binary | std::ios::ate);

	if (File.fail()) {
		printf("Opening the file failed: %X\n", (DWORD)File.rdstate());
		File.close();
		cleanupTarget();
		
		return -5;
	}

	auto FileSize = File.tellg();
	if (FileSize <= 0 || static_cast<unsigned long long>(FileSize) > 512ull * 1024 * 1024) {
		printf("Filesize invalid.\n");
		File.close();
		cleanupTarget();
		
		return -6;
	}

	std::unique_ptr<BYTE[]> source(new (std::nothrow) BYTE[static_cast<size_t>(FileSize)]);
	BYTE* pSrcData = source.get();
	if (!pSrcData) {
		printf("Can't allocate dll file.\n");
		File.close();
		cleanupTarget();
		
		return -7;
	}

	File.seekg(0, std::ios::beg);
	File.read((char*)(pSrcData), FileSize);
	if (!File || File.gcount() != FileSize) {
		printf("DLL read failed or file changed during reading\n");
		cleanupTarget();
		return -6;
	}
	File.close();

	printf("Mapping...\n");
	if (!ManualMapDll(hProc, pSrcData, static_cast<size_t>(FileSize))) {
		cleanupTarget();
		printf("Error while mapping.\n");
		
		return -8;
	}

	if (spawnMode) {
		printf("Resuming dummy's main thread...\n");
		if (ResumeThread(spawnedPi.hThread) == (DWORD)-1) {
			printf("ResumeThread failed: 0x%X\n", GetLastError());
			cleanupTarget();
			return -9;
		}
		CloseHandle(spawnedPi.hThread);
		CloseHandle(spawnedPi.hProcess);
	} else {
		CloseHandle(hProc);
	}
	printf("OK\n");
	return 0;
}
