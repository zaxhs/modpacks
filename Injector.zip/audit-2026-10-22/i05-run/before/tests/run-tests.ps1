param([ValidateSet('Release','Debug','Both')][string]$Configuration = 'Both')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$artifactRoot = Join-Path $projectRoot 'artifacts'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (!(Test-Path -LiteralPath $vswhere)) { throw 'Visual Studio Installer/vswhere is required.' }
$vsRoot = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (!$vsRoot) { throw 'An installed Visual Studio C++ toolchain is required.' }
$msbuild = Join-Path $vsRoot 'MSBuild\Current\Bin\MSBuild.exe'
$configurations = if ($Configuration -eq 'Both') { @('Release','Debug') } else { @($Configuration) }
New-Item -ItemType Directory -Path $artifactRoot -Force | Out-Null
foreach ($config in $configurations) {
    $buildLog = Join-Path $artifactRoot "build-$config.log"
    & $msbuild (Join-Path $projectRoot 'Manual Map Injector.sln') /m /t:Build "/p:Configuration=$config" /p:Platform=x64 "/p:AuditBuildRoot=$artifactRoot" /nologo /verbosity:minimal "/flp:logfile=$buildLog;verbosity=normal"
    if ($LASTEXITCODE -ne 0) { throw "$config build failed; see $buildLog" }
    $testExe = Join-Path $artifactRoot "$config\RegressionTests.exe"
    $payload = Join-Path $artifactRoot "$config\TestPayload.dll"
    Get-FileHash -LiteralPath $testExe,$payload | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $artifactRoot "provenance-$config.json") -Encoding utf8
    # Executes only the freshly built test runner, its owned host children,
    # the production CLI against those children, and TestPayload.dll.
    & $testExe 2>&1 | Tee-Object -FilePath (Join-Path $artifactRoot "tests-$config.txt")
    if ($LASTEXITCODE -ne 0) { throw "$config regression tests failed." }
}
