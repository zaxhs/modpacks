#pragma once
#include <Windows.h>
struct TestControl {
	LONG entered;
	LONG returning;
	DWORD delayMs;
	BOOL accept;
	ULONG_PTR imageBase;
	BOOL relocationOk;
};
