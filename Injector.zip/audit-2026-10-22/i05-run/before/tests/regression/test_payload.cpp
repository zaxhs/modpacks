// Built from this source only. No CRT, static TLS, workers, hooks, or UI.
#include "TestControl.h"
static int anchor = 123;
static int* volatile relocatedAnchor = &anchor;
extern "C" BOOL WINAPI TestDllMain(HINSTANCE module, DWORD reason, LPVOID reserved) {
	if (reason != DLL_PROCESS_ATTACH) return FALSE;
	if (!reserved) return relocatedAnchor == &anchor && *relocatedAnchor == 123;
	auto* control = static_cast<TestControl*>(reserved);
	control->imageBase = reinterpret_cast<ULONG_PTR>(module);
	control->relocationOk = relocatedAnchor == &anchor && *relocatedAnchor == 123;
	control->entered = 1;
	Sleep(control->delayMs);
	control->returning = 1;
	return control->accept;
}
