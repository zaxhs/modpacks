# Actual build and test results — 2026-10-22

## Environment and provenance

Native Windows 11 Pro 10.0.26300 (build 26300), AMD64, unelevated token.
Visual Studio Community 2026 18.10.12224.181 (display 18.10.3), v145,
MSVC 19.51.36260, Windows SDK 10.0.26100.0. MSBuild and dumpbin were taken from
the installed Visual Studio directory, not downloaded substitutes.
Machine-readable record: `audit-2026-10-22/repair-run/environment.json`.

Only reviewed source-built RegressionTests.exe, its own --host children,
Injector-x64.exe against those children, and TestPayload.dll were executed.
The payload was inspected with dumpbin: AMD64, custom TestDllMain entry, KERNEL32
Sleep import, no TLS directory, no CRT dependency. Its source includes an absolute
data pointer so the relocation path is genuinely exercised. Its normal entrypoint
can delay, accept, or reject initialization through fixture-owned control data.
No bundled or legacy DLL was executed. No game or protected process was targeted.

## Baseline before edits

The original x64 Release and Debug solution builds both succeeded natively with
zero compiler/linker warnings or errors. Logs are `baseline-native-Release.log`
and `baseline-native-Debug.log` in the repair-run folder. Original executable
headers/imports are in `baseline-imports.txt` (AMD64 console executable).

Restricted-environment attempts first reported MSB8037/MSB8036 SDK discovery
failures, then locked linker outputs/C1083 and LNK1101 MSPDB mismatch. The complete
installed toolchain succeeded outside that environment, with no source changes,
SDK override, toolchain installation, antivirus change, or security exclusion.
The unsuccessful diagnostic logs remain alongside successful native logs. They
are environment results, not evidence that the original source failed to compile.

Native baseline command, in PowerShell from the outer workspace (repeat with
Debug and a separate Debug OutDir/IntDir):

```powershell
& 'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe' `
  '.\Simple-Manual-Map-Injector-master\Manual Map Injector.sln' `
  /t:Rebuild /m /p:Configuration=Release /p:Platform=x64 `
  '/p:OutDir=C:\Users\zacha\Documents\Projekt\Simple-Manual-Map-Injector-master\Simple-Manual-Map-Injector-master\audit-2026-10-22\repair-run\baseline-native\Release\' `
  '/p:IntDir=C:\Users\zacha\Documents\Projekt\Simple-Manual-Map-Injector-master\Simple-Manual-Map-Injector-master\audit-2026-10-22\repair-run\baseline-native\Release\obj\' `
  /nologo /verbosity:minimal
```

## Final build and runtime results

PowerShell, from the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

The script records its exact compiler/linker invocations in the build logs. It
uses MSBuild /m /t:Build /p:Platform=x64 /p:Configuration=Release or Debug,
and /p:AuditBuildRoot with the absolute artifacts directory. Clean Rebuilds of
both configurations also passed during milestones.

| Final configuration | Build | Runtime regression result |
|---|---|---|
| x64 Release | Pass; 0 warnings, 0 errors | 82 passed, 0 failed |
| x64 Debug | Pass; 0 warnings, 0 errors | 82 passed, 0 failed |

Current logs: `artifacts/build-Release.log`, `build-Debug.log`,
`tests-Release.txt`, `tests-Debug.txt`. Runner/payload hashes:
`artifacts/provenance-Release.json` and `provenance-Debug.json`.
Final executable imports/headers and binary hashes are also preserved in
`audit-2026-10-22/repair-run/`. Release imports are AMD64 KERNEL32, MSVC runtime
DLLs, and UCRT API sets. Debug imports include the corresponding debug runtimes.
Neither final executable imports the old ADVAPI32 privilege-adjustment path.

Coverage includes valid/small PE input; all 1024 truncation boundaries of the
synthetic fixture; 2000 seeded mutations per configuration; invalid headers,
section/file/image ranges, certificate file bounds, import tables, thunk/name
ranges, overlapping IATs, relocation sizes/targets/self-overwrites, TLS bounds,
exception record lengths, >20 MiB virtual section, null pointers, PID boundaries,
first/subsequent process entries, pattern overflow and no-access-page boundaries.

Runtime cases include controlled attach/import/relocation, FALSE entrypoint,
missing module/symbol, allocation denial, deterministic pre-thread failure,
remote allocation inventories, thread handle counts, metadata preservation,
exception-support allocation/registration, repeated isolated children, healthy
host shutdown, and actual production CLI success/overflow/missing-file results.
Each configuration includes a real 30-second mapper timeout and a delayed
entrypoint which safely completes afterward; retained scratch memory is required.

Earlier results were 53/0, then 69/1 in each configuration, then 74/0, then final
82/0. The 69/1 failure was an incorrect fault-fixture assumption: a restricted
process handle still allowed thread creation on this host. The fixture now uses
an explicit INJECTOR_TESTING-only failure, retaining the real remote allocations,
writes, and cleanup assertions. No test was disabled to obtain success.
Earlier result files are retained as milestone evidence.

## Existing test sources: compilation only

`audit-2026-10-22/repair-run/build-legacy.ps1` contains exact commands and records
results in `legacy-builds/`. The original TLS project requests v143 and fails with
MSB8020 because that toolset is not installed. The same unchanged project builds
with command-line PlatformToolset=v145. Trivial, TLS-log, TLS-noworkers, and all
five exception variants (EHsc_MT, EHa_MT, EHac_MT, EHsc_MD, EHa_MD) build with v145.
EHsc and EHac variants warn C4297 at exc_test.cpp:400-403 because exported extern
"C" functions throw under /EHc. The legacy source was left intact; warnings are
recorded, not suppressed. Worker joins in DllMain, message boxes, and hardcoded
author-specific log paths make those examples unsuitable for the new unattended
suite. Their TLS requirements are blocked by the current mapper anyway.

## Limits of the evidence

Hosted CI has been configured but not run. Win32, Windows 10/other builds,
--spawn suspended startup, general DLL detach/unload, actual C++ throws/SEH across
mapped frames, induced unwind-registration failure, every Win32 API failure,
low-memory STL allocation failures, and complete malformed unwind/load-config
semantics remain untested. This is controlled developer testing evidence, not
arbitrary-DLL, Osiris, CS2, VAC, or universal Windows compatibility certification.
