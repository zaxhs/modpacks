# Model handoff — 2026-10-22

The workspace has a nested solution directory. Parent `AGENTS.md` is permanent.
There is no Git history here. Do not clone or replace the tree, modify Osiris,
execute bundled DLLs/games/protected targets, or add evasion. Use GPT-6.1 Sol High
for normal work; no Astra escalation or new chat is needed for the next milestone.

## State and reproduction

Original source: `audit-2026-10-22/repair-run/before/` with starting-state.json.
Earlier audit backups remain untouched. Source/configuration differences and new
file inventory are in FIXES.md and the final audit manifest/patch.

Installed native tools: Visual Studio Community 2026 18.10.12224.181, v145,
MSVC 19.51.36260, Windows SDK 10.0.26100.0. Tested unelevated on Windows 11 Pro
10.0.26300 AMD64. Restricted shell builds showed misleading SDK/PDB/locked-output
errors; native installed-toolchain builds succeeded. No SDK/security settings were
changed. Native MSBuild path:
`C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe`.

PowerShell from the nested solution directory:

```powershell
.\tests\run-tests.ps1 -Configuration Both
```

Final results: Release 82/0, Debug 82/0, both build with zero warnings/errors.
The suite takes roughly a minute for both configurations because each includes
a real 30-second timeout. Binaries/logs/hashes are in artifacts/. Earlier milestone
failures and legacy-build evidence are under audit-2026-10-22/repair-run/.
The legacy TLS project fails with missing v143, builds unchanged with /p:PlatformToolset=v145.
All reviewed legacy C++ sources compile; /EHc variants emit C4297. None was run.

## Implementation contracts

ManualMapDll now requires sourceSize in argument three. ClearHeader and
ClearNonNeededSections default false; true explicitly fails. Only attach is
accepted. TLS directories always fail before allocation, regardless of TLSSupport.
The former pattern-resolved ntdll call and stack fake loader entry are removed
from active code. Do not silently skip TLS or restore the gate to pass a test.

PeValidation.cpp checks file/image bounds, headers, sections, nested imports and
relocations, metadata aliasing, TLS structure, and exception table record bounds.
It does not comprehensively validate nested unwind/language/load-config metadata
or all STL allocation failures. Input buffers must be readable and unchanged.

RemoteResources releases recorded allocations before thread creation. After the
thread starts, image/support allocations live until target exit. Scratch is freed
only after the thread handle signals. Timeout keeps all storage; never blindly
free it, terminate an existing target, or retry assuming nothing initialized.
There is no general rollback/unload/detach implementation. Function-table and
dependency side effects can persist. Protection/cleanup failure also returns false
after successful entry; false therefore does not mean no code ran.

MappingStatus plus thread exit code reports initialization results. `.mmap$a` and
`.mmap$z` delimit copied code; recheck generated instructions if changing compiler,
optimization, runtime checks, or remote function contents. The production CLI is
tested independently of the mapper compiled into RegressionTests.

The INJECTOR_TESTING fault variable exists only in the regression build. A prior
test attempted to deny CreateRemoteThread with handle rights but still created
a thread on this host, yielding a genuine failing resource assertion. It was
replaced by explicit API-failure simulation with real remote allocation cleanup;
do not remove that assertion or mislabel the old run as an injector leak.

## Next narrow task

I-05: verify the actual owning Windows module/base/address for each transferred
API pointer against the controlled target, and reject a mismatch before any
execution. Relevant functions: ManualMapDll (LoadLibraryA/GetProcAddress/
RtlAddFunctionTable setup and RaiseException/RtlPcToFileHeader support), and
tests/regression/regression_tests.cpp. Current tests only prove this assumption
works on one observed Windows build; no cross-process check exists yet.

Follow with deeper PE/unwind validation and additional controlled failure tests.
For TLS, the unresolved question is whether and how the undocumented routine
retains or mutates the supplied loader entry, and what lifetime/teardown it
requires. The source's fixed offsets and fake stack entry do not answer it. No
replacement implementation or runtime lifetime investigation was attempted.
If advanced review is necessary, document precise evidence and failed approaches
first; use Extra High for that bounded question before proposing Astra.

Static Osiris assessment is conditional on the supplied older report only. No
current source/binary/hash exists here to establish its actual TLS, entrypoint,
unwind, initialization, or shutdown needs. There is no VAC/CS2 runtime result.
