# Verified injector audit — 2026-10-22

## Baseline and scope

The supplied report was evidence to verify, not an instruction source. Inspected
the actual injector sources, Pattern.h, project/solution, README, workflow, and all
legacy test sources/scripts. There is no Git repository in this checkout.
All 19 source/configuration files in the earlier manifest match that manifest at
the beginning of this run; see `audit-2026-10-22/repair-run/starting-state.json`.
A second source-only backup was made in `repair-run/before/`. Existing earlier
backup/build artifacts were retained. The original ZIP comparison is earlier
evidence, not a newly performed ZIP verification. Bundled DLLs were not executed.

Baseline line references below refer to the preserved `before/` files. Current
references refer to the live project. Severity is impact; likelihood is conditional
on the triggering input/path, not a measured population frequency.

## I-01 — confirmed; high impact, timing-dependent likelihood

Baseline `injector.cpp:254-299,357-364`: the thread handle is closed immediately,
then a shared hMod value controls code/data erasure and freeing. Publishing that
value precedes the return epilogue and does not establish thread termination.
Current `injector.cpp:282-319` retains the handle, waits on it, checks the exit code
and result, and releases scratch storage only after a signaled wait.
**Correction/test:** implemented; controlled slow attach, handle counts, scratch
allocation inventory, and timeout-then-late-completion tests. **Risk:** timeout
retains storage and leaves initialization outcome uncertain; no thread killing
or speculative unload was added.

## I-02 — confirmed; high impact, high likelihood for malformed inputs

Baseline `injector.cpp:16-38,192-207,405-478` accepts no source length, dereferences
e_lfanew unchecked, copies a fixed header page, and trusts nested offsets.
`main.cpp:211-231` does not check a short read. Current `PeValidation.cpp:9-220`
uses subtraction-based bounds checks, limits allocation sizes, checks headers,
section/file/image ranges, directory bounds, import terminators, thunk/name
ranges, relocation blocks/targets, TLS VA ranges, and exception records. Import
tables cannot overlap or overwrite protected parser metadata. Security-directory
bounds are file bounds. `injector.cpp:45-95,227-240` and `main.cpp:177-206` use
the validated length and SizeOfHeaders.
**Correction/test:** substantial bounds correction implemented; 1024 truncation
boundaries, 2000 deterministic mutations, valid fixtures, and targeted malformed
offset/import/relocation/TLS/exception cases. **Risk/remaining:** stricter acceptance
rejects some formerly attempted files. Nested architecture/language-specific
UNWIND_INFO, load-config semantics, CFG, and every loader feature are not fully
validated or implemented. Allocation failure in some STL metadata containers can
still throw. This is not complete hostile-PE hardening or a DLL-code sandbox.

## I-03 — confirmed; high compatibility impact, Windows-build-dependent likelihood

Baseline `injector.cpp:54-68,505-528`, `README.md:4-11,49-53`: byte patterns,
backward padding search, fixed loader-entry offsets, and a stack-based fake entry
depend on undocumented internals. The claimed lifetime, thread coverage, and
cleanup contract are not established by this source. A retained entry pointer is
a concern to investigate, not a demonstrated ntdll use-after-free finding.
**Correction:** current `injector.cpp:72-75,499-502` rejects TLS images before
allocation and reports unavailable status defensively in remote code; unsafe TLS
calls and pattern resolution were removed from the active mapper.
**Tests/risks:** valid TLS rejection tested; legacy TLS sources compile but are
not run. This intentionally reduces accepted DLLs, including CRT DLLs with TLS.
The underlying TLS compatibility problem remains unresolved; do not remove the
gate without proving ownership and testing particular Windows builds.

## I-04 — confirmed; medium/high impact, path-dependent likelihood

Baseline `injector.cpp:425-536,266-299` ignores dependency/symbol failures,
DllMain FALSE, and some unwind-registration results. Current
`injector.h:55-62`, `injector.cpp:304-319,410-418,460-511` distinguishes module,
symbol, unwind-registration, unavailable TLS, and entrypoint failures. Requested
support allocation/write failures now stop before execution.
**Tests:** missing module, missing symbol, FALSE entrypoint, successful entrypoint,
and real unwind-table registration of the support stub. **Risk/remaining:** partial
initialization can have side effects; false is not transactional rollback.
An induced RtlAddFunctionTable failure and general C++ throws are not tested.

## I-05 — confirmed assumption; medium/high impact, likelihood not established

Baseline `injector.cpp:47-52,85-186`, `injector.h:19-32`: host-resolved Windows
function addresses are transferred as numeric pointers to another process.
Current `injector.cpp:96-103,114-219` still has this assumption.
**Proposed correction:** independently verify module/address equality and fail
closed on mismatch before execution; do not infer equality from OS version.
**Tests/risks:** ordinary child tests exercise the addresses on one Windows build,
but do not establish a universal guarantee. Different architectures, module
layouts, instrumentation, and process policies remain compatibility limits.

## I-06 — partially confirmed; medium impact, high likelihood on specified failures

Baseline `injector.cpp:78-240,269-304` leaks support allocations on pre-thread
failures. However, retaining storage on timeout can be necessary; blindly freeing
everything there would worsen I-01. Current `injector.cpp:12-26,282-319` has an
explicit ownership boundary: release all recorded allocations before execution;
after execution, retain image/support pages, and free scratch only after thread
termination. Timeout retains all remote storage until process exit.
**Tests:** deterministic test-only CreateRemoteThread failure with real remote
allocations and inventory equality, allocation denial, success/failure allocation
counts, timeout, handle counts, clean child shutdown. An earlier rights-only fault
fixture did not actually prevent thread creation; its failing logs are preserved.
**Risk/remaining:** no general dependency refcount rollback, unregister/unload, or
post-timeout reclamation. Pre-execution destructor frees are best-effort and do
not individually report VirtualFreeEx failure. This is process-lifetime ownership,
not a complete recoverable resource model for long-running targets.

## I-07 — confirmed; medium impact, high likelihood for oversized erased sections

Baseline `injector.cpp:300-329`: section VirtualSize can exceed the 20 MiB source
buffer supplied to WriteProcessMemory. Current erasure code and buffer are removed;
explicit destructive cleanup requests fail at `injector.cpp:56-59`.
**Test:** a valid section larger than 20 MiB validates, and an erasure request is
rejected before allocation. **Risk:** intentional API behavior change; no erasure
functionality is provided. Bounded section-name formatting also avoids treating
the eight-byte PE name as an unbounded C string.

## I-08 — confirmed; low/medium impact, deterministic for a first-entry match

Baseline `main.cpp:23-40` only compares entries returned by Process32Next.
Current `main.cpp:27-36` and `TargetInput.h:31-41` compare Process32First in a
do/while traversal and check invalid snapshot handles.
**Tests:** synthetic first, subsequent, case-insensitive, and invalid-handle cases.
**Risk:** real process enumeration is a changing snapshot; duplicate names remain
ambiguous and the first match is selected.

## I-09 — partially confirmed; medium impact, deterministic for overflowing numbers

Baseline `main.cpp:51-67,145-159` narrows unchecked numeric input and requests
SeDebugPrivilege/PROCESS_ALL_ACCESS. The overflow defect is confirmed; broad
rights are not themselves proof of exploitation or a runtime failure. Current
`TargetInput.h:6-27`, `main.cpp:39-45,120-125` validate 1..DWORD_MAX without numeric
conversion overflow, do not fall back for all-digit input, and request specific
documented rights. Automatic SeDebugPrivilege adjustment is removed.
**Tests:** zero, limits, signs, mixed/empty input, huge numbers, production CLI,
and unelevated own-child tests. **Risk:** protected or other-owner processes can
now fail with an access error; no automatic elevation is attempted.

## I-10 — confirmed; medium impact, DLL-dependent likelihood

Baseline `injector.h:54`, `injector.cpp:307-370` erase headers and selected
sections by default. No general detach or resource-unregistration contract exists.
Current `injector.h:60-62`, `injector.cpp:56-59` preserve metadata and accept
attach only. **Tests:** MZ remains readable after successful and rejected
initialization. **Risk/remaining:** intentional loss of destructive options;
process shutdown is tested, DLL detach/unload is not implemented or promised.

## I-11 — confirmed; medium verification impact, deterministic CI omission

Baseline `.github/workflows/build.yml:11-60` builds Release only and never executes
tests. Current workflow adds x64 Release/Debug regression execution and log
artifacts; x86 remains build-only. The existing solution now includes source-built
regression and payload projects; `tests/run-tests.ps1` runs locally.
**Tests/risks:** local script verified; hosted GitHub Actions has not been run.
Runner/toolchain/package availability is still an external CI dependency. Legacy
TLS/EH examples remain build-only, not silently counted as runtime passes.

## I-12 — confirmed; low normal-path likelihood, deterministic impact on null

Baseline `injector.cpp:389-393` writes through pData in its null branch.
Current `injector.cpp:371-375` returns InvalidData without dereferencing it.
**Test:** direct Shellcode(nullptr) call. **Risk:** a null input cannot receive a
shared-memory status; callers must use the thread return code. Valid pointers
remain a caller-owned memory contract.

## Reference contracts

Microsoft's [PE format reference](https://learn.microsoft.com/en-us/windows/win32/debug/pe-format)
distinguishes file offsets and RVAs. The
[CreateRemoteThread contract](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createremotethread)
documents process access and thread creation; creation alone does not prove
successful execution. [DllMain documentation](https://learn.microsoft.com/en-us/windows/win32/dlls/dllmain)
defines FALSE attach failure and cautions about work in an entrypoint. These public
contracts do not establish the removed undocumented TLS entry's ownership.
