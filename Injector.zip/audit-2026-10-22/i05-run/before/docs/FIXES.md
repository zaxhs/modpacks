# Implemented corrections — 2026-10-22

## Safety changes

`ValidatePeImage` in `Manual Map Injector/PeValidation.cpp` operates on an explicit
byte count. Header reads use memcpy after subtraction-based range checks.
Validation builds a bounded local image for nested RVA checks, checks sections
before copying, bounds import descriptors/thunks/strings and relocation blocks,
and rejects parser-metadata overwrites and overlapping IATs. Image size is limited
to 512 MiB, sections to 96, and unsupported CLR/delay-import input is rejected.
TLS structure and exception-record bounds are checked, without claiming complete
validation of Windows' nested unwind/language-specific formats.

`ManualMapDll` now takes sourceSize as its third argument and validates before
remote allocation. Header copying uses validated SizeOfHeaders. The CLI checks
file size, nonthrowing source-buffer allocation, and complete reads. Valid caller
buffers must remain readable and unchanged for the duration of the call.

The fixed 20 MiB erase buffer and header/section/code erasure were removed.
ClearHeader/ClearNonNeededSections default to false; requests to enable them fail
explicitly. The eight-byte section names use bounded printf formatting. These are
intentional API behavior changes to preserve metadata and diagnostics.

Shellcode(nullptr) returns InvalidData without writing through the null pointer.
The remote function has the actual DWORD WINAPI thread-start signature. Ordered
`.mmap$a`/`.mmap$z` code sections and an end marker define the copied extent,
replacing the unbounded assumption that 4096 bytes always describe that function.
The extent is sanity-checked and instruction caches are flushed before execution.
This remains MSVC/code-generation-sensitive; production Release and Debug CLI
paths are tested, not just a test copy of the mapper.

Pattern.h additionally rejects null patterns and overflowing decimal ranges,
bounds wildcard loops, validates the entire scan window for readability, uses an
iterative memory-range walk, and bounds section-name comparison. It is no longer
used to resolve TLS in the mapper. Module helpers still expect a valid loaded
module; they are not arbitrary untrusted pointer parsers. Concurrent protection
changes can invalidate a prior VirtualQuery check.

## Resource-lifetime model

| State | Owner and permitted cleanup |
|---|---|
| Validation | Local buffers only; no remote allocations |
| Before thread creation | RemoteResources records image, two optional support pages, mapping data, code; destructor releases all on failure |
| Thread running | Image/support and scratch storage may be in use; thread handle remains owned by the host |
| Thread signaled | Read exit code/status, free code and parameter scratch; close handle through RAII |
| Initialized | Keep image and support pages until target exit; apply requested protections and report failures |
| Initialization failed after execution | Free scratch only after signal; retain image/support and dependency side effects until target exit |
| Timeout/wait failure | Close the host thread handle, retain all remote storage; do not stop the thread or guess at unload safety |

The model deliberately does not promise rollback or unloading. Registered function
tables, DLL-created state, and imported dependencies can outlive the mapper call.
A failed result can leave a partially initialized image. After timeout there is no
background reclamation owner; process exit is the supported release boundary.

`MappingStatus` distinguishes Pending, Initialized, InvalidData, missing module,
missing symbol, exception-registration failure, unavailable TLS, TLS initialization
failure (reserved), and rejected entrypoint. Remote failures also return a nonzero
thread exit code. The host requires an initialized status, zero thread exit code,
and the expected module base. Failed support writes/allocations are no longer
treated as successful reduced operation. Cleanup/protection failure returns false
even if the entrypoint already succeeded; callers must not blindly retry.

The TLS implementation was stopped at a safety boundary: any TLS directory is
rejected before allocation. The pattern lookup and fake stack loader entry were
removed from active code. This is a mitigation with a documented compatibility
regression, not a repair or validation of static TLS.

## Input, tests, and build integration

`TargetInput.h` provides overflow-safe decimal PID parsing and a first/next process
enumerator used by both production and fixture tests. Process snapshot creation
is checked. Numeric input no longer falls back to process-name lookup. The CLI
requests the process rights used by its APIs and no longer enables SeDebugPrivilege.
Interactive pause calls were removed, and a failed ResumeThread returns failure.
Spawn command paths are quoted; suspended startup itself remains unverified.

The solution adds an isolated regression executable and a minimal, reviewed DLL
with a custom entrypoint, no CRT/static TLS, and a deliberate relocation plus
Sleep import. Test children are the same source-built executable in --host mode.
All terminations are restricted to processes created by the fixture. The
INJECTOR_TESTING-only fault hook simulates CreateRemoteThread failure while real
allocations/writes and cleanup execute against the controlled child; it is absent
from the production project. A rights-only fixture had failed to induce that API
failure, and the original failed run is retained in the evidence folder.

`tests/run-tests.ps1` discovers the installed Visual Studio toolchain, builds the
existing solution, records payload/runner hashes, and propagates failures. CI now
executes x64 Release and Debug tests and uploads logs. x86 remains build-only in
CI; no x86 runtime result was obtained locally.

## Exact edited/added files

Paths below are relative to the nested solution directory, except the first:

- `../AGENTS.md` (new workspace-wide instructions).
- `Manual Map Injector/injector.cpp`, `injector.h`, `main.cpp`, `Pattern.h`, `Manual Map Injector.vcxproj`.
- `Manual Map Injector/PeValidation.cpp`, `PeValidation.h`, `TargetInput.h` (new).
- `Manual Map Injector.sln`, `.gitignore`, `.github/workflows/build.yml`, `README.md`.
- `tests/run-tests.ps1` (new).
- `tests/regression/RegressionTests.vcxproj`, `TestPayload.vcxproj`, `regression_tests.cpp`, `test_payload.cpp`, `TestControl.h` (new).
- `docs/INJECTOR_AUDIT.md`, `FIXES.md`, `TEST_RESULTS.md`, `COMPATIBILITY.md`, `PROGRESS.md`, `MODEL_HANDOFF.md` (new).

Generated binaries, compiler logs, provenance records, source backups, build
diagnostic scripts, and the final patch/hash inventory are evidence rather than
additional production source changes. No separate Osiris files or bundled DLLs
were modified by this work.
