# Compatibility and boundaries — 2026-10-22

## Windows and PE constraints

Primary target: native Windows 10/11 on AMD64. Runtime evidence currently covers
only unelevated Windows 11 Pro 10.0.26300, build 26300, with MSVC 19.51.36260.
Windows 10, other Windows 11 builds, ARM64/emulation, protected targets, different
owners/security policies, and Win32 runtime remain unverified.

The mapper accepts DLLs matching its build architecture with the expected PE
optional-header layout, bounded aligned sections, up to 96 sections, and an image
of at most 512 MiB. The CLI also limits input files to 512 MiB. Entry RVA zero is
accepted; a nonzero entry must be in file-backed executable section data. Imported
modules/symbols must resolve. Relocation types are DIR64 for x64, HIGHLOW for
Win32, and ABSOLUTE padding. An image without relocations fails if its allocated
base differs from the preferred base; preferred-base allocation is not retried.
CLR and delay imports are rejected. The certificate directory is a file range;
certificates/signatures are not authenticated by this validator.

All TLS-bearing DLLs are rejected, including when TLSSupport=false. The old
undocumented ntdll routine, assumed loader offsets, and stack loader-entry
lifetime have not been validated. The old README's broad TLS compatibility matrix
was removed. No new pattern or undocumented replacement was introduced.

Public Windows APIs used in remote code are still resolved in the injector's
process. Their identical addresses in a target are assumed, not independently
verified. Current own-child tests establish only that these paths work in the
observed process layout on this Windows build. A future correction should reject
module/address mismatches before remote execution.

The x64 exception path registers RUNTIME_FUNCTION tables and retains the existing
CxxThrowException/RtlPcToFileHeader support stubs. Registration is exercised by
tests, but general C++ throwing/catching, all /MT-/MD-runtime combinations, SEH
unwinding, RTTI, and nested language-specific unwind metadata are not verified.
The validator only checks exception record ranges and the minimum unwind header
extent; it does not parse every UNWIND_INFO tail, handler, or language structure.
Load-config/security-cookie/CFG and other normal-loader responsibilities are not
fully implemented. Do not interpret accepting a PE as full Windows-loader parity.

The build uses /MD for the production Release CLI, and Debug depends on debug
runtime libraries. The Release imports include KERNEL32, MSVCP140, VCRUNTIME140,
VCRUNTIME140_1, and UCRT API sets; final dumpbin reports are saved in the audit
folder. The old ADVAPI32 token-adjustment dependency is no longer imported.

## Initialization and shutdown

The PE entrypoint receives DLL_PROCESS_ATTACH. A custom entrypoint is permissible
if the DLL itself satisfies its initialization contract; the mapper does not
automatically supply CRT startup for a DLL that deliberately bypasses it. FALSE
is a failure. Entry success proves the entrypoint returned successfully, not that
hooks, worker threads, or application features work.

Header/section metadata is preserved. The mapper does not insert the image into
the normal loader's module bookkeeping. It does not offer a verified general
unload/detach contract, reverse dependency loading, or unregister all function
tables. The tested shutdown is normal exit of the owned host process, not a DLL
detach notification. After execution, image/support pages live until target exit;
timeouts additionally retain executable scratch and parameters. A timeout is an
unknown initialization outcome and is not safe grounds for a blind retry.

The --spawn suspended-startup path is preserved but was not exercised. Existing
legacy tests contain UI, hardcoded author-specific log paths, or worker-thread
joins in DllMain; their build success does not make them appropriate unattended
runtime tests. Only the new reviewed payload was executed.

## Static Osiris assessment

No current Osiris source or built DLL was supplied for this workspace assessment.
Nothing in a separate Osiris tree was read, built, modified, or executed. The
attached earlier report is the sole evidence for that separate snapshot:

| Property | Preliminary evidence and consequence |
|---|---|
| Architecture | Report describes a Windows x64 DLL; an actual DLL must have AMD64 machine and PE32+ headers |
| Entry point | Report says custom DllMain; actual PE AddressOfEntryPoint, calling convention, and startup obligations remain to inspect |
| PE metadata | Headers/resources/unwind data may be consumed by DLL code; this mapper preserves metadata, but does not provide normal module registration |
| TLS | Report says a restricted release runtime; that does not prove absence of a TLS directory. Any actual TLS directory is currently rejected |
| Exceptions | Report claims no C++ exceptions in Release; that does not prove absence of unwind metadata or SEH needs |
| Initialization | Report describes GlobalContext initialization; current source, return/async completion, and failure contracts are unavailable |
| Shutdown | No current teardown/ownership contract or controlled integration result is available; general unload is unsupported |

Architectural compatibility is possible only conditionally for a matching,
supported PE whose entrypoint contract is satisfied. It is not a positive
compatibility conclusion for any current Osiris build. Required next evidence:
exact reviewed source revision and build settings, reproducible DLL/hash, PE
headers/directories/imports/relocations/unwind data, and explicit initialization,
metadata, worker-thread, and shutdown requirements. Restricted CRT settings alone
cannot replace that evidence.

This work establishes no VAC safety, detection outcome, or CS2 runtime
compatibility. No CS2, game, anti-cheat-protected process, bypass, driver, process
hiding, or new concealment mechanism was involved.
