@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /W4 /WX /analyze /c /EHsc /std:c++17 /DUNICODE /D_UNICODE /Fo"RemoteApi-production-analysis.obj" "..\..\Manual Map Injector\RemoteApi.cpp"
if errorlevel 1 exit /b 1
cl /nologo /W4 /WX /analyze /c /EHsc /std:c++17 /DUNICODE /D_UNICODE /DINJECTOR_TESTING /Fo"RemoteApi-test-analysis.obj" "..\..\Manual Map Injector\RemoteApi.cpp"
exit /b %errorlevel%
