$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$out = Join-Path $PSScriptRoot 'legacy-builds'
New-Item -ItemType Directory -Path $out -Force | Out-Null
$vsRoot = 'C:\Program Files\Microsoft Visual Studio\18\Community'
$vcvars = Join-Path $vsRoot 'VC\Auxiliary\Build\vcvars64.bat'
$msbuild = Join-Path $vsRoot 'MSBuild\Current\Bin\MSBuild.exe'
$results = @()
foreach ($toolset in @('v143','v145')) {
    & $msbuild (Join-Path $projectRoot 'tests\tls-test-dll\tls-test-dll.vcxproj') /t:Rebuild /p:Configuration=Release /p:Platform=x64 "/p:PlatformToolset=$toolset" "/p:OutDir=$out\$toolset\" "/p:IntDir=$out\$toolset\obj\" /nologo /verbosity:minimal 2>&1 | Tee-Object -FilePath (Join-Path $out "tls-project-$toolset.txt")
    $results += [PSCustomObject]@{Name="tls-project-$toolset";ExitCode=$LASTEXITCODE}
}
$cases = @(
    @{Name='trivial';Source='tests\trivial-dll\trivial.cpp';Flags='/EHsc /MT'},
    @{Name='tls-log';Source='tests\tls-test-dll\tls_test_log.cpp';Flags='/EHsc /MT'},
    @{Name='tls-noworkers';Source='tests\tls-test-dll\tls_test_noworkers.cpp';Flags='/EHsc /MT'}
)
foreach ($mode in @('EHsc_MT','EHa_MT','EHac_MT','EHsc_MD','EHa_MD')) {
    $parts = $mode.Split('_')
    $cases += @{Name="exc-$mode";Source='tests\exc-test-dll\exc_test.cpp';Flags="/$($parts[0]) /$($parts[1]) /DEH_MODE_$($parts[0].ToUpperInvariant())"}
}
foreach ($case in $cases) {
    $source = Join-Path $projectRoot $case.Source
    $command = 'call "' + $vcvars + '" >nul && cl /nologo /W3 /std:c++17 /O2 /LD ' + $case.Flags + ' "' + $source + '" /Fo"' + $out + '\' + $case.Name + '.obj" /link /OUT:"' + $out + '\' + $case.Name + '.dll" user32.lib kernel32.lib'
    & cmd.exe /d /c $command 2>&1 | Tee-Object -FilePath (Join-Path $out ($case.Name + '.txt'))
    $results += [PSCustomObject]@{Name=$case.Name;ExitCode=$LASTEXITCODE}
}
$results | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $out 'results.json') -Encoding utf8
$results | Format-Table -AutoSize
