# Statisk kodgranskning: Simple Manual Map Injector för Osiris

**Datum:** 2026-10-22  
**Granskat underlag:** användarens `Simple-Manual-Map-Injector-master.zip` (30 arkivposter, varav tre förkompilerade prov-DLL-filer)  
**SHA-256 för ZIP:** `8763fc2843f017464877316598edb0c0857063c9bc46e8157e21305e4103b8c8`  
**Jämförd Osiris-bas:** användarens `Osiris-master(1).zip` från samma konversation  
**Verifieringsnivå:** statisk källkodsgranskning och kontroll av arkivstruktur. Ingen C++-kompilering, Windows-runtime, injektion eller CS2-test har utförts. Ingen av DLL-filerna har exekverats.

## Samlad bedömning

Koden innehåller en verklig Win32/Win64-manual-mapper med PE-sektionskopiering, relokeringar, importupplösning, x64-undantagshantering och en särskild x64-TLS-lösning. Det är en relativt liten och granskningsbar källkod, och projektet riktar sig mot Windows.

**Status: lovande som studie- och testunderlag, men inte tillräckligt tillförlitlig för att rekommenderas som verifierad Osiris-injektor.** Flera källkodsfel och antaganden kan ge minnesfel, ofullständig inläsning eller krasch. Varken kompatibilitet med Osiris i körning eller detektionsrisk i VAC-skyddade miljöer kan fastställas genom denna granskning.

## Granskade huvudfiler

- `Manual Map Injector/main.cpp`: argument, processval, rättigheter, DLL-fil och exekveringsflöde.
- `Manual Map Injector/injector.cpp` och `injector.h`: minnesallokering, manuell PE-inläsning, fjärrtråd och städning.
- `Manual Map Injector/Pattern.h`: byte-patternsökning i lokala moduler.
- `Manual Map Injector/Manual Map Injector.vcxproj`: bygginställningar.
- `.github/workflows/build.yml`: CI-byggjobb.
- `tests/`: exempel och särskilda TLS-/undantagstester.
- `README.md`, `LICENSE`: dokumenterade egenskaper och licens.

Radangivelserna nedan avser filerna i det **uppladdade** arkivet, inte nödvändigtvis aktuell GitHub master.

## Fynd (ordnade efter risk)

### I-01. Möjlig kapplöpning vid avslut av fjärrtråden — **hög**

**Källor:** `injector.cpp:254–264`, `266–299`, `357–364`.

Efter `CreateRemoteThread` stängs trådhandtaget direkt. Programmet väntar sedan genom att läsa ett färdigmeddelande från delat minne, men verifierar inte att den exekverande fjärrtråden faktiskt har avslutats. Därefter skrivs den kopierade koden över och dess minne frigörs. En tråd kan fortfarande exekvera epilog eller återgångskod vid den tidpunkten. Det skapar en möjlig krasch-/race-risk. **Rekommendation:** lägg till korrekt avslutssynkronisering och dokumentera livscykeln. Verifiera i en isolerad Windows-testprocess.

### I-02. Otillräcklig validering av PE-filen — **hög**

**Källor:** `injector.cpp:22–38`, `192–207`, `405–423`, `425–478`; `main.cpp:211–231`.

Koden kontrollerar MZ-signaturen och maskinarkitekturen men saknar genomgående verifiering av NT-headerns läge, PE-signatur, sektions- och kataloggränser och att de angivna offsetarna ryms i den lästa filen. Skadade eller felkonstruerade DLL-filer kan leda till otillåtna läsningar, felaktig kopiering eller instabilitet. **Rekommendation:** definiera fullständiga fil- och minnesgränser och avvisa ogiltiga PE-filer före fjärrallokering.

### I-03. Instabilt beroende av odokumenterad TLS-funktion — **hög kompatibilitetsrisk**

**Källor:** `injector.cpp:54–68`, `505–528`; `README.md:4–11`, `49–53`.

x64-TLS använder ett byte-mönster för att lokalisera `ntdll!LdrpHandleTlsData`, och överlämnar en konstruerad, strukturliknande post med antagna fältoffsetar. Dessa är inte stabila publika Windows-API-kontrakt. Vid misslyckat uppslag loggas endast en varning. **Rekommendation:** behandla TLS-funktionaliteten som osäker tills den verifierats på faktiska Windows-byggen; skilj tydligt mellan lyckad inläsning och reducerat TLS-stöd.

### I-04. Bristfällig kontroll av initieringsfel — **medel/hög**

**Källor:** `injector.cpp:425–476`, `480–502`, `531–536`, `266–299`.

Returvärden från inläsning av beroendemoduler och funktioner hanteras inte tillräckligt. DLL-entrypointens returvärde ignoreras, och ett särskilt felvärde för undantagsregistrering ger bara en varning och betraktas i praktiken som avslutat flöde. Felaktig initiering kan därför framstå som lyckad. **Rekommendation:** inför explicita statusvärden och konsekvent felrapportering samt skilj mellan lastad, initialiserad och fungerande modul.

### I-05. Antagande om samma Windows-API-adresser i två processer — **medel/hög kompatibilitetsrisk**

**Källor:** `injector.cpp:47–52`, `85–120`, `150–186`; `injector.h:19–32`.

Funktionpekare hämtas från injektorns process och används av kod som kör i en annan process. Windows-modulers adresser är ofta desamma mellan processer i praktiken, men detta är inte ett tillräckligt universellt kontrakt för att lämnas otestat. **Rekommendation:** dokumentera antagandet och verifiera det i isolerade målprocesser för relevanta Windows-versioner.

### I-06. Ofullständig resurshantering vid fel och timeout — **medel**

**Källor:** `injector.cpp:78–188`, `193–240`, `269–304`.

Ytterligare allokerade minnesområden för stödkod hanteras inte konsekvent vid alla felvägar. Timeout och vissa tidiga returer lämnar möjligtvis minne kvar i målprocessen. **Rekommendation:** inventera alla resursägare och införa ett sammanhängande fel- och återställningsflöde. Undvik att frigöra kod som fortfarande kan exekveras.

### I-07. Fast 20 MiB nollbuffert kan vara för liten — **medel**

**Källor:** `injector.cpp:300–329`.

En 20 MiB nollad lokal buffert används som källa när PE-sektioner nollställs. Längden som skrivs baseras på sektionsstorlek och jämförs inte med buffertstorleken. En tillräckligt stor sektion kan därför orsaka läsning utanför bufferten. **Rekommendation:** inför tydlig storlekskontroll och välavgränsad nollställningshantering.

### I-08. Processökningen hoppar över den första posten — **medel/låg**

**Källor:** `main.cpp:23–40`.

Efter `Process32First` söker koden enbart inne i `Process32Next`-loopen och kontrollerar aldrig den första processposten. Detta är ett konkret, reproducerbart logiskt fel. **Rekommendation:** inkludera första resultatet i processenumereringen och testa med kontrollerade processlistor.

### I-09. Ofullständig hantering av PID och privilegier — **medel**

**Källor:** `main.cpp:51–67`, `145–159`.

En numerisk inmatning konverteras till 64-bitars tal men castas sedan till `DWORD` utan explicit intervallvalidering. Verktyget försöker också aktivera `SeDebugPrivilege` och öppnar processen med `PROCESS_ALL_ACCESS`, vilket kan vara mer än vad som krävs för vissa testfall. **Rekommendation:** avvisa ogiltiga PID-värden, rapportera rättighetsproblem tydligt och tillämpa minsta nödvändiga behörighet.

### I-10. Destruktiv standardstädning och otydlig avlastning — **medel**

**Källor:** `injector.h:54`, `injector.cpp:307–355`, `357–370`.

Standardinställningarna raderar PE-headern och vissa sektioner. Detta försvårar diagnostik och kan påverka kod som behöver tillgång till modulmetadata. Någon allmän, verifierad avlastnings-/detach-livscykel för manuellt mappade DLL-filer finns inte beskriven. **Rekommendation:** prioritera verifierbar korrekthet, tydlig livscykel och god diagnostik framför destruktiv behandling av metadata.

### I-11. Tester finns men körs inte i det granskade CI-flödet — **medel**

**Källor:** `.github/workflows/build.yml:11–60`; `tests/`.

CI bygger Win32/x64 Release men innehåller inga steg som kör regressionstester eller de inkluderade TLS-/undantags-DLL:erna. Exempeltester visar avsikt, inte verifierad kompatibilitet. **Rekommendation:** lägg till isolerade funktionstester, feltester och rapporter som klart skiljer byggstatus från körstatus.

### I-12. Inbyggd felsäkerhet i startkoden behöver översyn — **låg**

**Källa:** `injector.cpp:389–393`.

Om `pData` är null försöker felgrenen direkt skriva via den nullpekaren. Detta leder till en ogiltig åtkomst i själva felhanteringen. **Rekommendation:** granska felhanteringens egna invariants och undvik ytterligare krascher i avvikelsefall.

## Extern källkontroll

GitHub visar ett öppet ärende från 2026-07-28 om x64-krascher för DLL:er kompilerade med `/MT`:  
https://github.com/TheCruZ/Simple-Manual-Map-Injector/issues/29

Det är en **användarrapport**, inte ett reproducerat fel i den uppladdade ZIP-filen. Det uppladdade arkivet innehåller dessutom specifik kod för C++-undantagsbehandling, så det går inte att utan vidare överföra ärendet till just denna snapshot. GitHub har också ett öppet historiskt TLS-ärende:  
https://github.com/TheCruZ/Simple-Manual-Map-Injector/issues/11

## Systemrisk och misstänkta sidoeffekter

I injektorns granskade C++-källor hittades inga explicita nätverksanrop eller telemetrifunktioner, registerändringar, drivrutinsinstallationer eller overlay-komponenter. Detta är **inte** en malwarefrihetsgaranti: tre körbara prov-DLL-filer ingår och har inte exekverats eller fullständigt analyserats. Injektorn begär omfattande processåtkomst och utför fjärrminnesallokering och fjärrkodexekvering, vilket är säkerhetskänsliga åtgärder och kan uppmärksammas av skyddsprogram.

## Relevans för den granskade Osiris-versionen

Jämförelsen gjordes med **användarens tidigare bifogade Osiris-snapshot**, inte ett nytt GitHub-checkout:

- `Source/dllmain.cpp:23–28`: Windows-DLL:n har en egen `DllMain` som initierar GlobalContext vid `DLL_PROCESS_ATTACH`.
- `Source/Osiris.vcxproj:645, 653–654`: Release-projektet är inställt med eget entrypoint `DllMain` och utan standardbibliotek.
- `README.md:33–40`: projektet uppger att Release saknar CRT, heapallokeringar, statiska imports, egna trådar, C++-undantag och externa beroenden.
- `README.md:73–81`: anger behov av manual mapping på Windows, men uppgiften är ingen garanti för kompatibilitet med en viss injektor.

Särskild TLS- och C++-undantagsinjektion verkar därför **inte vara ett visat behov** för just denna Osiris-bas. Jämförelsen stödjer bara arkitektonisk möjlighet, **inte** att inläsning, global initiering, hooks och avlastning verkligen fungerar i CS2.

## Rekommenderad fortsättning

1. **Håll injektorn som separat projekt** och ändra inte Osiris under denna granskning.
2. Prioritera minnessäkerhet, verifierad trådlivscykel, PE-validering och konsekvent felhantering.
3. Granska binärfiler och källkodens proveniens innan körning; kompilera egen testversion om Windows-miljö finns.
4. Testa endast grundläggande inläsning och uppstädning med en kontrollerad Windows x64-testapplikation och enkel test-DLL; dokumentera eventuella krascher.
5. Utvärdera Osiris-kompatibilitet först när injektorns basala korrekthet är visad och Osiris Windows-bygget verifierat. Håll anti-cheat- och detektionspåståenden separata: ingen metod kan här godkännas som VAC-säker.

**Slutsats:** Det finns ingen grund att kalla koden trojan eller malware utifrån det granskade C++-innehållet, men inte heller grund att kalla den säker eller kompatibel med CS2. Den bör betraktas som ett utvecklings-/testunderlag med konkreta kvarstående stabilitetsproblem.
