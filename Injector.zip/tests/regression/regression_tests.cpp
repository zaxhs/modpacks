#include "../../Manual Map Injector/injector.h"
#include "../../Manual Map Injector/PeValidation.h"
#include "../../Manual Map Injector/TargetInput.h"
#include "../../Manual Map Injector/Pattern.h"
#include "../../Manual Map Injector/RemoteApi.h"
#include "TestControl.h"
#include <algorithm>
#include <cstring>
#include <iterator>
#include <set>
#include <vector>

static int passed = 0, failed = 0;
bool InjectorTestFailThreadCreation = false;
extern bool InjectorTestFailHostAllocation;
extern int InjectorTestFailAllocationAt;
static void Check(bool ok, const char* name) {
	printf("[%s] %s\n", ok ? "PASS" : "FAIL", name);
	ok ? ++passed : ++failed;
}
static IMAGE_NT_HEADERS* Nt(std::vector<BYTE>& data) {
	return reinterpret_cast<IMAGE_NT_HEADERS*>(data.data() + reinterpret_cast<IMAGE_DOS_HEADER*>(data.data())->e_lfanew);
}
static std::vector<BYTE> MinimalPe() {
	std::vector<BYTE> bytes(0x400);
	auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(bytes.data());
	dos->e_magic = IMAGE_DOS_SIGNATURE; dos->e_lfanew = 0x80;
	auto* nt = Nt(bytes); nt->Signature = IMAGE_NT_SIGNATURE;
	nt->FileHeader.Machine = IMAGE_FILE_MACHINE_AMD64; nt->FileHeader.NumberOfSections = 1;
	nt->FileHeader.Characteristics = IMAGE_FILE_DLL;
	nt->FileHeader.SizeOfOptionalHeader = sizeof(IMAGE_OPTIONAL_HEADER);
	auto& opt = nt->OptionalHeader;
	opt.Magic = IMAGE_NT_OPTIONAL_HDR64_MAGIC; opt.ImageBase = 0x180000000;
	opt.SizeOfImage = 0x2000; opt.SizeOfHeaders = 0x200;
	opt.SectionAlignment = 0x1000; opt.FileAlignment = 0x200;
	opt.NumberOfRvaAndSizes = IMAGE_NUMBEROF_DIRECTORY_ENTRIES;
	auto* s = IMAGE_FIRST_SECTION(nt);
	memcpy(s->Name, ".text", 5); s->VirtualAddress = 0x1000;
	s->Misc.VirtualSize = 0x200; s->SizeOfRawData = 0x200; s->PointerToRawData = 0x200;
	s->Characteristics = IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_EXECUTE;
	return bytes;
}

static void ValidationTests() {
	std::string error;
	auto valid = MinimalPe();
	HANDLE current = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, GetCurrentProcessId());
	Check(ValidatePeImage(valid.data(), valid.size(), error), "minimal valid x64 PE");
	Check(!ValidatePeImage(nullptr, 0, error), "null source rejected");
	bool truncated = true;
	for (size_t n = 0; n < valid.size(); ++n) if (ValidatePeImage(valid.data(), n, error)) truncated = false;
	Check(truncated, "all 1024 truncation boundaries rejected");
	auto reject = [&](auto change, const char* label) {
		auto data = valid; change(data); Check(!ValidatePeImage(data.data(), data.size(), error), label);
	};
	reject([](auto& b) { reinterpret_cast<IMAGE_DOS_HEADER*>(b.data())->e_lfanew = -1; }, "negative NT offset");
	reject([](auto& b) { reinterpret_cast<IMAGE_DOS_HEADER*>(b.data())->e_lfanew = LONG_MAX; }, "oversized NT offset");
	reject([](auto& b) { Nt(b)->Signature = 0; }, "invalid PE signature");
	reject([](auto& b) { Nt(b)->FileHeader.Machine = IMAGE_FILE_MACHINE_I386; }, "wrong architecture");
	reject([](auto& b) { Nt(b)->FileHeader.SizeOfOptionalHeader = 2; }, "short optional header");
	reject([](auto& b) { Nt(b)->FileHeader.NumberOfSections = 97; }, "excess section count");
	reject([](auto& b) { Nt(b)->OptionalHeader.SizeOfImage = MAXDWORD; }, "oversized image");
	reject([](auto& b) { Nt(b)->OptionalHeader.SizeOfHeaders = 0x1000; }, "headers beyond file");
	reject([](auto& b) { IMAGE_FIRST_SECTION(Nt(b))->PointerToRawData = MAXDWORD; }, "overflowing raw section offset");
	reject([](auto& b) { IMAGE_FIRST_SECTION(Nt(b))->SizeOfRawData = MAXDWORD; }, "oversized raw section");
	reject([](auto& b) { IMAGE_FIRST_SECTION(Nt(b))->VirtualAddress = MAXDWORD; }, "overflowing virtual section");
	reject([](auto& b) { Nt(b)->OptionalHeader.AddressOfEntryPoint = 0x1fff; }, "entry point outside raw code");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[1] = {0x1fff, 40}; }, "directory outside image");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[1] = {0x1000, 20};
		auto* d = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(b.data() + 0x200); d->Name = 0x1fff; d->FirstThunk = 0x1fff; }, "unterminated import descriptor or thunk");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[5] = {0x1000, 8};
		reinterpret_cast<IMAGE_BASE_RELOCATION*>(b.data() + 0x200)->SizeOfBlock = 7; }, "relocation block underflow");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[9] = {0x1000, 4}; }, "truncated TLS directory");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[3] = {0x1000, 1}; }, "partial exception record");
	reject([](auto& b) { Nt(b)->OptionalHeader.DataDirectory[4] = {0x800, 0x100}; }, "certificate directory uses file bounds, not image bounds");
	auto importPe = valid;
	Nt(importPe)->OptionalHeader.DataDirectory[1] = {0x1000, 60};
	auto* descriptor = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(importPe.data() + 0x200);
	descriptor->Name = 0x1080; descriptor->OriginalFirstThunk = 0x1100; descriptor->FirstThunk = 0x1120;
	strcpy_s(reinterpret_cast<char*>(importPe.data() + 0x280), 13, "kernel32.dll");
	strcpy_s(reinterpret_cast<char*>(importPe.data() + 0x2a2), 6, "Sleep");
	*reinterpret_cast<ULONG_PTR*>(importPe.data() + 0x300) = 0x10a0;
	Check(ValidatePeImage(importPe.data(), importPe.size(), error), "valid import descriptor and thunk arrays");
	auto badImport = importPe;
	reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(badImport.data() + 0x200)->FirstThunk = 0x1000;
	Check(!ValidatePeImage(badImport.data(), badImport.size(), error), "IAT cannot overwrite import descriptors");
	badImport = importPe;
	reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(badImport.data() + 0x200)->OriginalFirstThunk = 0x1ffc;
	Check(!ValidatePeImage(badImport.data(), badImport.size(), error), "truncated pointer in import thunk array");
	badImport = importPe;
	auto* duplicated = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(badImport.data() + 0x200);
	duplicated[1] = duplicated[0];
	Check(!ValidatePeImage(badImport.data(), badImport.size(), error), "overlapping IAT arrays cannot mutate future import inputs");
	auto relocPe = valid;
	Nt(relocPe)->OptionalHeader.DataDirectory[5] = {0x1000, 12};
	auto* block = reinterpret_cast<IMAGE_BASE_RELOCATION*>(relocPe.data() + 0x200);
	block->VirtualAddress = 0x1000; block->SizeOfBlock = 12;
	*reinterpret_cast<WORD*>(relocPe.data() + 0x208) = (IMAGE_REL_BASED_DIR64 << 12) | 0x100;
	Check(ValidatePeImage(relocPe.data(), relocPe.size(), error), "valid bounded relocation block");
	auto badReloc = relocPe;
	*reinterpret_cast<WORD*>(badReloc.data() + 0x208) = (IMAGE_REL_BASED_DIR64 << 12) | 8;
	Check(!ValidatePeImage(badReloc.data(), badReloc.size(), error), "relocations cannot overwrite their own records");
	badReloc = relocPe;
	reinterpret_cast<IMAGE_BASE_RELOCATION*>(badReloc.data() + 0x200)->VirtualAddress = MAXDWORD;
	Check(!ValidatePeImage(badReloc.data(), badReloc.size(), error), "relocation target arithmetic cannot wrap");
	auto large = valid; Nt(large)->OptionalHeader.SizeOfImage = 0x1600000;
	IMAGE_FIRST_SECTION(Nt(large))->Misc.VirtualSize = 21 * 1024 * 1024;
	Check(ValidatePeImage(large.data(), large.size(), error), "virtual section larger than old 20 MiB erase buffer");
	Check(current && !ManualMapDll(current, large.data(), large.size(), false, true), "destructive section clearing rejected before allocation");
	Check(Shellcode(nullptr) == static_cast<DWORD>(MappingStatus::InvalidData), "null shellcode parameter returns failure");
	auto tls = valid;
	Nt(tls)->OptionalHeader.DataDirectory[9] = {0x1000, sizeof(IMAGE_TLS_DIRECTORY)};
	reinterpret_cast<IMAGE_TLS_DIRECTORY*>(tls.data() + 0x200)->AddressOfIndex = Nt(tls)->OptionalHeader.ImageBase + 0x1100;
	Check(current && ValidatePeImage(tls.data(), tls.size(), error) && !ManualMapDll(current, tls.data(), tls.size()),
		"structurally valid TLS image rejected before remote allocation");
	if (current) CloseHandle(current);
	// Seeded mutations are rejection/robustness coverage, not proof of a complete PE grammar.
	unsigned seed = 0x501;
	for (int i = 0; i < 2000; ++i) {
		auto data = valid; seed = seed * 1664525u + 1013904223u;
		data[seed % data.size()] ^= static_cast<BYTE>((seed >> 24) | 1);
		ValidatePeImage(data.data(), data.size(), error);
	}
	Check(true, "2000 deterministic mutations completed without crash");
}
static void InputTests() {
	DWORD pid = 99;
	Check(ParseTargetPid(L"1", pid) && pid == 1, "minimum PID");
	Check(ParseTargetPid(L"4294967295", pid) && pid == MAXDWORD, "maximum DWORD PID");
	bool rejected = true;
	for (const wchar_t* s : {L"", L"0", L"4294967296", L"18446744073709551616", L"-1", L"+1", L"1x", L" 12"})
		if (ParseTargetPid(s, pid) || pid != 0) rejected = false;
	Check(rejected && !ParseTargetPid(nullptr, pid), "invalid and overflowing PIDs rejected");
	auto first = [](HANDLE, PROCESSENTRY32W* p) { wcscpy_s(p->szExeFile, L"first.exe"); p->th32ProcessID = 7; return TRUE; };
	auto next = [](HANDLE, PROCESSENTRY32W* p) { if (p->th32ProcessID == 7) { wcscpy_s(p->szExeFile, L"second.exe"); p->th32ProcessID = 8; return TRUE; } return FALSE; };
	Check(FindProcessEntry(nullptr, L"FIRST.EXE", first, next) == 7, "first process entry and case-insensitive name");
	Check(FindProcessEntry(nullptr, L"second.exe", first, next) == 8, "subsequent process entry");
	Check(FindProcessEntry(INVALID_HANDLE_VALUE, L"first.exe", first, next) == 0, "invalid snapshot handle");
}
static void PatternTests() {
	BYTE data[]{0xaa, 0x11, 0x22, 0xbb};
	const auto base = reinterpret_cast<ULONG_PTR>(data);
	Check(Pattern::Scan(base, sizeof(data), "AA [1-2] BB") == base, "variable pattern span");
	Check(Pattern::Scan(base, sizeof(data), nullptr) == 0, "null pattern");
	Check(Pattern::Scan(base, sizeof(data), "AA [4294967296-4294967296] BB") == 0, "pattern decimal overflow");
	auto* pages = static_cast<BYTE*>(VirtualAlloc(nullptr, 8192, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
	if (!pages) { Check(false, "allocate pattern guard test"); return; }
	pages[4095] = 0xaa; DWORD old = 0;
	const bool guarded = VirtualProtect(pages + 4096, 4096, PAGE_NOACCESS, &old) != FALSE;
	Check(guarded && Pattern::Scan(reinterpret_cast<ULONG_PTR>(pages + 4095), 2, "AA [0-1] BB") == 0,
		"variable pattern cannot read into no-access page");
	VirtualFree(pages, 0, MEM_RELEASE);
}

struct Child {
	PROCESS_INFORMATION pi{};
	HANDLE ready = nullptr, stop = nullptr;
	bool Start() {
		SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
		ready = CreateEventW(&sa, TRUE, FALSE, nullptr); stop = CreateEventW(&sa, TRUE, FALSE, nullptr);
		wchar_t self[MAX_PATH]{}; GetModuleFileNameW(nullptr, self, MAX_PATH);
		std::wstring command = L"\"" + std::wstring(self) + L"\" --host " +
			std::to_wstring(reinterpret_cast<ULONG_PTR>(ready)) + L" " + std::to_wstring(reinterpret_cast<ULONG_PTR>(stop));
		STARTUPINFOW si{}; si.cb = sizeof(si);
		return ready && stop && CreateProcessW(self, command.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
			nullptr, nullptr, &si, &pi) && WaitForSingleObject(ready, 5000) == WAIT_OBJECT_0;
	}
	~Child() {
		if (pi.hProcess) {
			SetEvent(stop);
			if (WaitForSingleObject(pi.hProcess, 3000) != WAIT_OBJECT_0) {
				// This is exclusively the child created by this fixture.
				TerminateProcess(pi.hProcess, 2); WaitForSingleObject(pi.hProcess, 3000);
			}
			CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
		}
		if (ready) CloseHandle(ready); if (stop) CloseHandle(stop);
	}
	bool Shutdown() {
		DWORD code = 1;
		return SetEvent(stop) && WaitForSingleObject(pi.hProcess, 3000) == WAIT_OBJECT_0 &&
			GetExitCodeProcess(pi.hProcess, &code) && code == 0;
	}
};
static std::set<ULONG_PTR> PrivateAllocations(HANDLE process) {
	std::set<ULONG_PTR> allocations;
	MEMORY_BASIC_INFORMATION info{};
	ULONG_PTR cursor = 0;
	while (VirtualQueryEx(process, reinterpret_cast<void*>(cursor), &info, sizeof(info))) {
		if (info.Type == MEM_PRIVATE && info.AllocationBase) allocations.insert(reinterpret_cast<ULONG_PTR>(info.AllocationBase));
		const auto next = reinterpret_cast<ULONG_PTR>(info.BaseAddress) + info.RegionSize;
		if (next <= cursor) break;
		cursor = next;
	}
	return allocations;
}
static size_t FileOffset(const std::vector<BYTE>& bytes, DWORD rva) {
	const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(bytes.data() + reinterpret_cast<const IMAGE_DOS_HEADER*>(bytes.data())->e_lfanew);
	const auto* section = IMAGE_FIRST_SECTION(nt);
	for (WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i) if (rva >= section[i].VirtualAddress &&
		size_t(rva) - section[i].VirtualAddress < section[i].SizeOfRawData)
		return size_t(section[i].PointerToRawData) + rva - section[i].VirtualAddress;
	return bytes.size();
}
static void AddressTests(std::vector<BYTE>& payload) {
	Child child;
	if (!child.Start()) { Check(false, "I-05 owned child starts"); return; }
	RemoteApiAddresses addresses;
	std::string error;
	const bool verified = VerifyRemoteApis(child.pi.hProcess, true, addresses, error);
	Check(verified && addresses.loadLibraryA && addresses.getProcAddress && addresses.rtlAddFunctionTable &&
		addresses.raiseException && addresses.rtlPcToFileHeader, "I-05 all five API locations verified in owned child");
	if (!verified) printf("I-05 positive check: %s\n", error.c_str());
	const FARPROC pointers[] = {addresses.loadLibraryA, addresses.getProcAddress, addresses.rtlAddFunctionTable, addresses.raiseException, addresses.rtlPcToFileHeader};
	const char* names[] = {"LoadLibraryA", "GetProcAddress", "RtlAddFunctionTable", "RaiseException", "RtlPcToFileHeader"};
	if (verified) for (size_t i = 0; i < 5; ++i) {
		HMODULE owner = nullptr; wchar_t path[MAX_PATH]{};
		if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
			reinterpret_cast<LPCWSTR>(pointers[i]), &owner)) GetModuleFileNameW(owner, path, MAX_PATH);
		printf("I-05 observed %s=%p owner=%ls\n", names[i], reinterpret_cast<void*>(pointers[i]), path);
	}
	struct Case { RemoteApiTestFault fault; size_t index; const char* diagnostic; const char* label; };
	const Case cases[] = {
		{RemoteApiTestFault::ArchitectureUnavailable, 0, "IsWow64Process2 unavailable", "I-05 missing architecture API fails closed"},
		{RemoteApiTestFault::ArchitectureMismatch, 0, "native AMD64", "I-05 unsupported architecture fails closed"},
		{RemoteApiTestFault::SnapshotFailed, 0, "CreateToolhelp32Snapshot", "I-05 snapshot failure fails closed"},
		{RemoteApiTestFault::EnumerationFailed, 0, "Module32FirstW", "I-05 enumeration failure fails closed"},
		{RemoteApiTestFault::OwnerMissing, 0, "owning module absent", "I-05 absent owning module fails closed"},
		{RemoteApiTestFault::PathMismatch, 0, "path differs", "I-05 module path mismatch fails closed"},
		{RemoteApiTestFault::BaseMismatch, 0, "base differs", "I-05 module base mismatch fails closed"},
		{RemoteApiTestFault::IdentityMismatch, 0, "PE identity differs", "I-05 module PE identity mismatch fails closed"},
		{RemoteApiTestFault::ReadFailed, 0, "header read", "I-05 remote read failure fails closed"},
		{RemoteApiTestFault::ExportMissing, 0, "export unavailable", "I-05 absent target export fails closed"},
		{RemoteApiTestFault::ForwardedExport, 0, "forwarded export", "I-05 unsupported owner forwarder fails closed"},
		{RemoteApiTestFault::NotExecutable, 0, "not executable", "I-05 non-executable target address fails closed"},
		{RemoteApiTestFault::LocalExportMissing, 0, "LoadLibraryA", "I-05 missing LoadLibraryA fails closed"},
		{RemoteApiTestFault::LocalExportMissing, 1, "GetProcAddress", "I-05 missing GetProcAddress fails closed"},
		{RemoteApiTestFault::LocalExportMissing, 2, "RtlAddFunctionTable", "I-05 missing RtlAddFunctionTable fails closed"},
		{RemoteApiTestFault::LocalExportMissing, 3, "RaiseException", "I-05 missing embedded RaiseException fails closed"},
		{RemoteApiTestFault::LocalExportMissing, 4, "RtlPcToFileHeader", "I-05 missing embedded RtlPcToFileHeader fails closed"},
		{RemoteApiTestFault::ExportMismatch, 1, "GetProcAddress", "I-05 GetProcAddress RVA mismatch fails closed"},
		{RemoteApiTestFault::ExportMismatch, 2, "RtlAddFunctionTable", "I-05 RtlAddFunctionTable RVA mismatch fails closed"},
		{RemoteApiTestFault::ExportMismatch, 3, "RaiseException", "I-05 embedded RaiseException RVA mismatch fails closed"},
		{RemoteApiTestFault::ExportMismatch, 4, "RtlPcToFileHeader", "I-05 embedded RtlPcToFileHeader RVA mismatch fails closed"}
	};
	for (const auto& test : cases) {
		const auto before = PrivateAllocations(child.pi.hProcess);
		DWORD beforeHandles = 0, afterHandles = 0; GetProcessHandleCount(GetCurrentProcess(), &beforeHandles);
		gRemoteApiTestFault = test.fault; gRemoteApiTestIndex = test.index;
		addresses.loadLibraryA = reinterpret_cast<FARPROC>(1); // output must be cleared, never called
		const bool failedSafely = !VerifyRemoteApis(child.pi.hProcess, true, addresses, error) &&
			!addresses.loadLibraryA && !addresses.getProcAddress && !addresses.rtlAddFunctionTable &&
			!addresses.raiseException && !addresses.rtlPcToFileHeader && error.find(test.diagnostic) != std::string::npos;
		const bool mappingRejected = !ManualMapDll(child.pi.hProcess, payload.data(), payload.size());
		gRemoteApiTestFault = RemoteApiTestFault::None; gRemoteApiTestIndex = 0;
		GetProcessHandleCount(GetCurrentProcess(), &afterHandles);
		Check(failedSafely && mappingRejected && before == PrivateAllocations(child.pi.hProcess) &&
			beforeHandles == afterHandles && WaitForSingleObject(child.pi.hProcess, 0) == WAIT_TIMEOUT, test.label);
		if (!failedSafely) printf("I-05 unexpected diagnostic: %s\n", error.c_str());
	}
	gRemoteApiTestFault = RemoteApiTestFault::LocalExportMissing; gRemoteApiTestIndex = 4;
	Check(VerifyRemoteApis(child.pi.hProcess, false, addresses, error) && addresses.loadLibraryA && addresses.getProcAddress &&
		!addresses.rtlAddFunctionTable && !addresses.raiseException && !addresses.rtlPcToFileHeader,
		"I-05 disabled exception support does not require optional APIs");
	gRemoteApiTestFault = RemoteApiTestFault::None; gRemoteApiTestIndex = 0;
	HANDLE noRead = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, child.pi.dwProcessId);
	Check(noRead && !VerifyRemoteApis(noRead, true, addresses, error) && error.find("read") != std::string::npos &&
		error.find("Win32=5") != std::string::npos, "I-05 real missing read access reports access denied");
	if (noRead) CloseHandle(noRead);
	Check(!VerifyRemoteApis(nullptr, true, addresses, error) && error.find("GetProcessId") != std::string::npos,
		"I-05 invalid process handle reports failure");
	Check(child.Shutdown() && !VerifyRemoteApis(child.pi.hProcess, true, addresses, error) &&
		error.find("target has exited") != std::string::npos, "I-05 exited owned child rejected");
}
static void MappingTests(std::vector<BYTE>& payload) {
	for (int iteration = 0; iteration < 4; ++iteration) {
		Child child;
		if (!child.Start()) { Check(false, "controlled child starts"); continue; }
		TestControl control{}; control.delayMs = 150; control.accept = (iteration != 1);
		auto* remote = VirtualAllocEx(child.pi.hProcess, nullptr, sizeof(control), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		if (!remote || !WriteProcessMemory(child.pi.hProcess, remote, &control, sizeof(control), nullptr)) {
			Check(false, "controlled test data allocation"); continue;
		}
		DWORD handlesBefore = 0, handlesAfter = 0;
		GetProcessHandleCount(GetCurrentProcess(), &handlesBefore);
		const auto allocationsBefore = PrivateAllocations(child.pi.hProcess);
		const ULONGLONG start = GetTickCount64();
		const bool mapped = ManualMapDll(child.pi.hProcess, payload.data(), payload.size(), false, false,
			true, iteration >= 2, false, DLL_PROCESS_ATTACH, remote);
		const ULONGLONG elapsed = GetTickCount64() - start;
		GetProcessHandleCount(GetCurrentProcess(), &handlesAfter);
		const bool read = ReadProcessMemory(child.pi.hProcess, remote, &control, sizeof(control), nullptr) != FALSE;
		Check(mapped == (control.accept != FALSE) && read && control.entered && control.returning && control.relocationOk,
			iteration == 1 ? "entrypoint FALSE propagates failure" : "controlled attach, imports, and relocation");
		Check(elapsed >= 140, "mapper waits for actual entrypoint return");
		Check(handlesBefore == handlesAfter, "remote thread handle released");
		const auto allocationsAfter = PrivateAllocations(child.pi.hProcess);
		std::vector<ULONG_PTR> added;
		std::set_difference(allocationsAfter.begin(), allocationsAfter.end(), allocationsBefore.begin(), allocationsBefore.end(), std::back_inserter(added));
		Check(added.size() == (iteration >= 2 ? 3u : 1u), "only image and requested exception support remain allocated");
		WORD mz = 0;
		Check(control.imageBase && ReadProcessMemory(child.pi.hProcess, reinterpret_cast<void*>(control.imageBase), &mz, sizeof(mz), nullptr) && mz == IMAGE_DOS_SIGNATURE,
			"PE metadata retained including after initialization failure");
		VirtualFreeEx(child.pi.hProcess, remote, 0, MEM_RELEASE);
		Check(child.Shutdown(), "controlled child reports clean shutdown");
	}
	Child child;
	if (!child.Start()) { Check(false, "failure fixture child starts"); return; }
	Check(!ManualMapDll(child.pi.hProcess, payload.data(), 10), "malformed PE rejected against controlled child");
	HANDLE readOnly = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, child.pi.dwProcessId);
	Check(readOnly && !ManualMapDll(readOnly, payload.data(), payload.size()), "allocation permission failure propagates");
	if (readOnly) CloseHandle(readOnly);
	const auto beforeFailure = PrivateAllocations(child.pi.hProcess);
	InjectorTestFailThreadCreation = true;
	const bool threadFailure = !ManualMapDll(child.pi.hProcess, payload.data(), payload.size());
	InjectorTestFailThreadCreation = false;
	Check(threadFailure, "injected thread-creation failure propagates");
	Check(beforeFailure == PrivateAllocations(child.pi.hProcess), "all remote allocations released before thread creation");
	for (bool missingModule : {true, false}) {
		auto broken = payload;
		const auto importRva = Nt(broken)->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
		auto* descriptor = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(broken.data() + FileOffset(broken, importRva));
		if (missingModule) {
			strcpy_s(reinterpret_cast<char*>(broken.data() + FileOffset(broken, descriptor->Name)), 13, "absent42.dll");
		} else {
			const auto thunkRva = descriptor->OriginalFirstThunk ? descriptor->OriginalFirstThunk : descriptor->FirstThunk;
			const auto nameRva = static_cast<DWORD>(*reinterpret_cast<const ULONG_PTR*>(broken.data() + FileOffset(broken, thunkRva)));
			strcpy_s(reinterpret_cast<char*>(broken.data() + FileOffset(broken, nameRva) + sizeof(WORD)), 6, "NopeX");
		}
		Check(!ManualMapDll(child.pi.hProcess, broken.data(), broken.size(), false, false, true, false, false),
			missingModule ? "missing dependency module fails initialization" : "missing imported symbol fails initialization");
	}
	Check(child.Shutdown(), "failure fixture reports clean shutdown");
}
static void TimeoutTest(std::vector<BYTE>& payload) {
	Child child;
	if (!child.Start()) { Check(false, "timeout child starts"); return; }
	TestControl control{}; control.delayMs = 31000; control.accept = TRUE;
	void* remote = VirtualAllocEx(child.pi.hProcess, nullptr, sizeof(control), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!remote || !WriteProcessMemory(child.pi.hProcess, remote, &control, sizeof(control), nullptr)) {
		Check(false, "timeout control allocation"); return;
	}
	const auto started = GetTickCount64();
	const bool mapped = ManualMapDll(child.pi.hProcess, payload.data(), payload.size(), false, false, true, false, false, DLL_PROCESS_ATTACH, remote);
	Check(!mapped && GetTickCount64() - started >= 29000, "30-second timeout reported as failure");
	Sleep(1500);
	const bool read = ReadProcessMemory(child.pi.hProcess, remote, &control, sizeof(control), nullptr) != FALSE;
	Check(read && control.entered && control.returning && WaitForSingleObject(child.pi.hProcess, 0) == WAIT_TIMEOUT,
		"retained code and data allow thread to finish safely after timeout");
	if (read && control.returning) VirtualFreeEx(child.pi.hProcess, remote, 0, MEM_RELEASE);
	Check(child.Shutdown(), "timeout child shuts down after thread completion");
}
static std::wstring CliPath(const std::wstring& payloadPath) {
	const DWORD size = GetEnvironmentVariableW(L"INJECTOR_TEST_CLI_PATH", nullptr, 0);
	if (size) {
		std::wstring path(size, L'\0');
		const DWORD copied = GetEnvironmentVariableW(L"INJECTOR_TEST_CLI_PATH", path.data(), size);
		if (copied && copied < size) { path.resize(copied); return path; }
	}
	return payloadPath.substr(0, payloadPath.find_last_of(L"\\/") + 1) + L"Injector-x64.exe";
}
struct ConsoleResult { bool finished = false; DWORD code = MAXDWORD; std::string text; };
static ConsoleResult RunConsole(const std::wstring& exe, const std::wstring& args, const std::string& input = "") {
	struct Handles { HANDLE h[6]{}; ~Handles() { for (HANDLE value : h) if (value) CloseHandle(value); } } handles;
	ConsoleResult result;
	SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
	if (!CreatePipe(&handles.h[0], &handles.h[1], &sa, 0) || !CreatePipe(&handles.h[2], &handles.h[3], &sa, 0)) return result;
	SetHandleInformation(handles.h[0], HANDLE_FLAG_INHERIT, 0);
	SetHandleInformation(handles.h[3], HANDLE_FLAG_INHERIT, 0);
	STARTUPINFOW si{}; si.cb = sizeof(si); si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = handles.h[2]; si.hStdOutput = si.hStdError = handles.h[1];
	std::wstring command = L"\"" + exe + L"\" " + args;
	PROCESS_INFORMATION pi{};
	if (!CreateProcessW(exe.c_str(), command.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) return result;
	handles.h[4] = pi.hProcess; handles.h[5] = pi.hThread;
	CloseHandle(handles.h[1]); handles.h[1] = nullptr;
	CloseHandle(handles.h[2]); handles.h[2] = nullptr;
	DWORD written = 0;
	if (!input.empty()) WriteFile(handles.h[3], input.data(), static_cast<DWORD>(input.size()), &written, nullptr);
	CloseHandle(handles.h[3]); handles.h[3] = nullptr;
	const auto started = GetTickCount64();
	for (;;) {
		DWORD available = 0;
		while (PeekNamedPipe(handles.h[0], nullptr, 0, nullptr, &available, nullptr) && available) {
			char data[4096]; DWORD count = 0;
			if (!ReadFile(handles.h[0], data, (std::min)(available, DWORD(sizeof(data))), &count, nullptr)) break;
			result.text.append(data, count);
		}
		if (WaitForSingleObject(pi.hProcess, 5) == WAIT_OBJECT_0) {
			if (PeekNamedPipe(handles.h[0], nullptr, 0, nullptr, &available, nullptr) && available) continue;
			result.finished = GetExitCodeProcess(pi.hProcess, &result.code) != FALSE;
			break;
		}
		if (GetTickCount64() - started > 10000) { TerminateProcess(pi.hProcess, 2); WaitForSingleObject(pi.hProcess, 3000); break; }
	}
	return result;
}
static void ReleaseReliabilityTests(std::vector<BYTE>& payload, const std::wstring& payloadPath) {
	std::string error;
	auto pe = MinimalPe();
	InjectorTestFailValidationAllocation = true;
	const bool validationFailed = !ValidatePeImage(pe.data(), pe.size(), error) && error.find("allocation failed") != std::string::npos;
	InjectorTestFailValidationAllocation = false;
	Check(validationFailed, "release validation allocation failure reports an error");
	auto unwind = MinimalPe();
	Nt(unwind)->OptionalHeader.DataDirectory[3] = {0x1000, sizeof(RUNTIME_FUNCTION)};
	auto* function = reinterpret_cast<RUNTIME_FUNCTION*>(unwind.data() + 0x200);
	*function = {0x1100, 0x1120, 0x1080}; unwind[0x280] = 1;
	Check(ValidatePeImage(unwind.data(), unwind.size(), error), "release simple version-1 unwind metadata validates");
	auto chain = unwind; chain[0x280] = (4 << 3) | 1;
	*reinterpret_cast<RUNTIME_FUNCTION*>(chain.data() + 0x284) = {0x1100, 0x1120, 0x1090}; chain[0x290] = 1;
	Check(ValidatePeImage(chain.data(), chain.size(), error), "release bounded chained unwind metadata validates");
	chain[0x280] = (1 << 3) | 1;
	Check(!ValidatePeImage(chain.data(), chain.size(), error) && error.find("language-specific") != std::string::npos, "release language-specific handlers are explicitly unsupported");
	chain = unwind; chain[0x280] = (4 << 3) | 1;
	*reinterpret_cast<RUNTIME_FUNCTION*>(chain.data() + 0x284) = {0x1100, 0x1120, 0x1080};
	Check(!ValidatePeImage(chain.data(), chain.size(), error) && error.find("Cyclic") != std::string::npos, "release cyclic unwind chain rejected");
	chain = unwind; chain[0x280] = 2;
	Check(!ValidatePeImage(chain.data(), chain.size(), error), "release unsupported unwind version rejected");
	chain = unwind; chain[0x282] = 1; chain[0x285] = 0x11;
	Check(!ValidatePeImage(chain.data(), chain.size(), error), "release incomplete multi-slot unwind operation rejected");
	Child child;
	if (!child.Start()) { Check(false, "release failure child starts"); return; }
	const auto before = PrivateAllocations(child.pi.hProcess);
	InjectorTestFailHostAllocation = true;
	const bool hostFailed = !ManualMapDll(child.pi.hProcess, payload.data(), payload.size());
	InjectorTestFailHostAllocation = false;
	Check(hostFailed && before == PrivateAllocations(child.pi.hProcess), "release host allocation exception fails without remote allocation");
	for (int index = 0; index < 5; ++index) {
		InjectorTestFailAllocationAt = index;
		const bool failedSafely = !ManualMapDll(child.pi.hProcess, payload.data(), payload.size());
		InjectorTestFailAllocationAt = -1;
		Check(failedSafely && before == PrivateAllocations(child.pi.hProcess), "release each remote allocation failure releases earlier allocations");
	}
	TestControl control{}; control.exitCode = 73; control.accept = TRUE;
	void* remote = VirtualAllocEx(child.pi.hProcess, nullptr, sizeof(control), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!remote || !WriteProcessMemory(child.pi.hProcess, remote, &control, sizeof(control), nullptr)) { Check(false, "release exit-control allocation"); return; }
	const auto started = GetTickCount64();
	const bool mapped = ManualMapDll(child.pi.hProcess, payload.data(), payload.size(), false, false, true, false, false, DLL_PROCESS_ATTACH, remote);
	DWORD exitCode = 0;
	Check(!mapped && GetTickCount64() - started < 5000 && WaitForSingleObject(child.pi.hProcess, 1000) == WAIT_OBJECT_0 &&
		GetExitCodeProcess(child.pi.hProcess, &exitCode) && exitCode == 73, "release target exit during initialization reports prompt failure");
	auto first = [](HANDLE, PROCESSENTRY32W* e) { wcscpy_s(e->szExeFile, L"duplicate.exe"); e->th32ProcessID = 7; return TRUE; };
	auto next = [](HANDLE, PROCESSENTRY32W* e) { if (e->th32ProcessID == 7) { e->th32ProcessID = 8; return TRUE; } return FALSE; };
	size_t matches = 0;
	Check(FindUniqueProcessEntry(nullptr, L"duplicate.exe", first, next, matches) == 0 && matches == 2, "release ambiguous names require explicit PID selection");
	(void)payloadPath;
}
static void ReleaseConsoleTests(const std::wstring& payloadPath) {
	const auto exe = CliPath(payloadPath);
	const std::wstring eventName = L"Local\\InjectorReady-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64());
	HANDLE event = CreateEventW(nullptr, TRUE, FALSE, eventName.c_str());
	SetEnvironmentVariableW(L"INJECTOR_TEST_READY_EVENT", eventName.c_str());
	Child child; const bool started = child.Start();
	SetEnvironmentVariableW(L"INJECTOR_TEST_READY_EVENT", nullptr);
	if (!started || !event) { if (event) CloseHandle(event); Check(false, "release observable host starts"); return; }
	auto run = [&](const std::wstring& args, DWORD code, const char* text, const char* label, const std::string& input = "") {
		const auto result = RunConsole(exe, args, input);
		const bool ok = result.finished && result.code == code && result.text.find(text) != std::string::npos;
		Check(ok, label);
		if (!ok) printf("Console result code=%lu: %s\n", result.code, result.text.c_str());
	};
	const auto quoted = L"\"" + payloadPath + L"\"";
	const auto pid = std::to_wstring(child.pi.dwProcessId);
	run(L"--help", 0, "--check", "release CLI help describes supported workflow");
	run(L"--list", 0, std::to_string(child.pi.dwProcessId).c_str(), "release read-only process list includes owned child");
	run(L"--check " + quoted, 0, "No DLL code was executed", "release offline DLL preflight does not execute initialization");
	Check(WaitForSingleObject(event, 0) == WAIT_TIMEOUT, "release preflight has no initialization side effect");
	const auto before = PrivateAllocations(child.pi.hProcess);
	run(L"", 0, "Cancelled", "release blank DLL selection cancels safely", "\n");
	run(quoted, 0, "Cancelled", "release target selection cancels safely", "\n");
	run(quoted, 0, "Cancelled", "release final interactive confirmation cancels safely", std::to_string(child.pi.dwProcessId) + "\nn\n");
	Check(before == PrivateAllocations(child.pi.hProcess), "release cancellation leaves owned target unchanged");
	run(L"--spawn " + quoted + L" " + quoted, static_cast<DWORD>(-11), "No process was launched", "release suspended startup explicitly rejected");
	run(L"--unknown", static_cast<DWORD>(-10), "Usage", "release invalid arguments have failure exit code");
	for (int iteration = 0; iteration < 2; ++iteration) {
		ResetEvent(event);
		run(quoted + L" " + pid, 0, "entry point completed successfully", "release repeated production CLI initialization completes");
		Check(WaitForSingleObject(event, 0) == WAIT_OBJECT_0, "release end-to-end initialization observed through target event");
	}
	const std::wstring badPath = payloadPath + L".fixture";
	auto reject = [&](std::vector<BYTE> bytes, const char* diagnostic, const char* label) {
		{ std::ofstream file(badPath, std::ios::binary); file.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size())); }
		run(L"--check \"" + badPath + L"\"", static_cast<DWORD>(-6), diagnostic, label);
	};
	reject(std::vector<BYTE>(10), "DOS header", "release CLI malformed PE reports rejection");
	auto wrongArch = MinimalPe(); Nt(wrongArch)->FileHeader.Machine = IMAGE_FILE_MACHINE_I386;
	reject(wrongArch, "architecture", "release CLI wrong architecture reports rejection");
	auto tls = MinimalPe(); Nt(tls)->OptionalHeader.DataDirectory[9] = {0x1000, sizeof(IMAGE_TLS_DIRECTORY)};
	reinterpret_cast<IMAGE_TLS_DIRECTORY*>(tls.data() + 0x200)->AddressOfIndex = Nt(tls)->OptionalHeader.ImageBase + 0x1100;
	reject(tls, "TLS", "release CLI unsupported TLS reports rejection");
	auto config = MinimalPe(); Nt(config)->OptionalHeader.DataDirectory[10] = {0x1100, 0x40};
	reject(config, "load-config/CFG", "release CLI unsupported load-config reports rejection");
	DeleteFileW(badPath.c_str());
	SetEnvironmentVariableW(L"INJECTOR_TEST_REJECT_ATTACH", L"1");
	Child rejected; const bool failureStarted = rejected.Start();
	SetEnvironmentVariableW(L"INJECTOR_TEST_REJECT_ATTACH", nullptr);
	if (failureStarted) run(quoted + L" " + std::to_wstring(rejected.pi.dwProcessId), static_cast<DWORD>(-8), "Operation failed", "release production CLI rejects failed initialization");
	else Check(false, "release rejected-initialization host starts");
	Check(child.Shutdown(), "release observable host shuts down cleanly");
	run(quoted + L" " + pid, static_cast<DWORD>(-2), "Target process has exited", "release production CLI reports exited owned target");
	CloseHandle(event);
}
static void CliTests(const std::wstring& payloadPath) {
	Child child;
	if (!child.Start()) { Check(false, "CLI target starts"); return; }
	std::wstring injectorPath = CliPath(payloadPath);
	auto run = [&](const std::wstring& args, DWORD expected, const char* label) {
		std::wstring command = L"\"" + injectorPath + L"\" " + args;
		STARTUPINFOW si{}; si.cb = sizeof(si); PROCESS_INFORMATION pi{};
		bool ok = CreateProcessW(injectorPath.c_str(), command.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi) != FALSE;
		if (ok) {
			const DWORD waited = WaitForSingleObject(pi.hProcess, 10000); DWORD code = 0;
			ok = waited == WAIT_OBJECT_0 && GetExitCodeProcess(pi.hProcess, &code) && code == expected;
			if (waited != WAIT_OBJECT_0) { TerminateProcess(pi.hProcess, 2); WaitForSingleObject(pi.hProcess, 3000); }
			CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
		}
		Check(ok, label);
	};
	run(L"\"" + payloadPath + L"\" " + std::to_wstring(child.pi.dwProcessId), 0, "production CLI maps source-built payload into owned child");
	run(L"\"" + payloadPath + L"\" 4294967296", static_cast<DWORD>(-1), "production CLI rejects overflowing PID");
	run(L"\"" + payloadPath + L".missing\" " + std::to_wstring(child.pi.dwProcessId), static_cast<DWORD>(-4), "production CLI reports missing input file");
	Check(WaitForSingleObject(child.pi.hProcess, 0) == WAIT_TIMEOUT && child.Shutdown(), "CLI target remains healthy and shuts down");
}
int wmain(int argc, wchar_t** argv) {
	if (argc == 4 && wcscmp(argv[1], L"--host") == 0) {
		HANDLE ready = reinterpret_cast<HANDLE>(_wcstoui64(argv[2], nullptr, 10));
		HANDLE stop = reinterpret_cast<HANDLE>(_wcstoui64(argv[3], nullptr, 10));
		SetEvent(ready); const DWORD wait = WaitForSingleObject(stop, 60000);
		CloseHandle(ready); CloseHandle(stop); return wait == WAIT_OBJECT_0 ? 0 : 1;
	}
	ValidationTests(); InputTests(); PatternTests();
	wchar_t path[MAX_PATH]{}; GetModuleFileNameW(nullptr, path, MAX_PATH);
	std::wstring payloadPath(path); payloadPath.erase(payloadPath.find_last_of(L"\\/") + 1); payloadPath += L"TestPayload.dll";
	std::ifstream file(payloadPath, std::ios::binary);
	std::vector<BYTE> payload((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
	std::string error;
	const bool valid = !payload.empty() && ValidatePeImage(payload.data(), payload.size(), error);
	Check(valid, "locally built payload passes PE validation");
	if (valid) { AddressTests(payload); MappingTests(payload); CliTests(payloadPath); ReleaseReliabilityTests(payload, payloadPath); ReleaseConsoleTests(payloadPath); TimeoutTest(payload); }
	printf("RESULT: %d passed, %d failed\n", passed, failed);
	return failed ? 1 : 0;
}
