// Built from this source only. No CRT, static TLS, workers, hooks, or UI.
#include "TestControl.h"
static int anchor = 123;
static int* volatile relocatedAnchor = &anchor;
extern "C" BOOL WINAPI TestDllMain(HINSTANCE module, DWORD reason, LPVOID reserved) {
	if (reason != DLL_PROCESS_ATTACH) return FALSE;
	if (!reserved) {
		if (relocatedAnchor != &anchor || *relocatedAnchor != 123) return FALSE;
		wchar_t reject[2];
		if (GetEnvironmentVariableW(L"INJECTOR_TEST_REJECT_ATTACH", reject, 2) == 1 && reject[0] == L'1') return FALSE;
		wchar_t name[160];
		DWORD length = GetEnvironmentVariableW(L"INJECTOR_TEST_READY_EVENT", name, 160);
		if (length) {
			if (length >= 160) return FALSE;
			HANDLE ready = OpenEventW(EVENT_MODIFY_STATE, FALSE, name);
			if (!ready) return FALSE;
			BOOL signaled = SetEvent(ready); CloseHandle(ready);
			return signaled;
		}
		return TRUE;
	}
	auto* control = static_cast<TestControl*>(reserved);
	control->imageBase = reinterpret_cast<ULONG_PTR>(module);
	control->relocationOk = relocatedAnchor == &anchor && *relocatedAnchor == 123;
	control->entered = 1;
	if (control->exitCode) ExitProcess(control->exitCode);
	Sleep(control->delayMs);
	control->returning = 1;
	return control->accept;
}
