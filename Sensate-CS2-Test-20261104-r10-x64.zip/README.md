# Sensate r10 Windows x64 test release

Start Sensate.cmd (or OsirisLauncher.exe): one unified ImGui/DX11 window. Home contains Load Sensate and connection/loading state. Settings, profiles and Diagnostics use the same backend. No automatic loading or gameplay input on startup.
Read FIRST_RUNTIME_TEST.md. Keep existing configs; extract into a separate folder. Exit an older UI before switching versions. The old launcher is available with --legacy; classic settings with --classic. Default starts reuse the same settings singleton.

Compatibility: current installed Float4 caller signature verified, old entry signature had0 hits. Sound72-byte guarded layout retained. Fresh file-only metadata resolves14/14; initialized live objects/camera/hitboxes remain unverified. Sound/Model Glow actual CS2 checks remain pending.
1619/1619 CTest per Release/Debug, clang-tidy exit0; injector144/144 each. Own DX11/singleton/IPC tests are actual Windows execution, not CS2 evidence. Native aim/fire/jump/spin disabled. Physical Insert/Alt-Tab, transient flicker and end-to-end load into CS2 require the user's isolated test. v143 unverified.
R10_* evidence is current. Other inherited evidence files name historical revisions and do not establish r10 runtime compatibility. Prior r9 ZIP/configurations were preserved.
