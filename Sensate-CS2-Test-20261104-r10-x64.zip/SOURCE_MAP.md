# r3 additions — 2026-10-23

- Source/Automation/Movement.h: bunnyhop/spin engines and explicit-arm proposal controller; helper-only.
- Tools/InputHost/MovementSimulation.h: deterministic snapshot-to-proposal integration, no native input.
- GameplaySnapshot.h: optional grounded, unknown from current live collector.
- Settings.h / Config.h / AutomationTab.h / AutomationSettings.js:12 persisted parameters, emergency stop and bounded-stack control update.
- Tools/SettingsMenu: separate Sound/Movement pages; Tools/Launcher: automatic menu reuse and owned lifecycle check.
- Tests/UnitTests/Gameplay/AutomationMovementTests.cpp; MemorySearch/{SoundLayoutPatternTests,AttributePatternTests}.cpp; SoundSafetyTests raw72-byte fixture.
- build/patch-r3: original/fixed stride probe, dump summaries, installed-file signature/disassembly evidence and build/package manifests. Not runtime sign-off.

# Källkodskarta

## Launcher and Sound corrections — 2026-10-23 r2

- Tools/Launcher/{LaunchPolicy,WindowsServices,IntegrationTests}.h + main.cpp: argument-based mode policy, quoting, bounded hash/PE checks, explicit one-attempt CLI orchestration, menu/helper children and owned-host initialization verification. CMake reuses Simple-Manual-Map-Injector-master/Manual Map Injector/PeValidation.cpp; the independent injector source/project/tests remain unchanged.
- Source/MemorySearch/{PatternFinder,PatternNotFoundLogger}.h: Release duplicate rejection and explicit missing/ambiguous diagnostics. Tests/UnitTests/MemorySearch/PatternUniquenessTests.cpp reproduces the previous ambiguity.
- Source/Features/Sound/Details/{SoundWatcherImpl,SoundWatcherImplState,WatchedSounds,SoundVisualizationFeature}.h: paired-array validity, copied-sample invalidation, bounds/toggle/shutdown, render guards and separate Defuse config. GameClient/FileNameSymbolTable.h now preserves lookup success/failure.
- Source/Features/Common/InWorldPanels.h + GameClient/Panorama/{PanoramaUiPanelChildPanels,PanoramaTransformations,PanelStylePropertyFactory}.h: Sound reservation before UI creation, failed allocation/null storage/transform checks. EntryPoints unload terminally shuts down sound collection. PanoramaGUI/CreateGUI/PanoramaGuiState and native menu explain Sound status/runtime limits.
- PlayerInfoPanelCache.h/PlayerInfoInWorld.h and InWorldPanels: shared player metadata/cache/UI rollback and checked optional panel on pool failure; no unchecked/wrapped cache entry.
- Tests/UnitTests/Features/Sound/SoundSafetyTests.cpp:43 Sound/shared allocation tests; Tests/UnitTests/Launcher/LaunchPolicyTests.cpp:11 policy/argv tests. build/launcher-integration-20261023 contains before copies, original/current native probes, pattern disassembly, builds/tests/tidy and delivery verification.

## Offline automation implementation — 2026-10-22

- Source/Gameplay/GameplaySnapshot.h / GameplayState.h: optional extended data contracts, fixed publication storage, sample reset; collector/callback defaults unchanged.
- Source/Automation/Settings.h / ProfileSettings.h: 44 global integer descriptors, 68 typed embedded-profile variables, fixed four-entry overrides and config-to-consumer conversion.
- Source/Automation/SettingsCommands.h / ConfigDocument.h: strict Panorama commands, safe presets/defaults, existing-schema config codec and separate versioned helper-profile codec.
- Source/Automation/Geometry.h / DecisionData.h: finite angle/ray/smoothing/calibration math, freshness/identity/filter contracts; normal-CRT helper only.
- Source/Automation/Aim.h / Trigger.h: independent deterministic proposal state machines; no native input/game writes.
- Source/Automation/Input.h / Coordinator.h: explicit wire encoding, activation, calibrated bounded count conversion, nonce/session/revision/age/rate/watchdog and single output ownership.
- Source/Automation/WindowsInputSink.h: paired SendInput, physical-key/emergency/focus recheck, partial-send cleanup; own-process receiver restriction.
- Tools/InputHost/{CMakeLists.txt,main.cpp,OfflineSimulation.h}: standalone OsirisInput, --receiver-test (owned Windows window only), --self-test / --simulate / --benchmark (synthetic, no native input).
- Source/Config/{ConfigVariableTypes,ConfigSchema,ConfigState,Config,ConfigPersistence}.h / Source/Platform/Windows/FileSystem/WindowsFileSystem.h: shared metadata registration, validated staging, bounded complete save, checked replacement/failure/dirty handling.
- Source/UI/Panorama/{AutomationTab.h,AutomationSettings.js,CombatTab.h,CreateGUI.js,SetCommandHandler.h}: existing Combat tab expansion, shared numeric/profile controls and command routing; no overlay/framework.
- Tests/Fixtures/AutomationFrame.h, Tests/UnitTests/Gameplay/Automation{Input,Aim,Trigger,Settings}Tests.cpp, GameplaySnapshotTests.cpp, Config/ConfigPersistenceTests.cpp: deterministic isolated regressions. Tests/FunctionalTests/Config/ConfigCompatibilityTests.cpp: real transaction/compatibility/save-preparation state tests. Tests/Panorama/AutomationUiTests.cjs: full menu mock and 112 controls (existing Node only; optional CTest dev dependency).
- build/offline-development/: backup/hash manifest, exact changed-file list, build/test/tidy/import logs, size/performance and receiver evidence. Historical baseline manifest and config_v1–v9 are unchanged.

Granskad 2026-10-22 mot den tillhandahållna lokala baslinjen. Alla hänvisningar är enbaserade startlinjer; `fil:rad` är sökbar källreferens. Inga nedan föreslagna nya typer finns i baslinjen. Manifest: [baseline-sha256.json](evidence/baseline-sha256.json), 746 filer, varav 607 i Source och 128 i Tests.

## M1.2: callback- och provenance-tillägg

Implementerad M1.2 kompletterar M1.1 med Source/Gameplay/GameplayCallbackState.h (atomisk render-port, explicit startup-diagnostikläge och begränsade callbackobservationer). GameplaySnapshot/GameplayState har provenance, tidsprogression, felorsaker, antal förkastade kandidatrader och terminal shutdown. EntryPoints initierar/stänger livscykeln, skyddar normal render-efterbearbetning och registrerar scene-callbacks utan payloadåtkomst. WindowsPlatformApi använder SDK:s importfria NtCurrentTeb som diagnostisk trådtoken. Tests/UnitTests/Gameplay/GameplayProvenanceTests.cpp har 21 nya fall, inklusive faktiska testtrådar. Ingen CS2-runtime är verifierad; M1_2_RUNTIME_CHECKLIST.md är nästa uppgift.

## M1.1: tillägg efter granskningsbaslinjen

Följande är nu implementerat; återstoden av kartan beskriver fas 1 och dess linjenummer är historiska. Runtime i CS2 är inte verifierad.

| Källa | Faktiskt ansvar och begränsning |
|---|---|
| `Source/Gameplay/GameplaySnapshot.h` | EntityKey (full handle + session), SnapshotId, status, optional player/weapon-värden och FrameSnapshot med 128 fasta platser. Inga spelpekare i publicerad data |
| `Source/Gameplay/GameplayState.h` | Två buffertar, generation/session, begin/add/fail/finish/invalidate, const lånade vyer. 24 832 byte plus CallbackState 96 byte på verifierad Windows x64; accepterad render-ägare, ingen asynkron payload-/tidsåldersgaranti |
| `Source/Gameplay/GameplayCollector.h` | Befintliga wrappers → kopierade värden; identity/back-reference/full handle, känd spelarlagstyp, finita positioner/tider, ammo och klassvaliderat vapen. Ingen extra enumeration; inga kamera-/ben-/trace-/precisionanrop |
| `Source/Features/Common/RenderingHookEntityLoop.h` | begin före samma nätverksloop, collect i redan klassificerad pawn-gren, finish efter loopen. Visuals behåller sin inbördes ordning |
| `Source/GlobalContext/FullGlobalContext.h`, `Source/HookContext/HookContext.h` | Äger/exponerar GameplayState; default av, setEnabled är intern aktivering, ingen ny init/hook |
| `Source/EntryPoints/EntryPoints.h` | Befintlig render-start efter originalet; unload ger terminal Shutdown |
| `Source/GameClient/EntitySystem/EntitySystem.h` | Ny isAvailable skiljer saknad lista från en faktiskt tom enumeration |
| `Source/GameClient/Entities/BaseEntity.h` | absOrigin kontrollerar nu även nullresultat från den befintliga funktionen före dereferering |
| `Tests/UnitTests/Gameplay/GameplaySnapshotTests.cpp` | Rena snapshot/livscykeltester, collector-doubles och verklig absOrigin-wrapper vid saknad funktion/nullresultat |

Source/Osiris.vcxproj listar nu fyra Gameplay-headerfiler; inga toolset-/byggflaggor ändrades. Tests/UnitTests/CMakeLists.txt registrerar testfilen. Fulla CFG-01–03-korrigeringar ligger kvar; parsern är fryst. Exakta bygg-/testbevis och nästa M1.2-R finns i PROGRESS/MODEL_HANDOFF.

## Byggning och start

| Källa | Symbol/ansvar | Beroenden och begränsningar |
|---|---|---|
| `Osiris.sln:6` | Lösningens enda produktprojekt | `Source/Osiris.vcxproj`, Debug/Release x64 |
| `Source/Osiris.vcxproj:564` | Kompileringsenheter och MASM | `dllmain.cpp`, CRTWindows.cpp, WindowsSyscall.asm |
| `Source/Osiris.vcxproj:583` | v143 | Release-inställningar börjar vid 630; C++20, inga defaultbibliotek, egen entry point |
| `CMakeLists.txt:14` | `ENABLE_TESTS` | `unit;functional`; produkt och tester byggs separat |
| `Source/CMakeLists.txt:15` | MSVC Release-flaggor | Egen CRT-stub, `/nodefaultlib`, `/ENTRY:DllMain` |
| `.github/workflows/windows.yml:6` | MSBuild-matris | Windows 2022/2025, MSVC/ClangCL, Debug/Release |
| `.github/workflows/windows.yml:24` | CMake och CTest | x64, varningar som fel, unity batch 4, både testmål |
| `.clang-tidy:4` | Kognitiv komplexitet | Enda aktiverade kontrollen, tröskel 21 |
| `Source/dllmain.cpp:23` | `DllMain` | Initierar `GlobalContext` vid process attach; ingen detach-städning |
| `Source/GlobalContext/GlobalContext.h:46` | `initializeInstance()` | Statisk pool, moduler via PEB, partiellt SDL-hook |
| `Source/GlobalContext/PartialGlobalContext.h:13` | Tidiga mönstersökare | Modulsektioner och SDL-pekarhook; full init senare |
| `Source/GlobalContext/GlobalContext.h:80` | `initCompleteContextFromGameThread()` | Skapar komplett kontext efter SDL-callback |
| `Source/GlobalContext/FullGlobalContext.h:43` | Ägare av globalt tillstånd | Config, patterns, hooks, features, Panorama och panelcache |

## Exekveringsflöde och avlastning

| Källa | Symbol/ansvar | Koppling |
|---|---|---|
| `Source/EntryPoints/EntryPoints.h:7` | `finishInit()` | Initierar klassificerare och Panorama, schemalägger configladdning, växlar till render-hook |
| `Source/EntryPoints/EntryPoints.h:18` | `SDLHook_PeepEvents()` | Uppskjuten init, sedan originalfunktionen |
| `Source/Hooks/ViewRenderHook.h:35` | `install()` | Byter VMT-metod på index 4; sparar original |
| `Source/EntryPoints/EntryPoints.h:66` | `ViewRenderHook_onRenderStart()` | Original först; ljud, no-scope, entitetsloop, HUD, GUI, config-I/O, eventuell städning |
| `Source/Features/Common/RenderingHookEntityLoop.h:22` | `run()` | En nätverksentitetsloop; distribuerar till befintliga visuals och BombPlantAlert |
| `Source/HookContext/HookContext.h:81` | `clearRenderHookState()` | Nollställer panelindex/cacheindex per hook, inte ett gameplay-snapshot |
| `Source/EntryPoints/EntryPoints.h:32` | `unload()` | Raderar paneler, återställer hooks och glow på levande entiteter |
| `Source/EntryPoints/EntryPoints.h:95` | `PlayerPawn_sceneObjectUpdater()` | Originalfunktion samt modellglow; separat callback från render-start |
| `Source/EntryPoints/EntryPoints.h:109` | `Weapon_sceneObjectUpdater()` | Motsvarande vapenfunktion |
| `Source/EntryPoints/EntryPoints.h:120` | `ClientModeHook_getViewmodelFov()` | Viewmodel-FOV, inte getter/setter för spelarens siktesvinklar |
| `Source/Features/Visuals/ModelGlow/ModelGlow.h:143` | Hooka/återställ scene-updater | Originalpekare lagras per featuretyp, ingen allmän callback-quiescence |

## Tillgängliga speldata

| Källa | Metoder/data | Viktig semantik |
|---|---|---|
| `Source/GameClient/EntitySystem/EntitySystem.h:23` | `getEntityIdentityFromHandle`, `getEntityFromHandle`, `getEntityFromHandle2` | Helt handtag jämförs vid uppslag, inklusive generationsbitar |
| `Source/GameClient/EntitySystem/EntitySystem.h:41` | `forEachNetworkableEntityIdentity()` | 32 chunkar × 512 platser; klassificera före nedkonvertering |
| `Source/GameClient/EntitySystem/EntitySystem.h:73` | `getRawEntityIdentityFromHandle()` | Indexvalidering, nullkontroll, fullständig handtagsjämförelse |
| `Source/CS2/Classes/EntitySystem/CEntityHandle.h:10` | `CEntityHandle::index()` | Index = nedre 15 bitarna; behåll hela uint32-värdet vid cachning |
| `Source/CS2/Classes/EntitySystem/CConcreteEntityList.h:8` | Layout | 64 chunkar totalt, 32 nätverkschunkar, 512 identiteter per chunk |
| `Source/GameClient/Entities/EntityClassifier.h:74` | `init`, `entityIs`, `classifyEntity` | Klasspekare kopplas till statiska entitetstyper |
| `Source/GameClient/EntitySystem/EntityIdentity.h:10` | Identitetswrapper | Klassificering och `entity()`; ingen långtidsägd entitet |
| `Source/GameClient/Entities/BaseEntity.h:35` | `absOrigin()` | Optional-position via mönstersökt funktion, inget ben/hitboxcentrum |
| `Source/GameClient/Entities/BaseEntity.h:88` | `handle()` | Läser identity-handtag; förutsätter giltig identity när entity finns |
| `Source/GameClient/Entities/BaseEntity.h:149` | `teamNumber`, `vData`, `health`, `isAlive` | Lag får default vid bortfall; liv/hälsa kan vara okända |
| `Source/GameClient/Entities/PlayerPawn.h:55` | `weaponServices`, `weapons` | Återanvänd befintlig vapenkedja |
| `Source/GameClient/Entities/PlayerPawn.h:70` | `isAlive`, `playerController`, `health`, `hasImmunity`, `absOrigin` | Liv via BaseEntity, controller via handtag |
| `Source/GameClient/Entities/PlayerPawn.h:98` | `isControlledByLocalPlayer`, `isEnemy`, `isTTorCT` | `teammatesAreEnemies()` vid 189 har permissiv fallback `true` |
| `Source/GameClient/Entities/PlayerPawn.h:114` | Hostage, defuse, scope, C4 och flash-status | `isScoped()` vid 124; flash-tid återgår till 0 när data saknas |
| `Source/GameClient/Entities/PlayerPawn.h:157` | `getActiveWeapon()` | Hämtar via WeaponServices |
| `Source/GameClient/Entities/PlayerController.h:41` | `pawn()` | BasePawn-handle → BaseEntity; typkontroll krävs för PlayerPawn |
| `Source/GameClient/Entities/WeaponServices.h:26` | `getActiveWeapon()` | Handtagsvaliderat entitetsuppslag, returnerar nullable wrapper |
| `Source/GameClient/Entities/BaseWeapon.h:41` | `isSniperRifle`, `bulletInaccuracy`, `getName`, `clipAmmo` | Inaccuracy + spread; ingen fullständig skottsannolikhet |
| `Source/GameClient/Entities/BaseWeapon.h:79` | `inaccuracy()` | Mönstersökt spelfunktion; saknas → tom Optional |
| `Source/GameClient/Entities/BaseWeapon.h:87` | `spread`, `spreadIndex`, `weaponMode`, `vData` | Primärt/sekundärt läge; ingen exponering av recoil, reload eller nästa skotttid |
| `Source/GameClient/Entities/WeaponVData.h:15` | `name`, `spread` | Namn och spridningsfält; ItemDefinitionIndex är inte inkopplad runtime-vapenidentifiering |
| `Source/HookContext/HookContext.h:127` | `localPlayerController`, `globalVars`, `gameRules` | Nullable patterns och globalpekare |
| `Source/HookContext/HookContext.h:255` | `activeLocalPlayerPawn`, `localPlayerBulletInaccuracy` | Återanvänd lokala kedjan |
| `Source/GameClient/GlobalVars.h:8` | `curtime`, `frametime` | Inget verifierat tick-ID/simulationsintervall |
| `Source/CS2/Classes/GlobalVars.h:8` | Raw `GlobalVars` | `curtime` använder PAD(48), explicit FIXME |
| `Source/GameClient/ConVars/CvarSystem.h:16` | `findConVar`, `getConVarValue` | Typkontrollerad bool/float/int-läsning via cache |
| `Source/GameClient/ConVars/ConVarTypes.h:6` | Registrerade cvars | Bara teammates, viewmodel-FOV och crosshair-RGB; sensitivity/yaw/pitch saknas |

## Projektion och befintliga funktioner

| Källa | Ansvar | Begränsning |
|---|---|---|
| `Source/GameClient/WorldToScreen/WorldToClipSpaceConverter.h:14` | `toClipSpace()` | Saknad matris ger fyra nollor; inte ett fullständigt pixel-/vinkel-API |
| `Source/GameClient/WorldToScreen/ClipSpaceCoordinates.h:8` | `onScreen`, `toNormalizedDeviceCoordinates` | `onScreen` kontrollerar bara w ≥ 0,001, inte viewportgränser eller siktlinje |
| `Source/GameClient/WorldToScreen/NormalizedDeviceCoordinates.h:11` | `getX`, `getY` | Panorama-procent, inte fysiska muskoordinater |
| `Source/GameClient/WorldToScreen/ViewToProjectionMatrix.h:15` | `getFovScale`, `transformY` | Projektion för visualisering; inget komplett kamerakontrakt |
| `Source/Features/Visuals/PlayerInfoInWorld/PlayerInfoInWorld.h:19` | `drawPlayerInformation()` | Världsposition → panel; `shouldDrawInfoOnPawn` vid 43 tolererar okända data |
| `Source/Features/Visuals/PlayerInfoInWorld/PlayerInfoPanelCache.h:11` | Panelcache | Återanvända UI-poster per hook, inte en cache av spelardata |
| `Source/Features/Visuals/OutlineGlow/OutlineGlow.h:31` | `applyGlow()` | Entitetsklass-/featurepolicy för konturer |
| `Source/Features/Visuals/ModelGlow/ModelGlow.h:29` | Modellglow | Delat tillstånd mellan main/render- och scene-updater-vägar |
| `Source/Features/Visuals/ViewmodelMod/ViewmodelMod.h:16` | Aktivering och FOV | Bevara separat från kamerans verkliga FOV |
| `Source/Features/Sound/SoundFeatures.h:29` | Sex visualiserare | Steg, bombplant/defuse/beep, scope och reload |
| `Source/Features/Combat/SniperRifles/NoScopeInaccuracyVis/NoScopeInaccuracyVis.h:19` | `update`, `onDisable`, `onUnload` | Visuell inaccuracy-ring för oskopade prickskyttegevär |

## Panorama och konfiguration

| Källa | Ansvar | Utökningspunkt |
|---|---|---|
| `Source/UI/Panorama/CreateGUI.js:1` | Inbäddad JavaScript som C++ u8-råsträngar | Nya literalblock börjar vid 384, 464 och 669; behåll MSVC-uppdelning |
| `Source/UI/Panorama/CreateGUI.js:34` | `addCommand()` | Strängattributet `cmd` läses och töms i C++ |
| `Source/UI/Panorama/CreateGUI.js:72` | Slider-kommandon | Nu `Math.floor`; bara heltal |
| `Source/UI/Panorama/CreateGUI.js:209` | Combat-navigation | Bara sniper-rifles-flik; faktisk kontroll vid 469 |
| `Source/UI/Panorama/CreateGUI.js:385` | `createSlider()` | Hårdkodad `visuals`-routing vid 405/416, increment 1 |
| `Source/UI/Panorama/CombatTab.h:16` | `init`, `updateFromConfig` | Endast NoScopeInaccuracyVis; dropdown-callback, inte set/combat-kommandot |
| `Source/EntryPoints/GuiEntryPoints.h:25` | `dropDownSelectionChanged` | Typad callback → handler → config |
| `Source/UI/Panorama/SetCommandHandler.h:20` | Sektionernas kommandorouting | Combat-hanteraren vid 34 är tom; viewmodel-FOV vid 46 fungerar |
| `Source/UI/Panorama/Tabs/VisualsTab/IntSlider.h:16` | `updateSlider`, `updateTextEntry` | uint8-gränssnitt; kräver utökning för större intervall |
| `Source/UI/Panorama/PanoramaGUI.h:106` | `init()` | Kör inkluderad CreateGUI.js och registrerar flikarnas callbacks |
| `Source/UI/Panorama/PanoramaGUI.h:180` | `run()` | Paneluppslag, cmd-dispatch, previews; ingen automatisk återinit vid förlorad panel |
| `Source/UI/Panorama/PanoramaGUI.h:210` | `updateFromConfig`, `onUnload` | Synkar kontroller och raderar paneler/JS-objekt |
| `Source/UI/Panorama/PanoramaCommandDispatcher.h:19` | Kommandoloop | `set`, `restore_defaults`, `unload` |
| `Source/Config/ConfigVariableTypes.h:16` | Register med 85 variabeltyper | Inga aimbot-/triggerbotinställningar |
| `Source/Config/ConfigVariables.h:22` | `getVariableValue`, `storeVariableValue` | bit_cast/memcpy; storleksfilter och bytearrayer vid 46 |
| `Source/Config/Config.h:31` | `init`, setters, defaults | `default.cfg`, statisk 4096-bytebuffert; autosave och change handlers |
| `Source/Config/Config.h:81` | `update`, `performFileOperation` | Tvåfasig schemaläggning, synkron I/O på render-vägen |
| `Source/Config/Config.h:177` | `finishLoadFromFile()` | Setter-anrop under parsing, assertions i stället för explicit fullständighetsfel |
| `Source/Config/Config.h:196` | `prepareSaveToFile`, `saveToFile` | En serialiseringspassage, `.new` + rename efter lika många skrivna byte |
| `Source/Config/ConfigSchema.h:16` | Fyra rotobjekt | Combat, Hud, Visuals, Sound; ingen SchemaVersion-nyckel |
| `Source/Config/ConfigSchema.h:215` | `loadVariable()` | Clamp för hue/uint8-intervall; enums castas utan medlemsvalidering |
| `Source/Config/ConfigFromString.h:51` | `boolean`, `uint` | Ingen generell JSON-parser; okända nycklar skippas inte |
| `Source/Config/ConfigFromString.h:169` | Numerisk läsning | Ofullständig kontroll av uint64-överslag |
| `Source/Config/ConfigToString.h:59` | `boolean`, `uint` | Begränsad writer med continuation-state; filvägen fullföljer inte continuation |
| `Source/Config/ConfigParams.h:8` | Index och nästlingsgränser | Maxnivå 7, objektindex uint16 |
| `Source/Utils/InRange.h:33` | Range-wrapper | Assertions vid runtime, inte allmän Release-validering |
| `Source/BuildConfig.h:9` | Pool och configgräns | 1 000 000 respektive 4096 byte; skilda lagringsområden |

## Minne, mönster och tester

| Källa | Ansvar | Kontroll |
|---|---|---|
| `Source/MemoryAllocation/MemoryAllocatorBaseImpl.h:9` | Allokering ur global pool | Ingen inbyggd synkronisering |
| `Source/MemoryAllocation/FreeMemoryRegionList.h:46` | Allokera/frigör | Kan ge nullptr; `getFreeSpace` vid 66 |
| `Source/MemoryAllocation/UniquePtr.h:18` | Placement-new i egen pool | Granska OOM innan utökad användning; inga vanliga heap-new-anrop |
| `Source/GameClient/MemAlloc.h:16` | Spelets allocator | Används bland annat av PanoramaTransformFactory |
| `Source/MemoryPatterns/AllMemoryPatternSearchResults.h:7` | Mönstersökning vid init | Windows-signaturer och starka typalias under MemoryPatterns |
| `Source/MemoryPatterns/MemoryPatterns.h:28` | Compile-time patternpool | Kapacitetsgränser måste följas vid nya patterns |
| `Source/Utils/FieldOffset.h:30` | Nullable fältåtkomst | Kontrollerar bara null/positiv offset, inte pekarens livslängd |
| `Source/MemorySearch/PatternNotFoundLogger.h:17` | Samlar misslyckade patterns | Meddelanderuta i `finish` vid 43, inget komplett capability-register |
| `Source/Platform/Windows/WindowsDynamicLibrary.h:14` | Moduler/exports via PEB/PE | Exportrutning behöver granskas inför nya Win32-anrop |
| `Source/Platform/Windows/PortableExecutable.h:48` | `getExport()` | Forwarded exports avvisas uttryckligen vid 62; nya Win32-beroenden kan inte antas fungera direkt |
| `Source/Platform/Windows/Syscalls/WindowsSyscallIndex.h:8` | Fasta syscallindex för fil-I/O | Ingen OS-build-detektering i denna tabell; Windows-versioner behöver separat verifiering |
| `Source/Platform/Windows/FileSystem/WindowsFileSystem.h:74` | Synkron läs/skriv/rename | Rename vid 94 har maxväg 200 tecken och returnerar ingen status |
| `Tests/CMakeLists.txt:6` | GoogleTest FetchContent | SHA `063de7e9578f82b369302001269680b4b1553359`, kommentar v1.18.0 |
| `Tests/UnitTests/CMakeLists.txt:1` | UnitTestsBin | Mockbaserade features/config, patterns, Windows-PEB, utilities |
| `Tests/FunctionalTests/Config/ConfigCompatibilityTests.cpp:233` | Byteexakt aktuell konfigurationsfil | Laddningsfall v1–v9 och current vid 283–328 |
| `docs/evidence/config-parser-probe.cpp:13` | Separat granskningsprogram | Reproducerar parserbegränsningar utan att ändra Source/Tests |

Råa ben-, hitbox-, rustnings-, velocity-, view-angle-, recoil-, trace-/visibility- och sensitivity-adaptrar hittades inte vid sökning i Source och Tests. Namn som `Common/Visibility.h` och `onScreen()` avser UI/projektion och ska inte tolkas som siktlinjekontroller.
