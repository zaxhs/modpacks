Delivered r10: releases/Sensate-CS2-Test-20261104-r10-x64.zip,51 payload files;10/10 extracted-package checks passed including normal-launcher singleton reuse and owned TestPayload initialization. Builds/tests1619 per configuration and injector144 per configuration; current CS2 runtime remains pending. Final ZIP identity is in build/r10/final-release.json. Start Sensate.cmd; keep all files together.

Final r10 owned loading: all8 direct/shared-wrapper cases pass with WMI access (build/r10/owned-unrestricted.log); initial restricted run could not access CIM/WMI and failed before starting mapper. No test gate relaxed. Final unified-process test also checks that normal launcher startup reuses the same window. This is owned TestPayload initialization only, not CS2/Osiris runtime.

# r10 — unified Sensate application (2026-11-04)

Supersedes the r9 next-action/UI descriptions below; older entries are history. Continues the verified r9 source/package, not an upstream replacement. One default ImGui/DX11 window now contains Home/loading, settings, profiles and Diagnostics. OsirisLauncher.exe forwards normal startup to that same singleton; --legacy retains the old launcher and --classic retains the old menu. Internal filenames/IPC IDs remain compatible. No new injector or gameplay-input path.

LoadController.h extracts the existing launcher verify/refresh/load/file locks/attempt ledger/report/helper logic, shared by both presentations. Explicit authorization, final PID/creation/path checks, verified package, reviewed PE validator, durable no-retry ledger and child outcome handling remain. Mapper exit0 is distinct from a fresh DLL reply and full feature readiness. Home shows process/loading/communication/config sync/availability; detailed tools/reports moved to Diagnostics. Closing waits for active loading/helper operations; hiding leaves their lifecycle intact. Configuration formats/settings backend and existing profiles are unchanged.

UI correctness: modern layout no longer creates then hides the classic HWND controls on every layout/tab change (a verified source path capable of transient content bleed). Modern WM_PAINT/erase handling avoids GDI overwriting the DX11 surface. Page-specific IDs separate scroll/widget state. Segoe UI system font is rasterized at100/125/150% DPI; system-font fallback retained, no font redistributed. Violet selection colors, consistent margins, animated toggles and a short page fade. Menu is no longer WS_EX_TOPMOST and does not re-promote itself on game focus. Insert hides a focused menu; when behind another window it brings forward the same window. Read-only observation/hiding, focus gates and staged edits are retained. Actual CS2/physical Insert/Alt-Tab/flicker sign-off remains pending; do not infer it from a still image.

Reference: supplied Downloads/Osiris-master.zip (not the (2) filename in the prompt), SHA25675B6825468CFEA60FF034587E0A41187FC0B6F4F6FAD11CA221985BF532D8897. Extracted only under build/r10/reference. No Git commit; ZIP entries2026-11-01, README news2025-11-04, so newer ancestry is not established. Relevant class/wrapper/Sound/Glow/pattern changes compared; custom CFG/lifecycle/schema protections preserved. No new upstream camera/hitbox/input adapter was found to replace missing contracts.

Installed client changed: SHA25657EE728E15C50881070D847D7516D632D70456E0648D486A53F2528EC53F6EE0; soundsystem2260047A6DB739B6805E4F6FB72D1B34AC5ADD22DF796FCE55F6C9BD0229F698. The r9 Float4 entry signature has0 hits because its embedded RIP displacement changed. A broad wildcard was rejected (6 hits); reference caller approach was verified with stricter opcodes: 0F117424?E8????????FFC64883C70C, .add(6).abs(), one hit atRVA0xB15DC0 -> target0x16AF20. Supplied signature independently targets the same entry from0xC9F8AC. Disassembly verifies RCX attributes/EDX hash/R8 float4 and vector-copy implementation. Null/ambiguity/lifecycle gates remain. This is the only production DLL source change. Actual Model Glow still requires CS2 retest.

Sound: same72-byte ChannelInfo1 in supplied source; our stricter72/132-byte channel/origin indexing signature still uniquely matches current soundsystem. Retain existing bounded/null/lifetime/toggle/shutdown corrections. Do not replace with the supplied weaker global-reference signature. No additional Sound root cause or CS2 cure is claimed. All six effects, including reported Visualize Footsteps crash, still need actual runtime sign-off.

Fresh installed-file schema fixtures resolve14/14 with the production resolver in an owned process. All38 selected class offsets/sizes unchanged since r9. Dumper37/38 offsets match; m_bIsScoped remains0x1EA0 vs generated0x1E98 and existing pattern is retained. Generated five globals plus derived view angles are stale; current unique pattern targets retained, not copied offsets. Existing field types/schema gates retained. These are file/metadata checks, NOT live initialized-object/camera/hitbox/visibility/readiness/input evidence. Exact fields/types/bytes/interfaces: build/r10/dumper-comparison.json, metadata-fixture.json, reference-comparison.json and disassembly logs. No Dumper/SchemaExplorer executable, game or Osiris injection run by agent.

Injector provenance: source tree matches the reviewed release SOURCE-MANIFEST. r9/r10 injector hash3F738BE1C4CC4E842337C8C7DA3E6794158105A3D1E90BD965DB8A640FA8DA23 matches the documented launcher-integration rebuild; original standalone release C1E44... is a different build, not silently substituted. Existing 144/144 owned regression checks pass again in Release and Debug. TLS rejected; no general detach/rollback/retry, no anti-cheat guarantee. See original injector docs and build/r10/injector-source-check.json.

Verification: VS2026 Windows x64 Release/Debug and1619/1619 CTest each pass; clang-tidy exit0 (filtered warnings logged). Expanded DX11 test renders12 frames across Home/Aim/Movement/Diagnostics and three DPI scales, asserts no classic children/permanent topmost, rejected package and hidden-trial lifecycle. New owned process test checks singleton reuse and clean shutdown. Pattern tests cover correct relative target, changed displacement, truncated/missing/ambiguous callsites. Historical config fixtures/atomicity and previous regression suite retained. Owned injector144/144 each passed; no CS2 execution. Observation Release DLL has no static imports and matching PDB. v143 unverified. Exact commands: build/r10/verify.ps1, tidy.cmd, metadata-probe.cmd; logs/results in that directory. Extracted-package results/release identity are in final-release.json and packaged TEST_RESULTS.json.

Gameplay status: data collection, existing calculations and four read-only trials preserved. Aimbot does not move aim, Triggerbot does not fire, Bunnyhop does not jump, Spinbot does not rotate. Native input remains disabled under AUD-01. No new claims from r8's user CSV; fresh matching r10 live evidence is needed. Camera world-eye, active pose/hit regions, visibility, readiness and targeted input consumption/release remain unresolved. Sound/Glow sign-off pending.

Next exact task: user tests the single r10 program in isolated windowed/borderless CS2; verifies Insert from behind/hidden, tab changes, DPI, Alt-Tab, reconnect and profile save/reload. Export a10s Aim CSV (expect resolved16383/rejected0, otherwise preserve unknowns) and manual Movement/Space correlation. Only then continue one bounded targeted jump-consumption/release experiment; no parser expansion or broad audit. Sol High remains appropriate; no Astra problem identified. Recovery copies and source scope: build/r10/before and changed-files.txt. Earlier releases are preserved.
# r9 — runtime types and opt-in ImGui prototype (2026-10-24)

PARTIAL delivery: no automatic jump, fire, aim movement or rotation is enabled. The first actual gameplay-input objective remains incomplete. Native WindowsInputSink remains disabled under AUD-01. No agent CS2 launch/injection occurred. CFG01-03 and Sound/Glow gates are preserved.

User evidence: osiris-live-trial2.csv has615 rows,612 selected rows,4 handles,6 switches,10.000027s, time_limit and native_input=0. All rows show resolved511/rejected15872, identifying all five type gates as the rejection path; pointer contents are not exposed. User confirms visible markers and steadier selection. SHA25673D2168E397757490BA74F4472C80A8074CA74B3A11F2ACDDBB806BB1B81BCF3.

GameplaySchema now preserves encoded static registration checks and additionally validates exact named BuiltIn/Atomic runtime SchemaType values using bounded injected reads. Expected names: CEntityIndex,QAngle,Vector,int32. Reference layout name+8/category+24 comes from local Dumper source; actual live applicability remains pending. Production uses dynamically resolved ReadProcessMemory on this process during initialization. Wrong names/categories, pointer/array wrappers and inaccessible memory fail closed. Existing class/name/offset/width checks remain. Two new schema cases plus owned accessible/PAGE_NOACCESS memory checks cover this path. No raw game pointers are retained/exported.

UI: Dear ImGui1.91.9b/Win32/DX11 prototype (--modern), violet cards, animated toggles, navigation, numeric/choice controls, hotkey capture and existing trials/exports. Same config/IPC/backend. Classic default and renderer-failure fallback retained. Topmost menu; existing global Insert/reconnect reused. Read-only trials survive menu focus/hiding; other applications still stop them. Input decision gates remain unchanged. Nine owned DX11 frames across three pages and100/125/150% scales, topmost and hide/trial lifecycle tested. GPU-buffer image visually inspected. Real CS2 composition/Alt-Tab/flicker remains pending; bitmap font is still a prototype limitation.

ImGui chosen for direct C++ integration, MIT license and small deployment surface. Qt Quick has a retained GPU scene graph and richer declarative animation, but adds Qt/QML modules/plugins and LGPL/commercial deployment obligations. No comparative performance benchmark performed. Vendor version/license/hashes in ThirdParty/imgui. Only menu EXE links DX11/ImGui; DLL no-CRT constraints unchanged.

Input blocker: SendInput has no target process/window parameter and retains a foreground race. SDL_PushEvent does not update device keyboard state; queue acceptance proves neither game consumption nor release. No verified targeted delivery/consumption/cancellation contract exists yet. Identification is not a ray/hitbox/visibility/readiness result; raw local camera data is not world eye. No speculative input enabled.

VS2026 Release/Debug x64 builds and1617/1617 CTest cases per configuration pass; clang-tidy exit0 (filtered diagnostics logged). Actual owned Windows/DX11 execution is not CS2 verification. v143 unverified. Commands/logs/backups/changed-files under build/r9; observation DLL and extracted-package results in final-release.json/TEST_RESULTS.json. Previous r8 ZIP preserved.

Next: matching r9 DLL/menu in isolated local windowed/borderless CS2;10s Aim trial with menu open/hide; export CSV and check resolved16383/rejected0 plus identification/v_angle/camera-local/command columns. Repeat manual Space/ground observation. Check Insert, Alt-Tab and reconnect. Then establish one bounded targeted jump-consumption/release experiment before repeated Bhop. Aim/Trigger/Spin and Sound/Glow remain pending. No parser expansion/broad audit. Sol High; no Astra escalation justified.
# r8 status (2026-10-24)

External Sensate presentation implemented with violet theme, rounded cards/buttons, toggles, icon navigation, advanced diagnostics, global configurable Insert, Alt-Tab persistence, background reconnect with staged-edit preservation. Desktop visual/runtime sign-off pending. Launcher consolidated load path preserves mapper/ledger checks and no longer opens the menu automatically at startup.

Aim ORIGIN tracking now has10% hysteresis; user r7 origin test confirmed (624rows/551selected/3targets/10switches). No hitbox or aim-output claim. Schema gates remain intact; v5 trial CSV adds resolved/type-rejection masks to investigate live9/14. All automatic modules remain off; no actual aim/fire/jump/spin output. Camera/hitboxes/visibility/input consumption remain blockers, not completed features.

Preserve full ambitions below. Panorama remains until color controls and complete status parity exist. Sound/Footsteps/Model Glow runtime retests remain pending. r8 UI is an incremental Win32 redesign, not full parity with every reference-image layout or feature.

# M1.6 current feature evidence (2026-10-24)

| Feature | Implemented / testable | Actual output | Remaining |
|---|---|---|---|
| Bunnyhop | Existing engine + current local data, bounded overlay/CSV trial; old recorded-data replay remains valid | None | User live landing/stop evidence, isolated acknowledged jump/release |
| Aimbot | Existing enemy origins projected and selected in a fixed screen region; raw camera-local/v_angle fields exported | No aim movement | World-eye/camera ownership, model pose/hit regions, visibility and output |
| Triggerbot | Observed game ID index matched to full eligible enemy handle; raw weapon timing retained | No shot | Verify ID semantics against bots/empty space/walls; ray hit, readiness/timing and output |
| Spinbot | Separate current eye-yaw/v_angle observation trial and CSV | No rotation | Verify camera ownership and permitted rotation output; existing SpinEngine stays calculation-only |

All four new tests are connected to current game-data paths but not yet user-verified in CS2. Every native output remains disabled. No feature is complete based on compilation or PE metadata. Existing advanced feature ambitions below are retained. Sound and Model Glow still need their separate actual-game stability sign-off.
# M1.5 feature status — 2026-10-24

| Feature | New implemented connection | Actual runtime / remaining boundary |
|---|---|---|
| Bunnyhop | Current local DLL samples → existing menu process → existing BunnyhopEngine, bounded Hold trial with identity/focus/freshness/order/lease checks | User r5 CSVs show movement and takeoff; new live consumer/landing still unverified. No jump input, authenticated action transport or game-consumed isolated sink |
| Aimbot | Prior collector data and QPC retained | Camera/quantized eye/model/regions/visibility and action transport/output still absent |
| Triggerbot | Prior item/raw weapon timing retained | Local readiness clock and target intersection/visibility/output remain absent |
| Spinbot | Prior observed eye-angle data retained | Camera ownership/calibration/rotation delivery absent; remains offline |

No native game action is complete. Default feature settings remain off, native WindowsInputSink remains disabled. CSV export, Dashboard, Sound72-byte fix, Glow pattern and launcher remain. M1.5 adds no new persisted setting or optional feature ambitions. Full ambitions below are retained. The first purported stationary CSV contains53 moving rows; record its actual content, not the label alone.
# M1.4 current status — 2026-10-24

Real user runtime now confirms five complete player records in a one-human/four-bot match,9/9 metadata fields and zero observed callback overlaps/foreign calls during the reported probe. This replaces the prior blanket absence of runtime collection evidence; scalar correctness and long-term stability remain unverified.

| Feature | Current actual data connection | Remaining live boundary |
|---|---|---|
| Bunnyhop | Existing ground/velocity wrappers; new local120-row trace with identity/QPC and CSV for jump/landing verification | Values not yet behaviorally verified; simulation command cadence, transport and jump delivery absent |
| Aimbot | Existing velocity/eye-angle/item snapshots; new capture time and local-value diagnostics | Authoritative camera/quantized eye position, model/regions/visibility, live transport and isolated output |
| Triggerbot | Existing item/raw attack fields now exportable per local sample | Local weapon clock/readiness, target intersection/visibility, transport/output |
| Spinbot | Eye-angle observations and timestamp diagnostics | Camera ownership and verified rotation/output interface |

No live action or native input is complete. Dashboard painting/wrapping and scaled row placement are corrected; matching settings v3 peers are required. r3 Sound/Model Glow and prior fixes remain, with actual post-fix runtime sign-off pending. Advanced feature ambitions below are retained; no new unused feature settings were added.
# M1.3-LIVE current feature status — 2026-10-23

This entry supersedes older statements that grounded/velocity/item fields have no adapter. No live action is complete or CS2-runtime verified.

| Feature | Implemented connection | Still required |
|---|---|---|
| Aimbot | Existing collector now receives finite velocity and observed eye angles through current metadata-backed wrappers | Authoritative camera/eye position, hitbox/bone and visibility contracts, timing, output ownership and actual runtime |
| Triggerbot | Nonzero stable item ID and raw next-primary-attack tick/ratio | Validated local clock/readiness, target intersection/visibility, safe output and runtime |
| Bunnyhop | Ground flag and velocity are read during an explicit bounded probe | Simulation/output cadence, actual jump-delivery interface and runtime |
| Spinbot | Observed eye angles enter snapshots | Camera ownership, verified rotation-output interface and runtime |

Settings menu v2 exposes observation and a 120-callback probe plus schema/sample counters. No gameplay frame transport or automatic input is added. Sound and Model Glow retain r3 fixes but still require actual post-fix runtime verification. Full advanced feature ambitions below remain postponed, not removed. Precise blockers and reference evidence are in MODEL_HANDOFF.md.
# r3 current feature status — 2026-10-23

This table supersedes older rows below; full ambitions are retained.

| Function | Current status | Runtime limit |
|---|---|---|
| Original visuals / Panorama | IMPLEMENTED; prior user runtime report positive | No agent post-r3 CS2 execution |
| Model Glow / attribute resolution | IMPLEMENTED; current-file signature/ABI identified, regression tests | New fingerprint resolves once; actual effect/lifetime pending |
| Footsteps | IMPLEMENTED; dump-backed 72-byte stride correction; AUTOMATED TESTS PASSED | User's old/r2 crash is real; post-fix CS2 test pending |
| Bomb Plant | IMPLEMENTED; corrected shared Sound reader | Post-fix CS2 effect pending |
| Bomb Beep | IMPLEMENTED; corrected reader, independent configuration | Post-fix CS2 effect pending |
| Bomb Defuse | IMPLEMENTED; corrected reader, independent configuration | Post-fix CS2 effect and Beep isolation pending |
| Weapon Scope | IMPLEMENTED; corrected shared Sound reader | Post-fix CS2 effect pending |
| Weapon Reload | IMPLEMENTED; corrected shared Sound reader | Post-fix CS2 effect pending |
| Snapshot and collector | IMPLEMENTED; AUTOMATED TESTS PASSED | Normal collection off; grounded and missing gameplay inputs remain unknown |
| Aimbot | AUTOMATED TESTS PASSED (existing calculations) | BLOCKED WITH EVIDENCE: live camera/model/visibility/readiness/time/transport/output absent |
| Triggerbot | AUTOMATED TESTS PASSED (existing calculations) | Same live blockers; no simulated result proves game firing |
| Bunnyhop | IMPLEMENTED; AUTOMATED TESTS PASSED; INTEGRATED with configuration/menu/helper simulation | Known ground/timing/native jump delivery unavailable; not live-working |
| Spinbot | IMPLEMENTED; AUTOMATED TESTS PASSED; INTEGRATED with configuration/menu/helper simulation | Camera/calibration/exclusive native owner unavailable; not live-working |
| Dedicated menu | INTEGRATED; eight pages, Sound split, Movement settings, emergency stop | Prior user manual-start success; physical Insert/focus/fullscreen in new CS2 build pending |
| Launcher | INTEGRATED; package/self/owned-loader tests passed | New menu startup/close test blocked by an existing user-started menu; game flags unnecessary for settings |
| Windows helper | AUTOMATED TESTS PASSED; aim/trigger/movement simulations | Native output remains disabled; no live service |
| Configuration persistence | AUTOMATED TESTS PASSED; historical fixtures, atomic loads and owned process bridge | Real-game save/teardown still needs runtime evidence |
| Native input / gameplay transport | BLOCKED WITH EVIDENCE | AUD-01 disabled sink; no authenticated gameplay transport |

Movement parameters: off by default; always/hold/toggle + independent binds; bunnyhop landing delay and minimum interval, known-ground cancellation and one proposal per landing; spin direction/speed/continuous or alternating period, max-step and camera-owner priority. No held key state or game attack/view writes. Full later ambitions below remain unchanged.

# Funktionsregister

## Current feature-by-feature status — 2026-10-23

This ledger supersedes older proposed/implemented labels below; the complete ambitions and acceptance criteria are retained. Status vocabulary: **Not started**, **Implemented**, **Automatically tested**, **Runtime tested**, **Working under verified conditions**, **Blocked**. Automated evidence is scoped to the named fixture/owned process, not CS2. Latest user evidence: DLL loading, original visuals/Panorama and the separate settings app work; exact per-feature/build/hash coverage is unspecified. A subsequent CS2 test **crashes on enabling Visualize Footsteps**; other Sound options remain unverified. No dump/stack supplied. Preserve the working visuals; do not turn the general report into per-feature or callback-lifecycle sign-off.

| Feature | Implementation / verification state | Exact remaining requirement or limit |
|---|---|---|
| CFG-01 uint64 overflow | Automatically tested | Preserved; invalid values do not publish |
| CFG-02 conversion status/token/EOF | Automatically tested | Preserved; no parser expansion |
| CFG-03 atomic load | Automatically tested | Shared by file loading and the new configuration window; native CS2 save/load still needs a controlled test |
| Config persistence/short write/replace failure | Automatically tested with injected backend | Actual DLL filesystem failures and power-loss behavior unverified |
| Shared snapshot identity/lifecycle/freshness/invalidation | Automatically tested, Blocked for normal collection | Actual callback ownership, authoritative session boundaries, producer clock and teardown evidence |
| Existing-data collector | Implemented, Automatically tested; Disabled | Only existing identity/life/team/health/origin/scoped/immunity/basic weapon facts; no invented missing values |
| Callback/original/reentrancy diagnostics | Implemented, Automatically tested; Runtime tested only as incomplete user attempt | User saw no counters; actual thread/original-call order, reentrancy, transitions, shutdown and performance remain unverified |
| Camera/eye ray/view direction | Blocked | No validated current-client source or runtime sample |
| Model/bone/hit regions/visibility/smoke | Blocked | No validated model transforms/geometry or trace source; synthetic spheres do not establish CS2 hitboxes |
| Stable weapon item/readiness/inaccuracy/canScope | Blocked | Current collector does not establish these facts for input decisions |
| Velocity/recoil/simulation/monotonic sample time | Blocked | Current-source adapters and measured common clock domain required |
| Aim activation (always/hold/toggle, separate bind) | Automatically tested with synthetic frames | Real focus/capture/menu/chat gates and live input owner missing |
| Aim team/life/immunity/visibility/range filters | Automatically tested with synthetic frames | Known live data required; unknown rejects |
| Aim angle/distance/health/threat selection | Automatically tested with synthetic frames | Actual supported target data, including explicit threat, required |
| Aim FOV | Automatically tested; persisted real-unit menu edit tested | Correct live eye/camera ray required |
| Aim fixed region mask/fallback | Automatically tested | Actual model regions required |
| Arbitrary hitbox priority order | Not started | Current engine retains fixed head/neck/chest/stomach/pelvis order. Ordering codec/UI and tests still needed after supported live regions are established; not presented as implemented |
| Target retention/hysteresis/switch cancellation | Automatically tested | Live full-handle/session transitions and decision timing required |
| Linear/exponential/eased and axis smoothing/max step | Automatically tested | Measured live angular-to-count calibration required |
| Aim reaction delay/bounded variation | Automatically tested | Actual producer clock, latency and private runtime behavior unverified |
| Velocity extrapolation | Automatically tested calculation, Blocked live | Verified velocity/time and discontinuity handling from actual client needed; no ballistic claim |
| Recoil correction | Automatically tested calculation, Blocked live | Actual recoil samples/units/source and live non-double-compensation required |
| Trigger independent activation/deactivation | Automatically tested including AUD-02 | Same live gate/output requirements as aim |
| Trigger ray/regions/nearest blocker/team/immunity filters | Automatically tested with synthetic regions | Actual ray/geometry/visibility required |
| Trigger reaction delay/distribution/cancel | Automatically tested | Actual gameplay clock and acquisition transitions required |
| Trigger accuracy wait/inaccuracy threshold | Automatically tested | Verified weapon inaccuracy/readiness required |
| Geometric cone coverage estimate | Automatically tested | Explicitly not actual CS2 hit probability |
| Genuine spread/hitchance model | Not started, Blocked | Verified current spread distribution, weapon state and hit geometry |
| Burst/shot delay/cooldown | Automatically tested including AUD-03 | Real weapon fire readiness and acknowledgment policy required |
| Scoped-only / one scope request | Automatically tested proposal logic | Observed scope/canScope and calibrated new lease after zoom required; no live scope output |
| Four stable-item weapon slots and 16 overrides each | Automatically tested, persisted | Stable live item source missing; richer weapon/group inheritance remains Not started |
| Named full-configuration profiles/load/save/duplicate/reset | Implemented in OsirisMenu; shared-schema round trip Automatically tested | Native dialog/write-error behavior and actual DLL persistence need manual runtime coverage; opening/loading only stages values |
| Safe presets/defaults | Automatically tested | Presets retain Input/Aim/Trigger off |
| Calibration math/manual x/y/sensitivity/inversion | Automatically tested | Actual Windows/CS2 measurement, capture and zoom revision required |
| Automatic per-zoom calibration | Not started, Blocked | Validated view/zoom/cvar sources and isolated live output |
| Input lease/watchdog/replay/rate/partial failure/state machine | Automatically tested including AUD-04 | Real focus/capture/clock/transport integration absent |
| Native Windows mouse delivery | Blocked intentionally after AUD-01 | `WindowsInputSink` always rejects; no proven window-isolating game-output mechanism exists |
| Authenticated gameplay transport | Not started, Blocked | Proven callback/I/O lifetime and input isolation; configuration mapping is not this transport |
| Dedicated Insert menu | Implemented; owned Win32 opening/closing, controls and scaling calculations Automatically tested | Actual Insert from CS2, fullscreen, focus/raw-input behavior, real DPI transitions and release/cursor restoration unverified |
| Menu dark sidebar/toggles/sliders/selectors/regions/advanced | Implemented; owned window and screenshots inspected | 1080p layout calculations at 150/200% tested synthetically; real multi-monitor/DPI/accessibility pass pending |
| Menu key/mouse recording and changed hotkey | Implemented; key recording/repeat rejection Automatically tested | Actual physical key/mouse capture, reserved-key conflicts and scoped registration during CS2/Alt-Tab need manual test |
| Menu settings connection | Automatically tested with two separate owned processes and real mapping/resolver; production Config apply tested | Actual DLL-to-menu round trip, reconnect/unload and frame cost in CS2 unverified; one instance/session; default token ACL, not adversarial same-user authentication |
| Menu configuration emergency stop | Implemented and Automatically tested | Queued global Input/Aim/Trigger disable; not a process kill or guarantee against a stalled DLL. Native output is already disabled |
| E01 Model Glow | Implemented; earlier user crash, latest general visuals report positive; null/lifecycle regressions Automatically tested | Exact effect/path not identified in latest report. Attribute signature still absent in inspected client.dll; guards preserved, actual current function/lifetime verification pending |
| E02 Outline Glow | Implemented, existing mock tests | User's partial visuals report does not identify this feature separately; actual toggle/unload/session test pending |
| E03 Player Info / ESP | Implemented, limited existing automated coverage | Actual rendering/entity/panel lifetime and each icon/ammo/health toggle pending |
| E04 Weapon/bomb icons/ammo/glow | Implemented as existing shared components | Actual weapon transitions and each visual path pending |
| E05 Viewmodel FOV | Implemented, existing automated tests | Actual scoped/unscoped transitions, preview and restoration pending |
| E06 Footsteps | Implemented; user CS2 runtime **FAILED**; shared regression tests Automatically tested | Paired-array defect reproduced with original code as SEH0xC0000005 and guarded. No proof this is the user's exact crash. Default false, meaningful diagnostics; current Sfx/channel ABI and concurrent lifetime + real toggle/expiry/session/shutdown retest required |
| E06 Bomb plant / beep / defuse | Implemented; shared safety/expiry tests and independent Defuse setting Automatically tested | Defuse/Beep cross-wiring fixed. Each actual effect, combinations, map transitions and panel ownership still Runtime unverified; keep defaults false |
| E06 Weapon scope / reload sounds | Implemented; common collection/render safety Automatically tested | No individual CS2 runtime evidence. Same channel/filename/Panorama prerequisites; never assume safe because unreported. Defaults false |
| E07 Bomb timer/defuse alert | Implemented, existing automated tests | Actual round/bomb transitions pending |
| E08 Post-round timer/killfeed | Implemented, existing automated tests | Actual round/unload behavior pending |
| E09 Plant alert | Implemented, existing automated tests | Actual planting/round boundary behavior pending |
| E10 No-scope inaccuracy visual | Implemented, existing automated tests | Actual current inaccuracy/projection/source and cleanup pending |
| E11 Panorama settings | Runtime tested by user: visible; new grouped UI Automatically tested by Node mock | Redesigned layout and config refresh not yet executed in CS2; controls retained until replacement verified |
| X01 Bunnyhop | Not started, Blocked | Verified ground/movement/jump state and safe live keyboard output; no unused toggle exposed |
| X02 Spinbot | Not started, Blocked | Valid camera, calibrated bounded relative output, exclusive input ownership and emergency/runtime proof; no view-angle writes |
| X03 Other movement | Not started, Blocked | No further named movement feature defined beyond these ambitions; each needs concrete state/output/acceptance criteria |
| X04 Runtime diagnostics | Implemented partially, Automatically tested | Actual measured callback/thread/teardown, peak pool and frame cost remain pending |
| Unified Windows launcher | Implemented, Automatically tested; owned native mode/initialization/shutdown verified Release/Debug | Reuses unchanged reviewed injector and validator. Explicit one-attempt loading only for observed -insecure; mode observations cannot attest actual VAC/server state. Actual Osiris/CS2 initialization via launcher unverified |
| Reviewed copied injector | 17/17 released source fingerprints match; 144/144 native Release and Debug Automatically tested | Its owned-payload initialization is not Osiris/CS2 compatibility; no general unload/retry, no anti-cheat safety claim |
| Release pattern uniqueness | Automatically tested including original/current Release reproduction | Ambiguous patterns rejected, unrelated unique results preserved. No replacement for missing scene function identified |
| Shared Sound/player panel allocation | Automatically tested,43 Sound/shared regressions | Pool/cache/UI failure rolls back without invalid index publication. No actual engine allocation-pressure/lifetime sign-off |
| Owned helper receiver | Debug native test passed with zero native/tagged input; Release BLOCKED | Windows denied own foreground prerequisite twice; exit2 retained. Native sink remains disabled, not a window-confinement claim |

Current schema: 45 global values (including MenuKey) plus 68 embedded profile values; 113 Panorama controls. `config_current.cfg` is 3316 bytes; the 4096-byte buffer is unchanged. Existing visual/color controls remain in Panorama and every existing config variable is preserved through native-menu round trips. The test package is not a complete working gameplay release. See PROGRESS for final build/test evidence, FIRST_RUNTIME_TEST for exact manual steps, and ARCHITECTURE for researched references and anti-cheat risk distinctions. No feature is claimed undetectable and no anti-cheat bypass is implemented.

Additional owned Windows verification: the normal-loop menu window is **Working under verified conditions only for the owned test window**: visible rendering, posted-hotkey close, previous-window focus/clip restoration, reopen and exit passed. Insert/F9/F10 OS registration passed in an approved ordinary process; the restricted tool process denied registration with error 5. This does not upgrade physical Insert, key-repeat delivery, CS2 raw-input suppression or gameplay status. Current worst valid serialization with four distinct five-digit item IDs is **3457/4096 bytes**.

## Current offline implementation — 2026-10-22

The complete ambitions below are retained. The following are implemented offline, not approved for live CS2 use: bounded optional extended snapshots; calibrated input/lease safety with native output disabled; angle/distance/health/explicit-threat aim selection, sticky/hysteresis, fixed five-region priority/fallback, FOV/range, axis smoothing/easing/variation/reaction, optional extrapolation/recoil; separate trigger timing distributions, region/ray/blocker filters, geometric coverage estimate, accuracy waiting, burst/cooldown/scoping proposals and independent activation; 44 global settings, four 16-field weapon overrides, safe presets/defaults and 112 persisted Panorama controls; helper simulation/profile files and automated regressions. A separate observation DLL and Panorama callback-status label now exist, without collection or live helper connection. See PLAN/PROGRESS for exact evidence.

Still unavailable: actual game camera/model/bone/visibility/readiness/inaccuracy/recoil/item/clock/capture adapters; authoritative session/teardown evidence; live transport and live Windows game output. Existing collection remains Disabled. Uniform-cone coverage is not actual CS2 hitchance; spherical test regions are not claimed CS2 geometry.

Advanced ambitions retained: arbitrary hitbox priority editing, richer per-weapon/group override inheritance, named user presets, interactive key capture, automatic per-zoom calibration, validated ballistic/prediction/true spread models and richer data diagnostics. Bunnyhop/spin/movement experiments remain unimplemented and off pending valid movement data and a verified live output owner. Their absence does not block the implemented offline core. No anti-cheat evasion or speculative memory modifications are introduced.

Status 2026-10-22. **Befintlig/implementerad** betyder kod i den lokala baslinjen. **Testad** avser endast de faktiskt passerade mock-/konfigurationstesterna med VS 2026 Release. Alla livefunktioner är oprövade i aktuell CS2-runtime. **Planerad** betyder ingen produktionsimplementation och inga nya UI-kontroller. Nya kataloger är förslag enligt [ARCHITECTURE.md](ARCHITECTURE.md).

## Leveransordning efter CFG-03

CFG-01–03 är implementerade; parserutökning pausas om inget faktiskt blockerande fel upptäcks. [PLAN.md](PLAN.md) anger fem milstolpar: (1) validerad speldata/kamera/hitbox, (2) Windows-input/kalibrering/säkerhet, (3) första aim/trigger, (4) Panorama/persistens/end-to-end och (5) avancerat/experiment. Ingen ny gameplayfunktion är implementerad genom planändringen.

Första versionen får grundläggande hold-bindningar, vinkel-FOV, verifierat hitboxval, en smoothingmetod, reaktionstid, separat trigger med delay/cancel/cooldown/scoped-only och ett klickpar. Säkerhetskrav gäller fullt ut. Alternativa score-/smoothinglägen, rikare hitboxprioritet/låsning, axelreglage, recoil, träffchans, prediktion, burst, fulla vapenprofiler/presets/inheritance, toggle och automatisk kalibrering behålls nedan men skjuts till milstolpe 5. Minsta nödvändiga numerik och persistens införs först för faktiskt implementerade inställningar. P01–P02 i sin fulla framtida omfattning är inte längre en spärr före all speldatautveckling.

Hela registret nedan bevaras. Föreslagna namn/defaults är fortfarande design; avancerade reglage visas först med implementerad funktion. Kompilering och mocktester räknas inte som Windows/CS2-runtimebevis.

## Befintliga funktioner att bevara

| ID/funktion | Status och testning | Beroenden/data | Befintliga inställningar | Relevanta filer | Acceptans vid fortsatt utveckling |
|---|---|---|---|---|---|
| E01 Model Glow | Befintlig, implementerad; mocktester passerade | Klassificering, lag, health, scene-updater/renderobjekt | Master, spelar-/objekttyper, bara fiender, färgläge, hues | `Source/Features/Visuals/ModelGlow/ModelGlow.h` och undermappar; `Tests/UnitTests/Features/Visuals/ModelGlow/` | Samma filtrering/färger; original-updaters återställs; av/på och unload utan läckta effekter |
| E02 Outline Glow | Befintlig, implementerad; mocktester passerade | Entitetsklass, glow/scene-objekt, lag/health | Master, players/weapons/bomb/kit/granater/hostage, enemyfilter och hues | `Source/Features/Visuals/OutlineGlow/OutlineGlow.h`; motsvarande testmapp | Samma objekt och färger; inaktivering/unload återställer konturer |
| E03 Player Info in World | Befintlig, implementerad; begränsad täckning, bombikonstest passerade | Pawn, origin/projektion, health, aktivt vapen/ammo, statusflaggor, paneler | Master, only-enemies, position arrow, health och färger, vapen/ammo, C4/plant/defuse/hostage/flash-ikoner | `Source/Features/Visuals/PlayerInfoInWorld/`; `Tests/UnitTests/Features/Visuals/PlayerInfoInWorld/PlayerWeaponIcon/` | Panelposition och data uppdateras som förut; panelåterbruk/hidden/unload utan dubbletter; full UI-runtime krävs |
| E04 Vapenvisualisering | Befintlig, implementerad; glowtester samt begränsade ikontester | BaseWeapon, vData, klassificering och paneler | Glow per objekttyp, ikon/ammo inom E01–E03 | E01–E03; `Source/GameClient/Entities/BaseWeapon.h` | Bevara vapen-/bombikoner och ammo; detta är återanvända delar, ingen separat komplett vapen-ESP-modul |
| E05 Viewmodel-FOV | Befintlig, implementerad; ViewmodelModTests passerade | ClientMode-hook, lokal pawn/scoped, preview | Enabled, ModifyFov och Fov inom befintligt intervall | `Source/Features/Visuals/ViewmodelMod/`; `Source/Hooks/ClientModeHooks.h`; `Tests/UnitTests/Features/Visuals/ViewmodelMod/` | Samma FOV när aktivt/oskopat, original återställs, preview fungerar; inte ersätta verklig kamera-FOV |
| E06 Ljudvisualisering | Befintlig, implementerad; inga dedikerade ljudfeaturetester hittade | SoundWatcher, speltid, position, Panorama | Sex separata bool: steg, plant, beep, defuse, scope, reload | `Source/Features/Sound/SoundFeatures.h`, `Details/`, visualiserare | Samma ljudtyper/expiry/position; saknade ljuddata får inte lämna gamla paneler |
| E07 BombTimer och DefusingAlert | Befintliga, implementerade; mocktester passerade | PlantedC4, GameRules, curtime, HUD-paneler | Separat enabled per funktion | `Source/Features/Hud/BombTimer/`, `DefusingAlert/`; motsvarande tester; `Tests/UnitTests/GameClient/Hud/BombStatus/` | Samma timers, färger och hide/reset över rundor; inga UI-rester efter unload |
| E08 PostRoundTimer och KillfeedPreserver | Befintliga, implementerade; mocktester passerade | GameRules/tid, HUD/DeathNotices | Separat enabled | `Source/Features/Hud/PostRoundTimer/`, `KillfeedPreserver/`; motsvarande tester | Rundövergångar och killfeedregler oförändrade; defaults/config bevarade |
| E09 BombPlantAlert | Befintlig, implementerad; mocktester passerade | Entitetsloop, C4/pawn, rundtid, Panorama | BombPlantAlertEnabled | `Source/Features/Hud/BombPlantAlert/`; motsvarande tester | Visning/färg utifrån planttid och kvarvarande rundtid, döljs utan relevant plant |
| E10 No Scope Inaccuracy Visualization | Befintlig, implementerad; mocktester passerade | Lokal sniper, scoped, bulletInaccuracy, projektion, crosshairfärg | Enabled, övrig stil i Params | `Source/Features/Combat/SniperRifles/NoScopeInaccuracyVis/`; `Tests/UnitTests/Features/Combat/SniperRifles/NoScopeInaccuracyVisTests.cpp` | Ring bara i avsett läge, samma höjd/färg och städning; bevara Combat-kontrollen |
| E11 Panorama och config/defaults | Befintliga, implementerade; configtester passerade, GUI-runtime oprövad | HookContext, typregister, handlers, panelhandles, filsystem | default.cfg, autosave, restore_defaults, befintliga reglage | `Source/UI/Panorama/`, `Source/Config/`, `Tests/FunctionalTests/Config/` | Alla historiska giltiga fixturer laddas; fel får inte skapa nya regressioner; befintliga kontroller fortsätter fungera |

## Grundmoduler: implementerat och planerat

| ID | Status | Beroenden och inställningar | Data/filer | Acceptanskriterier |
|---|---|---|---|---|
| P01 Säker config-I/O/parser | CFG-01–03 klara: överslag, status/token/EOF och transaktionell laddning; fil-I/O-begränsningar kvarstår | Nödvändiga persistensskydd i milstolpe 4, parserfryst om inget blockerar | Befintliga Config*.h; riktade configtester | Överslag och ogiltig/ofullständig laddning publicerar inget; legacy passerar. Full buffert och write/rename-fel återstår att säkra/verifiera |
| P02 Numerik och vapenprofiler | Planerad, inte testad | P01; skalning, ranges, overrideflaggor, presets/defaults | `ConfigVariables.h`, `ConfigSchema.h`, föreslagen `Source/Config/WeaponProfiles/` | 4-bytetyper vid behov; samma validering i UI/fil; dokumenterad prioritet; worst-case fil inom tak, overflow avvisas |
| P03 Shared gameplay snapshot | M1.1/M1.2 implementerade och automatiskt testade; runtime ej verifierad, default av | Befintlig render-loop, atomisk ägarport och callbackdiagnostik; M1.2-R verifierar faktiska livscykelsignaler/tidsålder | Source/Gameplay: två 128-spelarbufferter, 24 832 byte state + 96 byte CallbackState | Full handle/session, optional data, provenance, felorsak och tom vy vid fel/overflow. Inga asynkrona läsare; ingen verifierad monoton ålder eller komplett sessionsdetektion |
| P04 Kamera, hitbox, visibility | Planerad förstudie, inte implementerad/testad | P03 och verifierad callbackkontext; inga synliga funktionsreglage ännu | Framtida GameClient-/patternadaptrar; befintliga projektionstyper | Validerad kamera/eye-ray, modellberoende hitboxtransformer, siktlinje inkl. tydlig smoke-policy; unknown stoppar input; privat runtimemätning dokumenterad |
| P05 InputBroker och protokoll | Planerad, inte implementerad/testad | Separat EXE, bounded overlapped-pipe, versions-/sessionshandshake; master off | Föreslagna `Tools/InputBroker/`, `Shared/InputProtocol/`, `Source/Input/Windows/` | Mottagarprogram visar korrekta rörelser/klick; fokus/lease/partial SendInput-fel avväpnar; inga gamla händelser efter reconnect; inget blocking i DLL |
| P06 Sensitivity/kalibrering | Planerad, inte implementerad/testad | P04/P05; auto/manuell, x/y-faktor, zoomprofil och revisionsstatus | Cvar-adaptrar samt föreslagen `Source/Input/Calibration/` | Riktning/storlek stämmer vid upprepade tester; oförenlig kalibrering stänger output; inga automatiska OS-inställningsändringar |
| P07 InputCoordinator/aktivering | Planerad, inte implementerad/testad | P03/P05/P06; separata bindningar/hold/toggle och säkerhetsspärrar | Föreslagen `Source/Input/`; nya statefält i FullGlobalContext | En outputägare, färsk status, korrekt configrevision, fokus/chat/menu/liv-gates, kvittenshantering och unload före destruktion |
| P08 Utökat Panorama | Planerad, inte implementerad/testad | P01/P02 och respektive färdig feature; beskrivningar/avancerade grupper | Befintlig CombatTab/CreateGUI/SetCommandHandler och nya små handlers | UI→validerad config→funktion→save/load→UI fungerar; skala/enheter syns; inga dekorativa reglage; MSVC-literalgränser bevaras |

## Planerad aimbot

**ID A01. Status:** ny, planerad, inte implementerad, inte testad. Beroenden P01–P07. Platsförslag `Source/Features/Combat/Aimbot/` med Settings, State, TargetSelector och AimController. Data: kända lokala/målets liv-/lag-/immunityfält, kamera/ray, riktiga hitboxpunkter, verifierad visibility och vapenprofil. Armor krävs bara om senare skadelogik införs, inte för de grundläggande urvalslägena.

Alla värden nedan är designförslag, inte befintliga inställningar. Numeriska defaults måste valideras mot kalibrering och privata tester före release.

| Inställning/grupp | Förslag och funktion | Datakrav/acceptans |
|---|---|---|
| Enabled/aktivering | Default off, obunden tangent; hold/toggle, separat från trigger | Ny aktivering efter focus loss/reconnect; ingen output vid okända chat/menu-gates |
| TargetSelection | AngularClosest default; Distance och LowestHealth | Filtrering före score, deterministisk tie-break, samma resultat vid samma snapshot |
| FovHalfAngle | Default 3°, föreslaget intervall 0,1–45°, upplösning 0,01° | Vinkel mot riktiga siktet, test av gränsfall och olika viewport/aspect |
| HitboxPriority | Ordning bland verifierade t.ex. head/chest/pelvis, inga numeriska ID:n antas | Validera per modell; inga punkter från origin + påhittad offset |
| TargetLock/Switch | Låsning på, byte först vid 20 % bättre score som utgångspunkt; separata minsta låstid/bytardelay | Ogiltigt mål ger noll output direkt; återanvänt index får aldrig ärva lås |
| SmoothingMode | Begränsad konstant hastighet eller exponentiell tidskonstant | Tidsstegsnormalisering; 30/60/144 FPS-replay med motsvarande tidsförlopp |
| SmoothTime/MaxSpeed | Förslag 120 ms tidskonstant, 90°/s hastighetstak; separata maxsteg | Testa extremt dt, pause och 0; klipp före rörelsekonvertering |
| HorizontalGain/VerticalGain | Default 100 % per axel, 0 stänger axeln; föreslaget 0–200 % | Ingen axelkorsning, teckenfel eller ackumulering vid förkastad output |
| ReactionMin/Max | Förslag 120–180 ms, validera min ≤ max; separat bytesreaktion | Deadline samplas en gång per kandidat, avbryts vid tappad giltighet |
| RecoilEnabled/X/Y/StartShot | Default av; axelstyrka och startskott endast med verifierade data | Egen komponent, inga antagna punchfaktorer eller dubbelkompensation |
| WeaponOverride | Global → feature → grupp → vapen; explicit inherit/reset | Samma byte/testfall väljer rätt profil, unknown weapon aktiverar inget automatiskt |
| PredictionEnabled/Horizon | Default av; begränsad linjär förutsägelse först efter velocity-/tidsverifiering | Ingen hitscan-projektilmodell; stora hopp/teleport/okänd velocity stoppar prediktion |
| SensitivitySource/X/Y/Zoom | Automatisk verifierad källa eller manuell effektiv kalibrering | Giltig calibration revision krävs; cvarbortfall ger inte tyst standardkänslighet |
| Enemy/Visibility/ImmunityPolicy | Grundpolicy kräver känt motståndarlag, levande, fri sikt, ingen immunity | Okända värden producerar inget mål; permissiva visualsfallbacks återanvänds inte |

**Godkänd grundversion:** reproducerbara offlineval och smoothing; rörelse genom FakeInputSink; därefter riktig broker mot mottagarfönster. Liveversion kräver privata mätningar av verklig ray/hitbox/visibility, korrekt kalibrering, dokumenterad latens och fungerande avväpning. Advanced recoil/prediction får levereras senare med separata kriterier; deras reglage visas först då.

## Planerad triggerbot

**ID T01. Status:** ny, planerad, inte implementerad, inte testad. Beroenden P01–P05 och P07; delar snapshot, profilupplösning, geometrityper och inputtransport med A01 utan att bero på dess mållås. Platsförslag `Source/Features/Combat/Triggerbot/` med egna Settings/State/RayEvaluator/TriggerController. Data inkluderar aktuell ray, hitboxer, visibility, känd lag, lokal ammo/scoped och verifierad fire-ready/reload.

| Inställning/grupp | Förslag och funktion | Acceptans |
|---|---|---|
| Enabled/Key/ActivationMode | Default off/obunden, egen hold/toggle | Aim får vara av medan trigger är aktiv och tvärtom; inga delade toggle-state |
| HitboxMask | Endast validerade stödjande hitboxgrupper | Rayintersection, inte närhet i pixlar; tom mask avvisas eller ger tydligt avläge |
| DelayMin/Max | Förslag 120–180 ms; ny sample per ny kandidat | Byte av mål/vapen/fokus avbryter; test med injicerad klocka och RNG |
| MaxInaccuracy | Av/validerad tröskel i verifierad enhet | Okänd precision stoppar när villkoret är aktivt; ingen tyst nolla |
| HitProbabilityEnabled/Threshold/Samples | Senare separat funktion; default av, tröskelförslag 70 % när implementerad | Kräver verifierad fördelning och geometri, deterministiskt estimat med dokumenterad tolerans; ingen omdöpning av inaccuracy till procent |
| WeaponGroup/SpecificOverride | Egna triggerprofiler; kategorier från validerad vapennyckel | Semiauto/auto/burst testas var för sig, okänd typ stoppar osäker skottlogik |
| ScopedOnly | Valbar, default false i global avstängd profil, sniperpreset kan kräva true | När true är okänt/false scoped ett absolut stopp |
| BurstCount/ShotInterval/Cooldown | Grundversion 1 klickpar; intervall i ms och burstbegränsning efter vapendatastöd | Räknar ack, respekterar både intervall och fire-ready; ingen catch-up-burst efter stutter |
| Visibility/Team/Immunity | Kända positiva villkor, enemy-only som default | Förlust av giltighet precis innan klick avbryter |
| WhileAimMoves | Första policy: avstå klick under rörelseframe | Nästa observerade ray måste bekräfta träff; antag inte att SendInput redan behandlats av CS2 |

**Godkänd grundversion:** ray-/hitboxgränser, delay/cancel och intervall testade med syntetiska data; exakt ett inputpar per action-ID i mottagarprovet; ingen knapp fastnar efter delvis API-fel/focus loss/normal unload. Windows-kvittens ska inte presenteras som bekräftat spelarskott. Träffchans och längre burst är senare delmoduler med egen verifiering.

## Gemensamma inställningar och kvalitetskrav

Global master, profilval, configstatus, diagnostic-status och reset till defaults. Featureinställningar har tydlig enhet/range/default och separat overridepresence. En ändring ska kunna sparas, laddas och återvisas i samma värde/skala. Presetbyte avväpnar och appliceras transaktionellt. Advanced-grupper förklarar exempelvis tidskonstant, halvvinkel, probabilistiskt estimat och kalibrering; oimplementerade alternativ exponeras inte.

Programmering av tangenter kräver en explicit bindningstyp, stödjande tangentlista/modifierarpolicy och test av fokus/capture. Lagra inte Windows-inputtillstånd i den gamla kommandosträngen som löpande högfrekvent kanal. Tangentinlärning i menyn får inte samtidigt aktivera spelfeaturen.

Nya moduler ska testas utan CS2 med syntetiska snapshots, FakeClock, reproducerbar RNG och FakeInputSink. Integrationstester använder lokal broker och mottagarfönster. Hela den aktuella unit/functional-sviten körs som regression efter gemensamma ändringar, inklusive CFG-01–03. Runtimegodkännande kräver separat dokumenterad privat match, aktuellt spelbuild-ID och observerade resultat. M1.1/M1.2 har testats automatiskt, inklusive native Windows-trådtoken och syntetisk contention; CS2-callbacks har inte verifierats. Befintliga och planerade livefunktioner är fortsatt runtime-overifierade.

## Valfria experiment, lägst prioritet

| ID/funktion | Status och beroenden | Inställningar/data | Föreslagen plats och acceptans |
|---|---|---|---|
| X01 Bunnyhop | Planerad utvärdering, inte implementerad/testad; efter kärnarkitektur och regression | Default av, privat testläge, egen bindning; kräver verifierad ground-state och jumpbeteende som saknas nu | Framtida `Source/Features/Experimental/`; inga nya kommandoskrivningar; gränser för genererad tangentinput, ingen fastnad tangent och dokumenterad tidsbegränsning |
| X02 Spinbot | Endast experimentförstudie, inte implementerad/testad | Default av; kalibrerad relativ musrörelse, verifierad kamera, hårda hastighetsgränser och stopptangent | Samma experimental-katalog; ingen direkt view-angle-skrivning, inget anticheatpåstående, ingen konkurrens med Aim/Trigger |
| X03 Rörelseexperiment | Planerad utvärdering, inte implementerad/testad | Default av; uttryckligen namngiven funktion krävs före settings; velocity/ground-state saknas | Ingen allmän experimentmotor byggs i förväg; separat privat test med acceptanskriterium per experiment |
| X04 Gameplaydiagnostik | Planerad, kan börja före experimenten som teststöd | Default av; callback-ID, sampleålder, capabilitybortfall, budget/latens och räknare | Föreslagen `Source/Gameplay/Diagnostics/`; begränsad loggning, inga råpekare i export, mätt liten framekostnad |

X01–X03 får aldrig flytta fram P01–P08, A01, T01 eller deras regressionstester. Automatisk kontroll av att en match verkligen är privat är inte verifierad; etiketten "privat" får inte framställas som en teknisk garanti.
