# M1.2 controlled runtime verification

## Current prerequisite and later verification sequence

2026-10-23: the user reported actual DLL loading, visible Panorama settings and partial existing visuals. Model Glow crashed immediately when toggled; a screenshot identifies the missing SetSceneObjectAttributeFloat4 pattern. The user saw no diagnostic counter line. No callback ownership, original-call order, transition, freshness, unload or performance check is signed off. The agent did not launch or attach to CS2. Guarded null/updater paths now have automated regressions, and the installed client.dll has zero file matches for that signature. This is not a captured crash stack or proof that Model Glow is restored.

The separate OsirisMenu configuration window now exposes the same counters and pattern status via a bounded configuration-only mapping. Its owned-window and separate-process synthetic peer tests are distinct from actual DLL/CS2 execution. Native WindowsInputSink remains disabled after AUD-01. See `FIRST_RUNTIME_TEST.md` for the current package and exact manual sequence.

The normal current DLLs in `build/phase1-vs2026/Source/{Release,Debug}` use Disabled. The versioned 20261023 package uses `OSIRIS_OBSERVE_CALLBACKS=ON` and leaves collection disabled. Its matching PDB now includes compiler /Zi and linker /DEBUG:FULL information; optimized locals can still be absent. Symbols do not by themselves prove ownership, original execution or teardown. The older `build/m1-2-r/observe-debug` and unversioned release artifacts do not match this source. Locate ViewRenderHook_onRenderStart / finishInit by current symbol rather than historical line numbers.

For the established authorized user-controlled session:

1. Record Windows/CS2 build, isolate an authorized local non-VAC environment and establish the user's trusted loading/native-symbol workflow. If unavailable, leave sign-off blocked; this repository change supplies no loader or bypass.
2. Verify the current packaged observation DLL/PDB/hash against `FIRST_RUNTIME_TEST.md` and use its matching source/symbols. Keep normal Disabled. Do not enable CollectSnapshots or any input consumer in the first observation phase. Leave Model Glow off until its function is identified/validated and the crash path can be retested separately.
3. At finishInit and accepted/rejected render/scene callbacks, record actual thread/TEB tokens, original callback execution exactly once, overlaps/foreign calls/ownership latch and lifecycle. Exercise menu, connect, disconnect/reconnect, map/round/respawn/spectator and unload. Stop on ownership/lifetime violation. The detailed observation table below still applies.
4. Only after those prerequisites pass may a separately prepared collection-only build inspect publication IDs, empty-on-failure, invalidation, shutdown and measured costs. New camera/region/weapon readiness/item/inaccuracy/recoil/canScope/threat/producer clock/simulation fields must remain unknown until supplied by a separately validated adapter. Complete status/render generation/gameTime do not establish those facts or monotonic freshness.
5. Record evidence in this checklist/PROGRESS/HANDOFF, restore Disabled and keep live output unavailable. Next implementation is M1.3-LIVE adapters, followed by safe authenticated transport; the existing codec and owned-window test do not authorize a game sink. Only after data/capture/calibration/lease/teardown gates pass should a later private-session aim/trigger/UI/save/load regression session be planned. Validate current normal visuals/HUD/sounds and historical config behavior separately.

## Historical preparation before offline development (2026-10-22)

CS2 is installed (Steam app manifest build 26087496) and VS 2026 Community is available. No CS2, Steam or debugger process was running during inspection. No confirmed isolated non-VAC session or established loading/symbol workflow was available. **No CS2 or isolated loaded-DLL runtime check was executed. Runtime sign-off is pending.**

The earlier observation-only Debug build is retained as historical evidence:

- DLL: build/m1-2-r/observe-debug/Osiris.dll
- Matching symbols: build/m1-2-r/observe-debug/Osiris.pdb
- Mode/hashes/dependencies: build/m1-2-r/observe-debug/artifacts.json
- Matching diagnostic header: build/m1-2-r/observe-debug/source/Source/Gameplay/GameplayCallbackState.h

DLL SHA256: 732097771DE80248AA6BC7001032E8F3B09E3AEE56682B40B52FA26E915DC791. The imported Debug CRTs VCRUNTIME140D.dll, VCRUNTIME140_1D.dll and ucrtbased.dll are present in System32. This is static readiness evidence, not successful loading. The normal source and rebuilt build/phase1-vs2026/Source/{Release,Debug} artifacts use **Disabled**. Normal-before DLL/PDB backups are under build/m1-2-r/normal-before/.

### Historical workflow reference (use freshly rebuilt current artifacts)

1. Start your authorized local CS2 development session only after confirming it is isolated and not VAC-protected. Do not join protected servers. If you do not already have a permitted, trusted DLL-loading/debugging workflow, stop and provide that missing prerequisite; this task supplies no loader or bypass.
2. Attach the installed VS 2026 native debugger to cs2.exe using that workflow before loading the observation DLL. Load only a freshly rebuilt current observation artifact with matching PDB/full source; the paths above are historical. Verify the module/base and matching PDB are visible to the debugger. If your loading method does not expose usable native symbols, stop and resolve that workflow before interpreting observations.
3. Locate current finishInit and ViewRenderHook_onRenderStart by symbol; break after diagnostic setup, at the accepted/rejected original calls and after the entity loop. Earlier numeric line references are superseded. Use the full matching source snapshot for the new observation artifact; do not edit the restored production default to suppress a checksum mismatch.
4. While paused, inspect hookContext.fullGlobalContext.gameplayCallbacks and gameplayState. Expected observation mode: lifecycle Ready, mode ObserveCallbacks, initialization/render tokens nonzero after their callbacks, renderCalls increasing, overlaps/foreignRenderCalls=0 and ownershipViolation=false. Scene counters may remain zero if those existing callbacks were never installed/invoked; record that as not observed, not passed. Step over the original call and record its return; do not infer its execution solely from counters.
5. In ObserveCallbacks, gameplayState must remain disabled, published status Disabled and players().size()=0. This phase cannot verify generation/publication/invalidation because it deliberately does not collect. Stop collection testing on any ownership violation. Only after observation prerequisites are documented may the later controlled CollectSnapshots phase below be prepared.
6. Capture debugger values/hit counts for startup, menu and each permitted transition. Paste or save a text record with: DLL hash, Windows/actual running CS2 build, diagnostic mode, scenario, init/render/scene tokens, renderCalls/overlaps/foreignRenderCalls/ownershipViolation, snapshot status/ID/count and observed original-call return. Mark unavailable scenarios **NOT RUN**, and faults **FAIL** with the exact trigger. Breakpoint pauses cannot measure performance; an established external profiler is required for timing.
7. Follow the detailed scenario table below only where the prerequisites hold. Keep normal collection off. Restore/use the normal Disabled build after diagnostics; changing a file on disk does not change a DLL already loaded in a process.

Prepared ObserveCallbacks DLL was not loaded. No CollectSnapshots DLL was prepared, no session transition/unload was exercised and no performance data was collected. The current result is **BLOCKED: user-controlled session/loading workflow required**, not a runtime failure of Osiris.

Status 2026-10-22: **not executed in CS2**. Automated tests are recorded in PROGRESS.md. This checklist is the next task, M1.2-R; it is not approval to enable normal collection or a claim that callback ownership is already verified. No injector or input functionality was added.

## Prepare a controlled diagnostic build

1. Preserve the normal DLL/source and record its hash, compiler/configuration, Windows version and CS2 build. Use the established manual development/test workflow; this task does not supply or change an injector. Do not overwrite user configurations.
2. In Source/Gameplay/GameplayCallbackState.h change only kStartupDiagnosticMode from Disabled to ObserveCallbacks for a **Debug diagnostic build**. Build with the existing toolchain. This mode observes callbacks without enabling collection or adding game-data reads. Record the one-line variation and restore Disabled before producing a normal build.
3. Attach the existing development debugger and inspect values only while threads are stopped, or through the atomic diagnostics() accessor. Do not poll the non-atomic snapshot payload asynchronously. FullGlobalContext is reachable as hookContext.fullGlobalContext in a callback; inspect gameplayCallbacks and gameplayState there. Conditional breakpoints should be sparse because stopping changes timing.
4. There are no new log files or hotkeys. The current packaged observation build exposes a read-only Panorama Automation diagnostic label; the diagnostic mode itself remains a build-time test choice. A runtime setDiagnosticMode call is available only through an established safe debugging workflow; mode changes apply on the next accepted render callback.

## Confirm callback facts before collecting

Inspect GameplayCallbackState::diagnostics(): lifecycle, mode, initializationThread, renderThread, renderCalls, overlaps, foreignRenderCalls, ownershipViolation, playerSceneThread/playerSceneCalls, weaponSceneThread/weaponSceneCalls and sceneDuringRender.

- Break on the SDL full-initialization path and finishInit during startup. Record actual caller threads and confirm a single initialization sequence. The baseline uses a plain completion flag, not a concurrent-init barrier; the render scope cannot protect construction of FullGlobalContext.
- At finishInit, lifecycle becomes Ready after existing config/classifier initialization and before hook installation. initializationThread identifies that callback; its name is not proof of the engine's main thread.
- renderThread is the first observed diagnostic render token. The token is the SDK NtCurrentTeb value, not a Windows thread ID or game pointer; it is valid only for that OS thread's lifetime and can be reused later. Compare with debugger thread/TEB information. Initialization and render tokens may differ; investigate rather than assuming they must match.
- renderCalls counts accepted diagnostic render entries; overlaps counts rejected busy entries. One nonblocking guard spans original render-start plus Osiris postprocessing. A busy render entry calls the original only, with no Osiris postprocessing or snapshot mutation.
- Confirm whether render calls nest or arrive on another token, and whether player/weapon scene callbacks occur on the same or other threads. sceneDuringRender means an observer saw the diagnostic render scope active; it is not a duration or proof of concurrent engine mutation by itself.
- overlaps or foreignRenderCalls > 0, unknown token 0 or ownershipViolation=true prohibit collection for the rest of that context. The latch is intentionally not cleared by changing modes. Stop, preserve evidence and use a fresh context after investigation; do not bypass the guard to continue a test.
- Scene callbacks only touch atomic diagnostics for M1.2. They still execute existing visual code; these diagnostics do not prove that all baseline visual state is thread-safe.

## Exercise snapshot lifecycle

Only after callback observations support a controlled collection test, make a separate Debug build with kStartupDiagnosticMode=CollectSnapshots. This is still an unverified diagnostic build, never the normal default. Run it in the intended private development environment with no input consumers. Inspect gameplayState.published() after collector.finish, while holding the render scope or with debugger threads stopped.

Record frame.id, status, reason, collectedPlayerCount, players().size(), localPlayer, gameTime, timeProgress and callback.{source,threadToken,sequence}; also record gameplayState.lastInvalidationReason().

| Scenario | Expected code behavior and evidence to record |
|---|---|
| Startup/main menu | No collection in Disabled/ObserveCallbacks. In controlled collection, missing entity list gives Unavailable, empty player view and reason EntitySystemUnavailable. An existing list with no known local pawn is not proof of a connected match; local fields remain unknown |
| Connect | Record first known local full handle, session, generation, source RenderStart and accepted thread token. Confirm identities/positions against observed entities; Complete alone does not validate the offsets or all fields |
| Disconnect/map change | If list/local availability changes or time rewinds, old IDs become invalid and session changes on recovery. Verify this actually occurs. Same handles plus continuous game time are **not** an authoritative boundary signal. If old-session data can appear valid across a transition, leave normal collection off and add a separate verified lifecycle signal before approval |
| Round transition/respawn | Record handle serials, local replacement and time progression. A round boundary is not automatically a new session; old collection IDs must still fail after replacement/publication. Do not infer round events from time progression alone |
| Spectator/local replacement | Record whether the controller's base pawn changes, disappears or remains unchanged. Existing lookup is the controller's base pawn, not guaranteed observer target or controllable pawn. Changed/lost local handle invalidates the old identity; same-handle transitions need additional evidence |
| Failed identity/list/local context | A failed collection exposes no players. reason distinguishes IdentityMismatch or CollectionContextChanged; collectedPlayerCount can describe discarded candidate rows, not available data |
| Capacity | Limit is 128. Overflow reports CapacityExceeded, available player count 0, discarded count 128; subsequent player reads stop. Synthetic tests cover this; do not manufacture unsafe live entity corruption |
| Paused/missing/rewound time | Unchanged/Missing/Rewound are explicit. Generation can advance with unchanged gameTime and is not a simulation tick. Rewind advances session. No elapsed-millisecond freshness or collection duration is currently supplied |
| Reset | Under the accepted render scope, invalidate() explicitly clears ID/data and invalidates earlier keys/IDs by the next session. Do not treat a manual reset as automatic map-boundary detection |
| Shutdown/unload | Callback lifecycle closes; gameplay state is terminal Shutdown with no data and cannot be reenabled. Render scope must release before FullGlobalContext destruction. Verify actual scene/render callbacks are quiescent through teardown using the debugger. The guard is not a general in-flight callback barrier or safe-unmapping proof |

## Evidence required for normal collection

Save a concise runtime evidence record with actual callback tokens/thread identities, overlap/reentrancy observations, mode, CS2/Windows/build identifiers, the scenario table results and measured overhead using an established external profiler. Do not use breakpoint pauses as timing measurements.

Before normal collection can be enabled, establish reliable context ownership and engine-object lifetime, authoritative or demonstrated session invalidation across every relevant transition, safe teardown, bounded memory/per-frame cost and an appropriate verified age source if later consumers require elapsed-time freshness. No existing monotonic source was verified in this task; generation-only checks must not be relabeled as milliseconds. Native SDK thread-token tests are not CS2 callback verification.

Restore kStartupDiagnosticMode=Disabled, rebuild and retain the normal default. Missing evidence leaves normal collection off. After M1.2-R is documented, the next development task is M1.3: required camera/eye-ray and hitbox source investigation within milestone 1, without input generation. Their runtime-dependent work remains pending; independent offline consumers are now implemented as described in MODEL_HANDOFF.md. Recommended model: GPT-6.1 Sol High; missing runtime evidence is not a reason to use Astra.
