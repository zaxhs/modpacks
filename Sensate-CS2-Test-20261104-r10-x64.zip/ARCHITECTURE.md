# M1.6 observation extension (2026-10-24)

Settings wire v4 carries expanded local scalar observations, projected origin/identified enemy diagnostics and SDL input observations. Matching DLL/menu are required; .cfg format stays unchanged. Five Dumper-referenced fields use the existing schema resolver, exact installed class/offset/type-tag checks and existing PlayerPawn/collector/snapshot paths. Camera-local origin, v_angle and last-executed command values remain raw observations: no CameraSample, hit region or simulationSequence is fabricated. Snapshot state102800B, fixed120-row trace14408B; existing128KiB/1MB/4096B limits hold.

The separate menu owns a1024-row bounded trial recording and a click-through/no-activate display window. Current replies drive the existing BunnyhopEngine or read-only module tests.10s/250ms lease, focus/data/identity/settings/clock stops remain. There is no input sink, angle/attack write or persistent SDL event hook. Public SDL read APIs are resolved once, version gated, and GetKeyboardFocus is only called after SDL_IsMainThread. No SDL object pointer crosses a frame or wire boundary. See current MODEL_HANDOFF and FIRST_RUNTIME_TEST for exact limits and pending runtime evidence.
# M1.5 live observation consumer

Existing settings v3 request/reply summary now feeds the existing BunnyhopEngine in the separate Win32 menu process during an explicit bounded validation session. It is current local diagnostic data, not retained history or an authenticated action transport. DLL timed collection has250ms source-clock heartbeat and10s hard expiry plus10000-callback cap. No waits/file IO/new threads or decision math in the DLL. The consumer independently checks foreground PID, local full key, QPC age/order, observed tick/generation progression and controls; it emits logs only. MovementController's simulationSequence contract and disabled native sink are unchanged. No keyboard/mouse/view/attack write or new command ABI is introduced.
# M1.4 bounded local telemetry — 2026-10-24

Existing collector now timestamps collection start in the QPC domain. A separate fixed<16KiB GameplayProbe buffer owned by FullGlobalContext records120 explicit local diagnostic rows, never actionable gameplay frames. RenderingHookEntityLoop records after existing publication; callbacks still own the state and no game pointer crosses a frame boundary. Settings v3 carries current diagnostic summary and explicit retained-history download; phase ownership protects each copy. Menu CSV writing is outside the DLL. No new thread, allocation path, dependency, automation transport, native output or command write. Producer QPC time is distinct from game time, observed simulation tick and the still-unknown simulationSequence. Microsoft QPC guidance: https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps .
# M1.3 data/probe addition — 2026-10-23

GameplaySchema is a fixed-layout, bounded metadata resolver owned by FullGlobalContext; existing wrappers borrow current entities and copy optional values into the existing snapshot. It caches offsets only. No new framework, allocation, game call, thread, gameplay IPC or output path. The normal startup collector stays disabled. An explicit settings-menu operation may request a bounded120-callback read-only probe after callback prerequisites; settings v2 transfers diagnostic aggregate counts only. Metadata validation does not replace object-lifetime/runtime validation. Read MODEL_HANDOFF.md for exact layouts and unresolved quantized view-offset, camera, timing and output contracts.
# r3.1 loading-policy correction — 2026-10-23

LaunchMode is now diagnostic only. Command-line availability is separate from the required live process identity. GUI and owned tests share startMapper, which invokes the unchanged reviewed injector CLI; no duplicate mapper is introduced. Explicit isolated-session authorization, package/PE checks, PID/creation/path revalidation, file locks and the durable one-attempt ledger remain mandatory. Entry-point completion (CLI exit 0) is distinct from live Osiris readiness; nonzero failure may retain partial remote state. Previous sections requiring -insecure describe historical launcher policy, not an injector or Windows prerequisite.

# r3 implementation / compatibility boundary — 2026-10-23

User-supplied compatibility cross-check: the revised caller pattern 0F 11 74 24 ? E8 ? ? ? ? FF C6 48 83 C7 0C matches exactly once at client RVA 0xB15490. Its E8 displacement resolves to RVA 0x16AE00, identical to the implemented direct-entry fingerprint. Installed build 26144732 and module hashes were rechecked and unchanged. The supplied 72-byte ChannelInfo1 report agrees with the disassembly and dump-backed correction. No further production change was needed; the direct executable-entry match avoids introducing an unchecked call-target resolution. verified-patterns.json includes both independent matches.

Windows build26144732 files identify the current inspected ABI. Dump17:25 + r2 code/PDB + installed instruction analysis establish ChannelInfo1 stride 72 (old64); ChannelInfo2 remains 132. New Sound signature binds indexing and resolves the existing global, uniqueness mandatory. This establishes strides/fields used, not concurrent Sfx lifetime or callback ownership. No speculative blocking lock in render.

SetSceneObjectAttributeFloat4 now resolves by a unique63-byte entry fingerprint at client RVA16AE00, inside the already bounded executable-section search. Nine call sites and final movups copy support the existing RCX/EDX/R8 float4 ABI. The short prefix was ambiguous and rejected. Exact RIP-table context intentionally restricts compatibility; changed binaries need revalidation. Missing/ambiguous entries remain null; no stale fallback address. The client and Sound global are separate dependencies.

MovementController is a normal-CRT helper component, not included in the DLL. It consumes the existing snapshot's optional grounded field and camera/time/identity, yields finite bounded proposals, and owns reset/activation state. No input wire-version change or native delivery is introduced. Twelve Settings metadata fields are shared with DLL-safe config/Panorama and the native menu. Configuration remains 4096, worst 3638; no extra memory pool/framework/threads. Native input remains blocked after AUD-01.

Launcher startup validates files and starts/reuses the settings application independently of game discovery/launch mode. Loading keeps the separate explicit gate. Eight menu pages retain existing visual settings; Sound is now its own page. Startup process existence is distinct from configuration-peer readiness.

References: [upstream Sound layout](https://raw.githubusercontent.com/danielkrupinski/Osiris/master/Source/CS2/Classes/Sound.h) and [upstream client patterns](https://raw.githubusercontent.com/danielkrupinski/Osiris/master/Source/MemoryPatterns/Windows/ClientPatternsWindows.h) still expose the historical layout/signature inspected this session; no blind merge used. [Official CS2 updates](https://www.counter-strike.net/news/CS2?l=english) describe game updates, not private C++ ABI guarantees. [Microsoft minidump exception stream](https://learn.microsoft.com/en-us/windows/win32/api/minidumpapiset/ns-minidumpapiset-minidump_exception_stream) defines the dump fields used. Local disassembly/dump evidence is authoritative for the narrow correction.

# Föreslagen arkitektur

## Launcher / Sound stability boundary — 2026-10-23 r2

Tools/Launcher is a separate normal Win32/CRT application. It compiles the copied reviewed injector's unchanged file validator and delegates actual mapping to its CLI; no second mapper or new DLL import/thread/framework. Package SHA256 is integrity checking, not authentication. WinVerifyTrust uses only the local cache, without online revocation. WMI Win32_Process.CommandLine is read-only and can be unavailable; identity combines a live process handle, PID, creation time and image path. Mode labels are launch-argument observations, not effective protection/server attestation. No -insecure observation => no loading action. Validated DLL/CLI/runtime files are locked against writing/deletion during an attempt. A flushed per-user attempt journal forbids blind retries; closing the launcher cannot unload a mapped image or force termination. Normal menu and offline-helper tests are ordinary owned children, whose exit codes are distinct from readiness.

Sound collection still runs only in the accepted existing render scope after the original callback; it adds no sound hook/thread or entity enumeration. Samples retain copied origin/time and integer GUID, never Sfx/entity pointers across frames. Both parallel arrays must satisfy typed structure/count/storage checks before iteration. Filename failure, missing/nonfinite time and rewinds cannot publish new invalid samples; stop clears only its type and shutdown is terminal. Per-type retained GUIDs are bounded to256. Sound panel allocation now reserves bookkeeping before UI construction, rolls back failure, and cannot publish an out-of-storage index. Null child storage/transforms and failed transform-vector allocation are rejected. Bomb Defuse uses its own config variable. These are source-level corrections, not proof of engine pointer validity or Sound.h's hard-coded padded layouts. Non-null freed Sfx objects, concurrent engine writes, correct live geometry and unsubmitted transform ownership/freeing remain unresolved runtime/ABI contracts. No speculative synchronization or guessed free function was introduced.

The file-only Sound signature resolves uniquely in installed soundsystem.dll; disassembly shows a RIP-relative qword pointer load (the pattern begins after its REX prefix). This is separate from the missing client.dll SetSceneObjectAttributeFloat4 signature. Uniqueness proves neither global-object layout nor lifetime. The inspected [upstream Sound.h](https://raw.githubusercontent.com/danielkrupinski/Osiris/master/Source/CS2/Classes/Sound.h) retains the same historical padding and supplies no independent current ABI proof. `sound-pattern-evidence.json` and disassembly are under build/launcher-integration-20261023. No new offsets or pattern replacements.

### Loading contract and risk reporting

[Valve Trusted Mode FAQ](https://help.steampowered.com/en/faqs/view/09A0-4879-4353-EF95) documents blocked foreign injection, signing requirements outside Trusted mode, insecure unsigned sessions and possible Trust Factor effects. This unsigned package targets an explicitly started local **-insecure** session; the launcher rejects the third-party-only/default/unknown paths. [Osiris README](https://github.com/danielkrupinski/Osiris#loading--injecting-into-game-process) specifies manual mapping rather than LoadLibrary and names detected third-party injectors. Reusing this injector is not evidence that it is undetected.

Keep VAC, server behavioral enforcement (VAC Live/VACNet) and Trust Factor distinct. Public documentation is not a complete algorithm, coverage or safety specification; do not reduce risk to a specific guessed list of movements or infer that Windows-generated input avoids it. No behavior shaping to evade detection, bypass, concealment or undetectability claim was added. An observed -insecure argument is not proof of the actual session, and owned test-host success proves no CS2/anti-cheat compatibility. See FIRST_RUNTIME_TEST for the exact manual boundary.

## Implemented Windows settings window — 2026-10-23

`Tools/SettingsMenu/OsirisMenu` is a separate normal-CRT Win32 application, with no renderer dependency or additional game hook. It presents a dark sidebar, real-unit sliders/edits, named selectors, region buttons, local key recording, collapsible advanced settings, full-schema profile load/save/duplicate and configuration diagnostics. `MenuKey` is the only schema addition (default Windows VK_INSERT=45); historical files retain that default. Existing Panorama controls remain until the replacement has actual CS2 runtime evidence. Opening either menu does not change or arm settings.

The menu uses `RegisterHotKey(MOD_NOREPEAT)` while its own window or a foreground process named cs2.exe is active, unregisters elsewhere, and rechecks foreground at the toggle event. Foreground eligibility is polled at 50 ms; a small registration race remains and executable naming does not prove a private/non-VAC session. Local recording temporarily unregisters the menu key, rejects reserved menu keys, and waits for key release before registration. No global keyboard/mouse hook is installed. Escape and Close wait for menu/escape/mouse release before hiding. Focus/clip restoration is attempted only after owned focus, to a still-existing unchanged previous window; focus loss closes without forcing another application's focus. No synthetic key release, cursor warp or game input is injected. Native focus, raw-input deactivation, exclusive fullscreen and real per-monitor scaling in CS2 remain runtime requirements. Windows may deny foreground activation; the app then flashes its taskbar button and reports the denial.

`Source/UI/Windows/SettingsProtocol.h` defines a fixed configuration-only request/reply slot: two 4096-byte payloads, operation/result, revision and small callback/pattern/persistence diagnostics. Windows Interlocked operations publish the slot; one menu and one DLL instance per Windows session are supported. The DLL resolves the five required functions directly from locally verified non-forwarded KernelBase exports, maps once at initialization and unmaps at shutdown. It creates no thread, static import or CRT dependency. One extra fixed 4096-byte scratch array belongs to PanoramaGuiState; the existing 1,000,000-byte pool and 4096-byte configuration limit stay unchanged. Per accepted render callback the service only checks a slot; bounded parse/serialize work occurs on a request, without waiting, sleeping or new disk operations. Live cost and teardown still require measurement.

Refresh serializes the actual ConfigSchema. Apply compares the current serialized configuration revision before parsing a copied, bounded payload through the same CFG-03 candidate/publication/handler path as file loading, then schedules existing auto-save. Stale edits are rejected and current values returned. Stop bypasses the revision comparison to disable global Input/Aim/Trigger; it is a queued configuration request, not an out-of-band process kill or gameplay-input transport. Acceptance reports persistence pending; later refresh distinguishes pending/failed/completed save state. The menu's named-file save uses an exclusive temporary file and replacement with a uniquely named backup. No default.cfg is overwritten by merely opening or closing the app.

The mapping uses the creator's default token ACL and the session-local namespace. All payload lengths and configuration values are treated as untrusted. The FNV revision detects stale edits; it is not authentication. This channel has **no adversarial same-user isolation guarantee**, no game pointers, snapshots or mouse packets, and must not be repurposed as the future authenticated gameplay transport. UI says `DLL connected` for this configuration peer; `Input helper disconnected` remains accurate. A processing request is never blindly reused; unclaimed requests are canceled after peer loss. A stalled processing peer still requires manual process/runtime investigation. The client clears connected labels on peer loss and marks unanswered requests/diagnostics unconfirmed after two seconds; it does not reclaim a Processing slot on a timeout.

Owned Windows evidence: `window-probe-unrestricted.log` records a normal message-loop menu process, actual visible rendering, a posted WM_HOTKEY close, focus and clip restoration to a separate owned window, reopen and clean exit (all 1, exit 0). `hotkey-probe-unrestricted.json` records successful Insert/F9/F10 registration/unregistration. The restricted tool process returned ERROR_ACCESS_DENIED=5 for all three; the explicitly approved ordinary test process succeeded, so no workaround or alternate input hook was added. These are actual Windows observations with owned windows and window-local messages, not physical key events or CS2 evidence. PrintWindow previews from the direct synchronous self-test can omit child paint; the inspected normal-loop capture is `menu-loop-visible.bmp`. No game was launched and no synthetic keyboard/mouse event was sent.

## Crash evidence and research — 2026-10-23

The user reported an immediate Model Glow toggle crash and supplied a missing-pattern dialog. It names `SetSceneObjectAttributeFloat4`: `0F 11 74 24 ? E8 ? ? ? ? FF C6 48 ? C3`. The installed client.dll (SHA256 `CCAF4E4926BABC052994502B19EC61198A11008A39DCE712921B93DD993BE9F5`) has zero file matches; see `build/runtime-integration-20261023/pattern-evidence.json`. This identifies a concrete null-call path in SceneObjectAttributes, not a captured crash stack. Both float/color setters now reject the missing function. ModelGlow also refuses a null or incompatible original updater and never restores null; those lifecycle defects were independently reproduced by tests. Neither change proves all current CS2 scene data/lifetimes correct. The missing signature remains visible and the effect remains blocked, rather than replaced with a guessed address.

Public primary references checked on 2026-10-23; no third-party implementation was copied or new framework installed:

- [Microsoft RegisterHotKey](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey): repeat suppression and reserved F12 constrain the menu key; the emergency key is locally polled, not registered as F12.
- [Microsoft foreground rules](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setforegroundwindow): activation can be denied. The app does not bypass those restrictions.
- [Microsoft Interlocked access](https://learn.microsoft.com/en-gb/windows/win32/sync/interlocked-variable-access) and [mapping security](https://learn.microsoft.com/en-us/windows/win32/memory/file-mapping-security-and-access-rights): shared-memory ordering and default token ACL semantics inform the bounded configuration channel.
- [Current Osiris client patterns](https://github.com/danielkrupinski/Osiris/blob/master/Source/MemoryPatterns/Windows/ClientPatternsWindows.h): inspected source still contains the same missing signature; it supplies no independently validated replacement for this installed game.
- [CounterStrikeSharp README](https://github.com/roflmuffin/CounterStrikeSharp) and [its Schema implementation](https://github.com/roflmuffin/CounterStrikeSharp/blob/main/managed/CounterStrikeSharp.API/Modules/Memory/Schema.cs): server-side schema lookup by class/member name is a useful research direction. Its server offsets, callbacks and ABI are not validated client interfaces for this Osiris tree. [AlliedModders' older cs2 branch](https://github.com/alliedmodders/hl2sdk/tree/cs2) explicitly redirects to s2sdk; the replacement branch could not be retrieved in this research pass. [Valve Source SDK 2013](https://github.com/ValveSoftware/source-sdk-2013) is not evidence of current CS2 client layouts. Do not paste any of these layouts into production.

No researched reference establishes this build's eye/camera ray, model/bone geometry, visibility, weapon readiness/item/clock, ground state or safe live output. Those still need current-client source/ABI evidence plus controlled runtime validation. This blocks live aim, trigger, recoil/prediction, scope, bunnyhop and spin actions; adding synthetic state machines alone would not resolve it.

## Functional correctness versus anti-cheat risk

The DLL reads internal game memory through GameClient wrappers and installs existing initialization/render/scene hooks. Its loading mechanism is external to this tree. The new menu is an external Windows configuration app; that does not make the DLL external. WindowsInputSink remains disabled after AUD-01; the helper's simulated actions do not establish safe game input. A future enabled automation path would still be automated gameplay behavior even if Windows delivered its mouse events.

[Valve's VAC FAQ](https://help.steampowered.com/en/faqs/view/571A-97DA-70E9-FF74) describes cheat-related secured-server bans, and the [Steam Subscriber Agreement](https://store.steampowered.com/subscriber_agreement/) governs cheats/automation. Successful builds, signature resolution or private functional tests provide no evidence of detection safety. No VAC bypass, disabling, concealment or detection-evasion implementation is supplied, and no component is claimed undetectable. Runtime testing remains restricted to an independently established authorized isolated environment; the application cannot establish that a session is non-VAC.

## Current diagnostic build boundary

`OSIRIS_OBSERVE_CALLBACKS` is an explicit separate CMake option (default OFF). The observation Release DLL records callback diagnostics while leaving snapshot collection disabled. The existing Panorama Automation label reads those diagnostics only in the accepted render scope and reports the helper disconnected and automation data unavailable. Normal Release retains Disabled; neither build creates a live transport or enables native output. The current observation PDB uses /Zi plus /DEBUG:FULL; optimized locals can still disappear. See `FIRST_RUNTIME_TEST.md`; no CS2 execution or callback ownership has yet been observed.

## Implemented offline boundary — 2026-10-22

This section supersedes older proposed/unimplemented status statements below. The later architectural detail remains a design/evidence reference, not a claim of deployed live transport.

Source/Automation splits shared integer metadata/commands/profile conversion (DLL-safe headers) from normal-CRT helper-only Geometry, DecisionData, Aim, Trigger, Coordinator, Input and WindowsInputSink. Tools/InputHost is a separate Win32/CRT executable. DLL Release still has no static imports/CRT/new threads/exceptions. No live transport is implemented; a bounded explicitly encoded 56-byte input-packet codec exists for isolated verification only. No struct/padding serialization or raw game pointers cross it.

GameplayState retains two fixed 128-player buffers, now 78,224 bytes within a 128-KiB cap; the pool stays 1,000,000 bytes. New optional fields are explicit adapter contracts. Five world-space spherical regions do not assert that CS2 hitboxes are spheres: a future adapter must supply validated conservative geometry/model transforms. Full skeletal transforms, camera FoV/eye/direction, velocity, stable weapon IDs/readiness/inaccuracy/recoil/canScope, threat and producer-clock/simulation data are not fabricated by the existing collector. Failed publication clears sample context and players.

Coordinator requires known fresh camera/sample/simulation/local life/team/scoped/weapon readiness/ammo, coherent identities, explicit safety facts and a nonce/session/revision arm. Safety facts (foreground, capture available, connected, local alive, calibrated) are independent optional inputs; unknown fails closed. Same/older simulation samples never repeat actions. Focus/settings/session/weapon/item/scope changes invalidate the lease; physical button conflicts, sink failure and shutdown stop output. After a new arm, keys must first be released. poll() expires accepted-sample leases when the producer stops. Callers must use one established monotonic clock domain, periodically poll safety and resolve the effective profile's bindings. These caller facts are not supplied by a live adapter today.

Aim returns angular proposals with bounded linear/exponential/eased smoothing; prediction is finite velocity extrapolation only, recoil is supplied angular data and threat is explicit. Fixed region priority is head, neck, chest, stomach, pelvis. Trigger uses nearest provided region intersection (including blocking allies/immune players), deterministic delays and a uniform-cone geometric coverage estimate. This estimate is not validated game hitchance. A motion proposal suppresses firing from that observation; a later simulation ray is required. Scope requests require explicit canScope; the coordinator additionally requires a new calibrated lease after observed scope change. Mouse count quantization is bounded by both counts and the configured angular maximum, including sub-count accumulation.

Config reuses existing 2-byte typed storage and CFG-03 staging. Automation range, timing and duplicate-profile errors reject the entire candidate; legacy semantics remain. Four embedded slots each persist Item plus 16 essential overrides; Item 0 disables a slot, other settings inherit globally. Full helper profiles have Version=1/Item/Settings and fit a separate bounded file. Global InputEnabled remains required. Presets keep global input/aim/trigger off; defaults clear slots. Panorama uses the same metadata and strict numeric command path, with explicit offline-unavailable notice. Current config is 3303 bytes; tested worst-case serialization is 3427, below unchanged 4096. Full-buffer reads and incomplete serialization are rejected. Native temporary-file replacement reports rename failure; failed saves keep dirty state and suppress retries until another edit. This is not a power-loss durability guarantee; actual native syscall I/O remains runtime-unverified.

Status 2026-10-22: M1.1 och M1.2 är implementerade och automatiskt testade, med runtimegodkännande kvar; övriga framtida moduler är fortfarande design. CFG-01–03 är också implementerade, se PROGRESS/MODEL_HANDOFF. Fas 1-källor och begränsningar finns i SOURCE_MAP/AUDIT. Föreslagna framtida API:er får inte antas existera.

## Faktiskt M1.2-kontrakt

GameplayCallbackState i FullGlobalContext lägger till en icke-blockerande atomic_flag-port för render-start samt atomiska diagnoser. finishInit sätter Cold → Ready före hook-installation. Porten tas före originalets callback och släpps före eventuell kontextförstörelse. En avvisad överlappande/reentrant render-entry anropar originalet en gång och kör ingen Osiris-efterbearbetning. Den accepterade normala vägens ordning är bevarad. Detta är en liten nödvändig korrigering av den tidigare oskyddade render-ägarmodellen, inte en allmän omskrivning av hooks.

Default kStartupDiagnosticMode=Disabled lämnar insamling av. En kontrollerad diagnostikbuild kan välja ObserveCallbacks (bara atomiska observationer) eller CollectSnapshots (uttryckligt diagnostiskt prov). Första observerade render-token binds som policy; det är inte bevis för rätt speltråd. Olika render-token, token 0, overlap eller sekvensöverslag spärrar insamling för kontextens livslängd. Scene-callbacks skriver endast atomiska observatörsfält för M1.2 och får inte läsa snapshotpayloaden.

WindowsPlatformApi::currentThreadToken använder SDK:s inlinade NtCurrentTeb, verifierad i den lokala Windows SDK 10.0.26100.0-definitionen och ett native enhetstest. Token är en OS-tråds TEB-identitet under dess livstid, kan återanvändas senare och är inte ett spelobjekt eller Windows thread-ID. Ingen ny import/TLS/heap/tråd skapas. Atomiker har kontrollerad lock-free-implementation för måltyperna; busy ger omedelbart avslag, ingen vänteloop.

FrameSnapshot har nu callbackkälla/token/sekvens, explicit Missing/First/Advanced/Unchanged/Rewound för observerad gameTime, felorsak och collectedPlayerCount. Vid misslyckande är spelarvyn tom även om räknaren visar kandidatrader som förkastades. lastInvalidationReason skiljer kontextreset från ett enskilt insamlingsfel. Alla dessa värden är diagnostik, inte tillåtelse till input. isCurrent är fortfarande bara publiceringsidentitet; ingen monoton tid, millisekundålder eller verifierad simulationstick har införts.

Snapshotens payload och direkta GameplayState-metoder får bara användas av den accepterade render-ägaren, eller när debuggern stoppat trådarna. Det atomiska diagnostics()-resultatet är en sammanställning av oberoende observationer, inte en konsistent flerfälts-snapshot. Atomic_flag:s acquire/release ger ordning mellan accepterade render-entryn; godtyckliga parallella span-läsare är fortfarande otillåtna. Befintliga scene-/visuals-tillstånd utanför snapshoten får ingen allmän trådsäkerhetsgaranti.

Shutdown stänger callbacklivscykeln, invaliderar payloaden och är terminal: state kan inte återaktiveras eller publicera en äldre kandidat. Portens scope måste släppas före FullGlobalContext-förstörelse. Befintlig hook-återställning garanterar däremot inte att alla redan startade scene/render-callbacks är borta. En generell teardown-/unmapping-barriär är fortfarande obevisad och ingår i runtimeporten, inte i detta påstående om säkerhet.

Baslinjens SDL/full-init använder fortfarande en vanlig completionflagga, inte en generell samtidig-init-barriär. Render-porten gäller först när FullGlobalContext finns. Runtime måste bekräfta en enda initsekvens; detta har inte antagits säkert från metodnamnen.

Runtime är inte genomförd. Se M1_2_RUNTIME_CHECKLIST.md för start/meny/connect/disconnect/map/round/respawn/spectator/unload och exakta observationsfält. Saknad lista/lokal pawn/tidsbakgång är tillgängliga signaler med testad invalideringsmekanik; att de fångar alla verkliga sessionsgränser är fortfarande en hypotes. Round-/observer-transitioner kan lämna samma pawn/handtag/tid och får inte uppfinnas som verifierade events. GameRules rundtider finns, men ger inte i sig en auktoritativ map-/anslutningsgeneration.

## M1.1-grunden, uppdaterad med M1.2-metadata

`gameplay::GameplayState` i FullGlobalContext äger två fasta FrameSnapshot-buffertar à 128 PlayerSnapshot. HookContext exponerar ägaren. Uppmätt storlek i Windows x64-tester: state 24 832 byte, frame 12 392 byte, player 96 byte; CallbackState tillkommer med 96 byte (totalt 24 928 byte). Ingen ny heap, tråd, import, exception eller konfigurationsvariabel. Statisk kontroll håller state under 32 KiB och FullGlobalContext inom befintlig 1 000 000-bytepool; detta är inte en runtime-mätning av poolens toppförbrukning.

Collector.begin/collect/finish används i den befintliga RenderingHookEntityLoop efter originalets render-start, inte i scene-updater, UI eller en worker. Samma enumeration och redan utförd pawn-klassificering återanvänds. Visuals flyttas inte och deras inbördes ordning ändras inte. Insamling är default av tills M1.2-R har verifierat callbackens faktiska ägarskap/livscykel. Produktionsvägen styr setEnabled via den uttryckliga startup-diagnostikmoden; ingen meny eller persistens lades till. Avläge gör inga nya speldatauppslag.

PlayerSnapshot kopierar full pawn-handle/session, optional local/alive/team/health/world-origin/immunity/scoped och optional aktivt vapen. WeaponSnapshot kopierar full handle/session, befintligt EntityTypeInfo-classIndex och optional icke-negativ clipAmmo. Indexet är byggspecifikt, inte en stabil profilnyckel eller ItemDefinitionIndex. TT/CT är kända lag; övriga/defaultvärden förblir unknown. Position/tid måste vara finita, negativ health/ammo blir unknown. Döda spelare behålls med alive=false. Ingen framtida eligibilitypolicy byggs in i insamlingen.

En saknad optional lämnas tom, inte 0/false. En felaktig pawn-identity/back-reference/handle, förlorad entitetslista, lokal-pawn-byte under insamling eller kapacitetsöverskridande ger en felstatus utan publicerade spelare. Saknat/okänt aktivt vapen lämnar just vapendata okända. Complete betyder att insamlingen slutförts, inte att alla fält finns, att en simulationstick observerats eller att input får utlösas.

Inaktiv buffert byggs utan att ändra den publicerade vyn; finish publicerar genom indexbyte. Vid fel blir den publicerade spelarvyn tom och gammal bra data återanvänds inte som färsk. Session ökas vid känd lokal-pawn-förändring/bortfall, entitetslistbortfall, observerad tidsbakgång och explicit invalidate/avaktivering. Unload ger terminal Shutdown. Räknare får inte wrapa; uttömning spärrar fortsatt insamling. Detta är inte bevis för att alla map-/disconnect-gränser hittats.

SnapshotId innehåller session och insamlingsgeneration. gameTime är optional observerad curtime från den befintliga GlobalVars-wrapparen (ärvd PAD(48)/FIXME); ingen ny monoton klocka eller simtick lades till. isCurrent kontrollerar aktuell publiceringsidentitet, inte millisekundålder. Referenser/spans får bara lånas fram till nästa begin/invalidate i samma exekveringskontext; kopiera värden eller ID för längre bruk. Inga trådsäkra läsare eller pekare till spelobjekt publiceras.

M1.2-R återstår för att verifiera tråd-/callbackägarskap, explicita sessionsgränser, tidsproveniens och kostnad före normal aktivering. Kamera/eye-ray, hitbox/ben, visibility, recoil, velocity, reload/fire-ready och stabil vapennyckel är fortfarande otillgängliga i snapshoten. Ingen ny input, combatlogik eller IPC finns. Återstoden nedan är den tidigare målarkitekturen; detta implementerade delkontrakt har företräde där förslagen går längre.

## Ansvar och gränser

```mermaid
flowchart LR
    G[CS2 via befintliga GameClient-wrappers] --> D[SnapshotBuilder i DLL]
    D --> S[Validerat FrameSnapshot]
    S --> A[AimController]
    S --> T[TriggerController]
    C[Config och vapenprofiler] --> A
    C --> T
    A --> M[InputCoordinator]
    T --> M
    M --> P[Begränsad asynkron lokal IPC]
    P --> B[InputBroker.exe]
    B --> W[Win32 SendInput]
    B -->|nycklar, fokus, status, kvittenser| P
    U[Befintlig Panorama] --> C
```

DLL:en är fortfarande intern eftersom den kör i spelprocessen och läser spelets objekt. Hjälpprocessen gör enbart inputgenereringen extern. Konstruktionen medför inga garantier om anticheat och innehåller ingen bypass.

| Del | Föreslagen plats | Ägare/livslängd | Tillåtna beroenden |
|---|---|---|---|
| Dataadaptrar | Befintligt `Source/GameClient/` | Kortlivade wrappers i verifierad callback | Befintliga patterns och nullable fält |
| Snapshot och capabilities | `Source/Gameplay/` | `GameplayState` i FullGlobalContext | Värdetyper, fasta arrayer, en läsare/producentkontext |
| Rena beräkningar | `Source/Features/Combat/Aimbot/`, `Triggerbot/` | Separata stateobjekt | Snapshot, immutable settings, injicerad klocka/RNG |
| Samordning | `Source/Input/InputCoordinator.h` | Ett InputState i FullGlobalContext | Featureintentioner och brokerstatus |
| DLL-transport | `Source/Input/Windows/` | Ett stängningsbart transportobjekt | Dynamiskt upplösta Win32-funktioner, fasta buffertar |
| Protokoll | `Shared/InputProtocol/` | Serialiserade meddelanden | `<cstdint>`/byteformat, ingen GameClient/HookContext |
| Windows-input | `Tools/InputBroker/` | Separat, manuellt startad EXE | Dokumenterade Win32-API:er, normal CRT |
| UI/config | Befintliga `Source/UI/Panorama/`, `Source/Config/` | Befintliga ägare + typade profiler | Endast implementerade funktioners inställningar |

Ingen hjälpprocess startas från DllMain. Ingen GameClient-pointer, HookContext, Panorama-panel eller STL-container skickas i IPC. Inga direkta anrop till spelets attack-/sikteskommandon föreslås.

## Snapshotkontrakt

Definiera först små rena typer, inte ett nytt parallellt entitetssystem:

- `EntityKey`: hela `CEntityHandle::value` samt en egen sessionsgeneration. Index ensamt är otillräckligt när platser återanvänds.
- `FrameSnapshot`: sekvensnummer, sessionsgeneration, monoton insamlingstid, observerad speltid, eventuell simtick endast när verifierad, settingsrevision, capabilityflaggor, local-data och ett begränsat antal PlayerSnapshot-värden.
- `PlayerSnapshot`: nyckel, validerad entitetstyp, optional lag/liv/health/immunity, world-origin och optional senare hitboxer/armor/velocity. Spara inga wrappers eller råpekare.
- `LocalSnapshot`: samma kärnfält, aktivt vapen, scoped och först senare verifierad eye-origin/view-riktning, recoil och inputtillstånd. Observerad pawn är inte automatiskt lokalt styrbar pawn.
- `WeaponSnapshot`: validerad klass/normaliserad profilnyckel, ammo, scoped/mode, tillgänglig inaccuracy/spread. Fire-ready/reload/attackintervall är separata capabilities tills de faktiskt finns.
- `ProjectionSnapshot`: kopierad matris, giltighet och viewportkontrakt. World→clip/NDC och viewportkontroll görs i en separat ren funktion; `onScreen()` från baslinjen räcker inte.

Varje avancerat fält har giltighet och källa/samplegeneration. `Unknown`, `Visible` och `Occluded` måste skiljas åt. Saknad velocity är inte 0, saknad armor är inte 0 och saknad inaccuracy är inte perfekt träffsäkerhet. Kapacitet kan börja på 128 spelare som en uttrycklig produktgräns, inte ett antagande om alla entiteter. Överskridning markeras och input stoppas; kontrollera gränsen i privat testmiljö. Träffboxpunkter får en separat liten, verifierad maxkapacitet.

Reuse: EntitySystem för enumeration/handtag, PlayerPawn/BaseEntity för liv/lag/position, WeaponServices för aktivt vapen, BaseWeapon för tillgänglig precision och projektionstyper för rendering. Flytta inte visuals till snapshots i första implementationen. Lägg till en valfri snapshot-observer i befintlig entitetsloop eller ett litet collector-anrop, med avslagen funktion som trivial snabbväg.

## Insamling, tid och cache

1. Efter originalets render-start väljs en settingsrevision för hela uppdateringen. Lokal pawn och obligatoriska capabilities kontrolleras.
2. Töm byggaren. Befintlig entitetsloop får fortsätta köra visuals i samma ordning; collector kopierar endast relevanta spelarfält efter klasskontroll.
3. Slutför snapshot atomiskt ur konsumentens perspektiv i samma verifierade exekveringskontext. Publicera inga halvfyllda data.
4. Kör rena featureberäkningar utan spelfunktionsanrop. InputCoordinator skapar högst en rörelseintention och en klickintention per ny samplegeneration.
5. GUI/config-ändringar får nästa revision och träder i kraft som en sammanhållen uppdatering. De får inte ändra halva pågående beräkningen.

Render-start ger renderfrekvens, ingen garanterad server-/simfrekvens. Instrumentera callback-tråd-ID, curtime/frametime, observerade uppdateringar och framekostnad i privat match. Bensystem och tracing måste anropas i en separat verifierad säker kontext; flytta inte sådana anrop till render-/workertrådar på chans. Om färsk data inte kan samlas där måste förstudien välja lämplig game-callback innan produktionskoppling.

Använd monoton klocka för reaktionsfördröjning, stale-timeout och transportlatens; speltid kan pausas eller gå bakåt. En ny rendertidsstämpel bevisar inte en ny simulationssample. Tappa därför readiness vid pausad/fastnad speltid, sessionsbyte eller osäker sampleproveniens. Värden för maxålder bestäms efter mätning; första prototypförslag är 50 ms för både data och inputtillstånd, vilket innebär att låg uppdateringsfrekvens kan stoppa input.

Cachning: kopiera värden per sample, nyckla varaktigt featuretillstånd med EntityKey, återuppslå handtag vid insamling. Rensa vid respawn/ny pawn, lag-/vapenbyte där tillämpligt, disconnect, ändrad map/session, ogiltig lokal spelare och unload. Viewport/fokus/kalibrering får egna revisionsnummer. Vapenklass/normaliserat namn kan cachelagras inom sessionen efter validering; inga namnpekare får leva längre än uppslaget.

## Aimbot som separat tillståndsmaskin

Kontrakt: snapshot + AimSettings + ActivationState + tidssteg → `AimDecision` med diagnostik och optional önskad vinkelförändring. Den rena algoritmen anropar varken Win32 eller GameClient. Settings och beroenden finns i [FEATURES.md](FEATURES.md).

- **Eligibility:** verifierat levande lokal pawn och mål, känd lagpolicy, inte lokal spelare, ingen immunity, validerad målpunkt, fri sikt enligt aktiv policy och färska data. Okänt betyder inget mål. Filtrera före poängsättning.
- **FOV:** använd vinkelavstånd mot verifierad siktesriktning, definierat som konens halvvinkel i grader. Skärmpixelradie får inte presenteras som samma mått. Viewmodel-FOV ska inte användas för detta.
- **Poängsättning:** närmast siktesriktningen som default; alternativ avstånd och lägst health endast om dessa data är tillgängliga. Stabil tie-break på hela EntityKey ger reproducerbara resultat.
- **Hitboxprioritet:** ordnad lista med validerade hitbox-ID:n. Ingen antagen benindexkonstant, huvudhöjdsoffset eller world-origin som låtsashitbox. Rekommendation är ingen output förrän minst en riktig målpunkt verifierats.
- **Låsning/byte:** Idle → CandidateDelay → Tracking. Förlorad giltighet avbryter; positiv hysteres och minsta förbättring för byte undviker fladder. Ett dolt/ogiltigt låst mål producerar ingen output under eventuell återfångsttid.
- **Reaktion:** tidsdeadline utan sleep, omstart vid nytt mål eller förlorad aktivering. Separat målbytardelay; ingen fördröjning gäller genom bortfall av data.
- **Smoothing:** en direkt begränsad hastighetsmodell och en exponentiell modell med tidskonstant. Båda ska vara tidsstegsberoende i sekunder, med x/y-gain och maxhastighet/-steg. Korta mikrosteg summeras först efter godkänd outputkvittens.
- **Recoil:** separat valbar komponent, default av. Kräver verifierad recoil/punch, skottillstånd och kontrakt som förhindrar dubbel kompensation om view-riktningen redan innehåller recoil.
- **Prediktion:** senare capability, default av. Kräver velocity, sampleålder och rörelsemodell. För CS2-hitscan ska ingen påhittad projektilhastighet införas. Ingen garanti för serverns lagkompensation/interpolation.
- **Aktivering:** av/hold/toggle med bindning, default av och obunden. Fokus-/sessionsbortfall återställer toggle till av. Osäkert UI/chat/inputcapture stoppar beräkningen.

Om obligatorisk kameradata saknas är kärnan bara testbar med syntetiska data; den får inte aktiveras i spelet. Screen-space-visning kan utvecklas oberoende men ersätter inte vinkelkontraktet.

## Triggerbot och delning utan hård koppling

Kontrakt: samma snapshot + egna TriggerSettings + egen ActivationState → `TriggerDecision`. Trigger läser aldrig AimControllers låsta mål. De delar datatyper, geometrifunktioner, eligibility och profilupplösning via uttryckliga argument.

Tillstånd: Idle → CandidateDelay → Ready → AwaitShotAck → Cooldown. Det aktuella verifierade siktets ray testas mot tillåtna hitboxer. Synlighet, lag, ammo, fire-ready, precision och scoped-only kontrolleras om varje uppdatering och igen omedelbart före utsänd klickintention. Crosshairnärhet i pixlar är inte träff med en ray.

Fördröjningsintervall samplas en gång per ny kandidat med injicerbar reproducerbar RNG; slumpen är en funktionell tidsinställning, ingen anticheatmekanism. Byte av mål, vapen, session eller aktivering avbryter väntande skott. Tider väntas ut i uppdateringar, aldrig med sleep i en hook. Scoped-only med okänt scoped-värde betyder inget skott.

`bulletInaccuracy()` är en summa och kan användas först efter enhets-/giltighetsverifiering som en enkel tröskel. Riktig träffchans kräver verifierad spridningsfördelning, träffboxgeometri och vapentillstånd. En deterministisk sampler kan senare returnera sannolikhetsestimat med angivet antal sampel, inte ett påstått exakt värde. Visa inte ett fungerande "hit chance %"-reglage förrän kontrakt och tester finns.

Burst räknar endast kvitterade syntetiska klick, inte bekräftade skott i spelet. Semiautomatiskt, automatiskt och burst-vapen behöver separat beteende och verifierade skottintervall. Börja med klickpar down/up; håll inte knappen genom flera frames i första versionen. Om fire-ready saknas stoppas skottfunktionen i stället för att samma delay används som bevis att vapnet kan skjuta.

## InputCoordinator och kalibrering

InputCoordinator är ensam producent av inputintentioner. Den kombinerar rörelse och klick utan att features ropar på varandra. Master enable, färsk helperstatus, settingsrevision, fokus, lokalt liv, inputcapture och alla nödvändiga capabilities bildar en gemensam gate. Allt avaktiveras vid protokollfel eller förlorad kalibrering.

Aim-beslut omvandlas från grader till relativa Win32-rörelsesteg med separat x/y-kalibrering. Spara subheltalsrest per generation. Vid förkastad rörelse, tappad transport eller ny kalibrering återställs restvärden; ack anger vad som faktiskt skickades till Windows. Dagens kod ger varken verifierad sensitivity eller graden-per-steg-faktor.

Föreslagen ordning: registrera och verifiera sensitivity/yaw/pitch/zoom-cvars via befintlig cvarläsare om möjligt; annars manuell effektiv kalibrering i privat testmiljö. Manuell profil lagrar båda axlarnas observerade grader per injicerat steg och mätförutsättningar. DPI ensamt eller en sensitivity-siffra räcker inte. Bekräfta tecken, scoped/unscoped och olika rörelsestorlekar. En modell som inte passar mätningarna lämnas ogiltig och input av.

Windows dokumenterar att relativa MOUSEINPUT-rörelser påverkas av pekarhastighet och acceleration; hur CS2 konsumerar just den genererade inputen måste mätas. Ändra inte användarens globala musinställningar automatiskt. Kalibrering blir ogiltig vid ändrad sensitivity, zoommodell eller relevanta OS-inställningar. [MOUSEINPUT](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-mouseinput)

Om båda features körs är klickets förutsättning den **observerade** rayen i snapshoten. Ett aimsteg och ett klick i samma paket får inte innebära antagandet att spelet redan har bearbetat rörelsen. Vid rörelse som påverkar skottvillkoret väntar trigger på nästa giltiga observation; enklaste första policy är inga triggerklick under en rörelseframe.

## Windows-process, IPC och felsituationer

**Rekommendation:** en separat EXE med vanlig Win32-input och en lokal namngiven pipe med overlapped I/O. Första prototypen kör mot ett eget mottagarfönster utan CS2. Behåll data och featureberäkningar i DLL:en; skicka små tidsbegränsade intentioner och status, inte stora spelarsnapshots. Nuvarande `PortableExecutable::getExport()` avvisar forwarded exports; DLL-transporten behöver därför en separat verifierad API-upplösningslösning innan nya Win32-anrop kan användas med bibehållet importkrav.

En pipeklient är normalt blockerande utan explicit overlapped-läge. DLL-vägen får aldrig använda väntande exempelimplementationer, `WaitNamedPipe`, blockerande reads eller reconnect-loopar i callbacken. [Microsofts pipeklientdokumentation](https://learn.microsoft.com/en-us/windows/win32/ipc/named-pipe-client)

Alternativet shared memory kan minska kopiering men tillför publicerings-/atomik-/livslängdsproblem och är omotiverat för dessa små meddelanden innan mätningar visar ett problem. Ingen naiv seqlock över icke-atomära payloadfält: det löser inte automatiskt C++-dataracefrågor. UDP/sockets och en tredje parts RPC-/JSON-stack föreslås inte.

| Meddelande | Minsta innehåll | Regel |
|---|---|---|
| Hello/HelloAck | magic, protokoll-major/minor, längd, sessionnonce, processidentitet/startgeneration, tidsbas/frekvens, capabilities | Fel version/storlek/klient ger avvisning. Inga anslutningar över nätverk |
| Settings/SettingsAck | Konfigurationsrevision, bindningar/activation och kalibreringsrevision | Inga handlingar förrän båda sidor använder samma revision |
| InputStatus | Sekvens, samplings-/utgångstid, foreground-PID, hållna bindningar, toggle-/armstatus, fysiska musknappar | Gammal status avväpnar; ny anslutning kräver ny aktivering |
| Intent | Unikt seq/action-ID, session, snapshot-ID/tid, deadline, revisioner, relativa dx/dy och optional ett klickpar | Ingen råpekare, fri kommandosträng eller obegränsad rörelse/klickmängd |
| Ack/Error | Senast behandlade sekvens, antal insatta Windows-events, dropped/expired/blocked, felkod där tillgänglig | Kvittens betyder Windows-event, inte spelvinkel eller avlossat skott |
| Stop/Disarm | Session och ny generation | Prioriteras lokalt; helperns lease fungerar även om Stop aldrig kommer fram |

Välj och dokumentera fasta bredder, little-endian, maxpayload och explicita kodningsrutiner; skicka inte `sizeof(struct)` med okänd padding. Prototypförslag: högst 512 byte för en intention/status. Versioner, längder och matematiska gränser valideras före tolkning. Lokala ACL:er begränsar aktuell användare/session; verifiera ansluten processidentitet och hantera namnkollision utan att automatiskt lita på första pipe-servern. Detta är vanlig processisolering, ingen tillitsgaranti mot andra processer med samma användarbehörighet.

**Ägarskap och belastning:** högst en pågående read och en write med eget OVERLAPPED/event och oförändrad buffert tills I/O är avslutad. Pollning av completion är icke-blockerande. Transporten köar inte historiska rörelser; vid upptagen write kastas den aktuella intentionen och nästa beräknas från ny data. Klick omsänds aldrig automatiskt efter oklar kvittens. Throttla anslutningsförsök, högst ett per vald återförsökstid.

**Helper:** huvudtråden kan köra en begränsad event-/timerloop utan extra workertrådar. Den provtar knappar och foreground, upprätthåller lease och validerar deadline även om DLL:en stannar. Ingen output utan aktuell användaraktivering och rätt foreground-process. DLL:en måste dessutom leverera verifierat meny/chat-/speltillstånd; foreground ensamt räcker inte. Saknas det kontraktet förblir live-input blockerad.

**SendInput:** kontrollera antal insatta events. Noll eller delvis insättning avväpnar, loggas och ger ingen automatisk rörelse-/klickomsändning. UIPI tillåter bara lika eller lägre integritetsnivå och API:t pekar inte säkert ut UIPI som felorsak. Hjälpprocessen ska inte automatiskt begära administratörsrättigheter som lösning. [SendInput](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput)

**Knappägande:** skicka helst down/up i samma batch. Håll aldrig syntetisk knapp genom avaktivering. Vid ofullständigt klickpar gör en begränsad best-effort up-städning endast för input processen själv kan ha skapat. Skapa inte nya klick när fysisk vänsterknapp redan är nere. Windows logiska knappstatus är inte ett perfekt separat ägarsystem för fysisk och syntetisk input; detta måste verifieras i mottagarprovet. En hårt terminerad helper kan inte garantera egen cleanup, vilket är ytterligare skäl att börja med klickpar.

**Felpolicy:** disconnect, timeout, stale snapshot, focus loss, dead local, session-/settingsbyte och protokollfel → avväpna, töm avsikter och nollställ restvärden. Nya anslutningar får ny nonce/generation och kräver ny aktivering; tidigare köat input återspelas aldrig. Paus/focus loss återställer toggle till av. Saknad helper lämnar befintliga visuals i funktion.

**Unload:** gå till Quiescing, stoppa nya beslut, skicka Stop om möjligt, begär I/O-cancel och fortsätt observera completion över senare frames utan blockerande wait. Först när inga callbacks eller I/O-operationer längre kan använda tillståndet får hooks återställas och GlobalContext förstöras. Avsaknad av generell callback-barriär i baslinjen måste lösas före live-IPC. Stäng inte en transport och frigör OVERLAPPED-buffertar medan OS fortfarande kan skriva i dem. Helperns korta lease stoppar input även om renderflödet aldrig återkommer; fysisk DLL-unmapping är ett separat ännu obevisat livscykelkrav.

**Mätning:** sätt ingen hård realtidsgaranti. Mät sample→beslut→pipe→SendInput samt statusålder, tappade/utgångna paket och fönstrets mottagna events. Första prototypmål: p95 högst 5 ms för broker/IPC utöver väntan på ny speldata och 50 ms lease/maxålder, under dokumenterad normalbelastning. Detta är föreslagna acceptansmål, inte uppmätta egenskaper. Vid överbelastning ska output hellre utebli än levereras sent.

## Konfiguration som växer utan formatbyte i onödan

1. **Först säkert befintligt format:** korrekt uint64-kontroll före operationer, fullständighets-/EOF-status och transaktionell laddning. Behåll gamla nycklar och giltiga gamla filer. Skilj Invalid, TooLarge, IoError och UnsupportedVersion från lyckad tom/default-laddning.
2. **Staging:** validera hela filen mot ett separat värdetillstånd utan change handlers, autosave eller GUI-effekter; commit applicerar skillnader och kör handlers en gång. För ogiltig fil bevaras nuvarande tillstånd och diskfil, inklusive om flera tidigare fält var giltiga.
3. **Storleksgräns:** behåll 4096 tills tester för N−1/N/N+1 och misslyckad writer/I/O finns. Därefter föreslås högst 64 KiB per aktiv profilfil, med N+1-avkänning eller separat storleksfråga. Kapacitet och fullständighet ska kontrolleras i Release före parse/rename. Mät värsta serialiserade storlek med samtliga overrides.
4. **Minnesbudget:** filbufferten är redan separat statisk lagring, inte en del av 1 MB-poolen. En större buffert och staging ska ha explicit bytebudget och leva utanför hookens stack. Ändra inte poolkapaciteten automatiskt; följ även UI:s poolförbrukning.
5. **Numerik:** lägg till 4-bytebucket endast när behövd. Använd skalade osignerade heltal för FOV (0,01°), tid (ms), gain/procent och kalibrering där det är lämpligt. Konvertera till float endast i beräkningar. Signerade offsetvärden kräver egen validerad signed-codec om en implementerad funktion behöver dem; rå float-JSON/NaN införs inte som första steg.
6. **Validering:** gemensamma typade metadataspecifikationer för default/min/max/enums/enheter och beskrivningar. Kontrollera korsfält, exempelvis delayMin ≤ delayMax och giltiga hitboxmasker. Avvisa strukturellt fel; dokumenterat clamp för begränsade numeriska inställningar. Assertions ersätter inte runtimekontroller.
7. **Profiler:** upplösning global default → featuredefault → vapengrupp → specifikt validerat vapen-ID. Varje override har en separat närvaroflagga så att 0/off är meningsfullt. Fasta, dokumenterade kapaciteter, förslagsvis 64 vapenposter. Unknown weapon använder säker featuredefault utan automatisk aktivering. Profilnycklar är applikations-ID:n, inte lokaliseringstext eller oägda strängpekare.
8. **Presets:** flera namngivna `.cfg`-filer, en aktiv i minnet; inte alla presetdata i samma 4096-bytefil. Begränsa namn/längder, inga path separators, skydda gamla filer vid fel och avaktivera input under profilbyte. Lägg till explicit formatversion först med definierad legacy-import: avsaknad av version betyder legacy, inte fel. Okänd nyare majorversion får inte skrivas över med ett äldre schema.
9. **Sparning:** serialisera komplett innan I/O. Behåll `.new`-mönstret, men returnera/visa write-/renamefel, behåll dirty-state vid fel och inför debounce, exempelvis 500 ms efter senaste ändring. Om senare I/O flyttas ut ur DLL:en måste configägarskap, kvittenser och fungerande fristående visuals lösas först; det ingår inte automatiskt i inputbrokern.
10. **Bakåtkompatibilitet:** behåll v1–v9-fixturer oförändrade; läs giltiga saknade fält med säkra defaults. Vid schematillägg uppdateras endast current-fixturen och dess förväntningar. Okända nycklar behöver antingen begränsad korrekt skip med djup-/längdgräns eller tydlig avvisning; aldrig delvis publicerade värden.

Grundfunktionerna ska vara default av/obundna. Återställ defaults ska gå genom samma validering och handlerflöde och behålla befintlig användarbekräftelse. Presets som heter "precision" eller liknande får inte innehålla inställningar till oimplementerade funktioner.

## Panorama-utökning

Behåll Combat som huvudingång. Lägg till underflikar för Aim, Trigger och gemensam Input/kalibrering först när respektive modul är funktionell. Avancerade grupper kan döljas bakom expanderbara paneler. Visa enheter, inherited/override, bindning och orsaken till att en implementerad funktion för närvarande är otillgänglig.

Dropdowns följer CombatTab → GuiEntryPoints → typad handler → Config. Numeriska sliders behöver parameteriserad sektion och skala i CreateGUI.js, bredare IntSlider-gränssnitt och central validering i SetCommandHandler; nuvarande `visuals`/uint8/Math.floor är inte generiska. Undvik att skicka värden genom eval/byggda skript. Återläs validerat värde till slider/textfält efter inmatning och profilbyte.

Bevara råsträngsuppdelningarna; nya längre sektioner får nya C++-literalblock innan MSVC-gränsen nås. Testa menyinit, settings-sync, saknade paneler, återinit och unload. Håll i första hand callbackregistrering och UI-ägarskap i samma verifierade trådkontext som idag. Inga låtsasreglage: ej implementerad avancerad funktion har ingen redigerbar kontroll.

## Begränsningsbeslut och verifieringsportar

| Begränsning | DLL | Ny hjälpprocess/tester |
|---|---|---|
| CRT | Behåll ingen CRT i Release | Normal CRT tillåts uttryckligen i separat mål |
| Heap | Behåll egen begränsad pool; ingen ny generell heap | Begränsade allokeringar vid start/config tillåts; ingen obegränsad kö |
| Trådar | Skapa inga nya trådar | Börja med EXE:ns huvudloop; extra tråd först om mätning motiverar |
| Undantag | Behåll av; returnera status | Föreslå även status i protokoll/input; bibliotekskrav hanteras i EXE-gränsen |
| Statiska importer | Behåll av; verifiera dynamisk exportupplösning inklusive forwarded exports | Vanliga dokumenterade Win32-importer tillåts |
| Beroenden | Ingen generell ny produktdependency | Win32 och standardbibliotek; befintlig GoogleTest bara för test |

Ingen live-input före: giltig datakälla och samplekontext, verifierad visibility/hitbox/kamera, fungerande inputcapture-gate, kalibrering, broker-watchdog och unload-/I/O-livslängdstester. Förstudier får sluta med "saknas/ej verifierat"; så länge lämnas beroende funktion otillgänglig. Följ den stegvisa ordningen i [PLAN.md](PLAN.md).

