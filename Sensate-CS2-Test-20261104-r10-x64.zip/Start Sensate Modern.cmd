@echo off
start "" "%~dp0OsirisMenu.exe" --modern
