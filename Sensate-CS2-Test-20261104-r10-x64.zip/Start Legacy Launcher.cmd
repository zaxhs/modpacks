@echo off
start "" "%~dp0OsirisLauncher.exe" --legacy
