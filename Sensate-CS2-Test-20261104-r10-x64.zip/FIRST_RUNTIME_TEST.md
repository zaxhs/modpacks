# Sensate r10 — börja här (äldre avsnitt är historik)

1. Packa upp hela r10 i en separat mapp. Behåll befintliga konfigurationer. Avsluta tidigare meny/launcher. Starta Sensate.cmd eller OsirisLauncher.exe: ett gemensamt fönster ska visas, även utan CS2. Laddning startar endast via Home > Load Sensate och befintlig bekräftelse.
2. Insert visar/döljer. Klickar du tillbaka till spelet får menyn ligga bakom; Insert ska då ta fram samma fönster. Testa Alt-Tab och snabba flikbyten vid100/125/150% DPI. Inget klassiskt menyinnehåll ska blinka fram. Klassisk fallback: OsirisMenu.exe --classic; äldre launcher: OsirisLauncher.exe --legacy. Kör en UI-version i taget.
3. Starta själv en isolerad lokal CS2-session i kantlöst/fönsterläge. Stäng föregående session före byte av DLL. Load Sensate behåller paket-/processkontroller och bekräftelse. Upprepa inte ett osäkert laddningsförsök i samma process. Mapper exit0 är inte full funktionell verifiering; kontrollera färskt DLL-svar och tillgänglighet på Home.
4. Advanced finns under Diagnostics: paketkontroll, rapport, callback-observation, probe och export. Kör Aim-trial i10sekunder, öppna/dölj menyn under testet, exportera CSV. Förväntade schema-masker16383/0 är ännu inte live-verifierade. Skicka även avvikande CSV; inga saknade värden får gissas.
5. Movement-trial: hoppa själv med Space och exportera markkontakt/SDL-observation. Ingen automatisk hopp-, skott-, aim- eller rotationsinput skickas. Testernas egen tids-/sessions-/fokuslivscykel gäller även när menyn är dold.
6. Testa profilsparning/återläsning och återanslutning. Sound/Visualize Footsteps och Model Glow är fortfarande inte friskförklarade i aktuell CS2-runtime. Gör deras befintliga kontroller separat i den isolerade miljön; spara rapport/dump om ett fel återkommer.

Automatiskt verifierat:1619 CTest per Release/Debug,12 egna DX11-testbilder vid tre skalor, singleton, äldre tester och injektor144/144 per konfiguration. Inte verifierat: fysisk Insert, faktiskt flimmer/fokus över CS2, r10 live14/14, Sound/Glow eller automatisk spelinput. Inga speltester utförda av agenten.
# r9: börja här (äldre instruktioner nedan är historik)

1. Packa upp hela paketet separat. Behåll konfigurationerna. Avsluta äldre meny och starta om den isolerade lokala CS2-sessionen före en ny DLL. Följ befintlig launcherbekräftelse; upprepa inte en osäker laddning i samma process.
2. Launchern öppnar klassiska menyn. Avsluta den med Exit menu och kör Start Sensate Modern.cmd. Samma singleton används: en redan körande klassisk meny byter inte läge. Start Sensate Classic.cmd är fallback.
3. Testa Insert från skrivbord/spel, klick tillbaka, Alt-Tab och återanslutning i fönsterläge/kantlöst. Menyn ska ligga över spelet; markörlagret är click-through. Exklusiv helskärm är inte verifierad.
4. Aim > Start / stop trial. Gå till spelet inom startfristen. Öppna/dölj menyn under10sekunder; det ska inte ensamt avsluta read-only-testet. Annan app, F12, gamla data eller sessionsbyte stoppar. Export trial CSV sparar resultatet.
5. Kontrollera schema_resolved_mask=16383 och schema_rejected_type_mask=0. Om511/15872 kvarstår, skicka CSV ändå. Live-typen är ännu inte verifierad.
6. Kör Movement-test och hoppa själv med Space. Inga automatiska hopp, skott, siktrörelser eller rotationer skickas. Skicka CSV samt observerat Insert/fokus/markörbeteende.

1617 tester per Release/Debug och eget DX11-fönster verifierade. r9 i CS2, ny live14/14, Sound/Glow och verklig spelinput är INTE verifierade.
# r8 quick check (matching v5 package)

1. Close the old menu; restart your isolated local CS2 session before loading a changed DLL. Keep automation and Sound/Glow off initially. Open OsirisLauncher.exe. It should show the launcher alone. Load Osiris performs validation and the existing explicit load confirmation; never retry an uncertain attempt in the same process.
2. Before loading, Open Insert menu can be tested without CS2. Insert hides/shows it from the desktop as well as the game. Alt-Tab should preserve it. Check text at100/125/150% display scaling. Advanced diagnostics exposes counters without filling the normal view.
3. Keep the menu open before loading, optionally stage an unapplied setting. When the DLL becomes available, connection should recover without restarting or discarding that edit. Discard/Apply explicitly before a trial. A mapper exit0 alone does not prove initialized/connected/feature-ready.
4. In a windowed/borderless local bot match, Aim > Start/stop live data test. Aim between nearby bots for10s, then Save latest trial CSV. Markers are still ORIGIN points, not hitboxes. New tracking should resist small target oscillations. No aim output occurs.
5. Send the CSV. schema_resolved_mask uses bits0..13; full=16383, old nine=511. schema_rejected_type_mask15872 means all five new type checks rejected metadata. These masks provide the next exact diagnostic without exposing raw pointers. A different result must be investigated rather than assumed.

Existing Trigger/Bunnyhop/Spin trials below remain read-only. Existing Sound/Glow verification remains outstanding. Do not interpret these steps as completion of native gameplay functions.

# r7-m16: kort manuellt test (inga automatiska spelhandlingar)

Använd matchande r7 DLL/PDB/meny (protokoll v4). Stäng den äldre menyn själv. Börja i en isolerad lokal match med fyra botar och fönsterläge eller kantlöst fönster. Inga hopp, skott, siktrörelser eller rotationer skickas av denna version. Befintliga profiler startar inget automatiskt; du behöver inte ersätta din konfiguration.

1. Öppna Insert-menyn. Dashboard ska visa14/14 schemafält efter godkänd observation. Om inte: kör ett kort prov och spara CSV ändå; saknade fält blir tomma. Normala callbackkrav från r6 gäller fortfarande.
2. Välj ett av proven nedan, klicka Start och bekräfta. Stäng menyn och gå tillbaka till samma spel inom5sekunder. Provet varar högst10sekunder och visar en liten läsruta över spelet. F12 eller fokusförlust stoppar. Om rutan inte syns i exklusiv helskärm: använd kantlöst läge; CSV kan ändå sparas.
3. Gör den manuella rörelsen, öppna menyn igen och klicka **Save latest trial CSV**. Spara före nästa prov; endast senaste provet finns kvar. Ingen terminal eller debugger behövs.
4. Skicka CSV-filerna och säg om markör/ruta syntes samt vilken handling du gjorde.

**Bunnyhop:** Movement → sätt master+Bunnyhop på, Hold och en separat tangent (t.ex. Mouse4), Apply. Starta live decision trial, släpp provtangenten en gång och håll den sedan. Hoppa manuellt med Space, släpp Space i luften och landa. Rutan ska visa hoppförslag/landningar; figuren ska INTE hoppa automatiskt. CSV registrerar både Windows Space och SDL Space, markkontakt/ticks och stopporsak. Testa även att släppa provtangenten och F12. Aktiverade inställningar ensamma startar inget prov.

**Trigger:** Triggerbot → Start / stop live data test. Inga gameplayinställningar behöver aktiveras. Sikta manuellt över en fiendebot, tom mark och därefter en vägg framför boten. Rutan visar spelets ID-index och eventuellt matchande fullständigt fiendehandtag. Detta är ett identifieringstest, INTE ett besked om att ett skott skulle träffa eller få skjutas. Inget skott skickas.

**Aim:** Aimbot → Start / stop live data test. För kameran över botarnas fötter/ursprung. En markör väljer en känd levande, icke-immun fiendes ursprung nära skärmens mitt. Markören är INTE huvud/träffbox, kan sakna siktlinje och använder en fast skärmradie, inte inställningen för vinkel-FOV. Ingen siktrörelse skickas. Notera om markören ligger fel, särskilt med svarta kanter eller ändrad upplösning.

**Spin:** Movement → Start / stop observed yaw test. Vrid kameran manuellt åt båda håll och över ±180gränsen. Rutan visar observerad eye yaw och separat v_angle; CSV innehåller också kameraursprung i lokal rymd och senast observerade kommandonummer/-tick. Ingen rotation skickas och ingen av dessa observationer görs automatiskt till en kamerakontrakt-/kommandosekvens.

CSV: native_input=0 alltid. Tom cell=okänt. raw_keyboard_hint:0=inte satt,1=strängen"0",2=strängen"1",3=annat; detta är en inställningsobservation, inte bevis för vilket inputgränssnitt CS2 konsumerar. source_us/consumer_us är QPC; last_command_tick och simulation_tick är separata observationer. Identifierat handtag och projicerat origin-handtag är oberoende kolumner och kan avsiktligt skilja sig. Observerat ID/markör ger inget siktlinje-, träff- eller skottberedskapslöfte.

Sound/Model Glow ska fortfarande testas separat enligt tidigare guide nedan. Deras runtime-status uppgraderas inte av denna patch. Den äldre120-radersproben och dess export finns kvar; använd senaste trial-CSV för hela det längre provet.
# r6-m15 — live decision trial, no jump output

The three r5 CSVs now supply real movement/airborne evidence. Note that the file named stationary includes later horizontal movement; no full stationary/landing sign-off is inferred. This trial connects CURRENT DLL replies to the existing Bunnyhop engine; it must not jump automatically. Native input stays0.

1. Use matching r6 DLL/PDB/menu in your authorized isolated local bot match; close the older menu yourself first. Keep stdout capture enabled: `Start-Process -FilePath .\OsirisMenu.exe -RedirectStandardOutput .\bhop-live.log`. Prior release/config files remain preserved. Observe64 callbacks with no ownership violation as before.
2. In Dashboard enable Automation master; in Movement enable Bunnyhop, select Hold and bind a separate key (for example Mouse4), then Apply and wait for confirmation. Space/menu/emergency keys cannot be the trial activation key. Aim/trigger/spin need not be enabled. These settings alone do not arm any native input.
3. Click Start / stop live decision trial and confirm. Close the menu, enter the same source CS2 window within5s, release the activation key once, then hold it. Stand, move and manually jump/land using Space. The trial lasts at most10s; a missed250ms heartbeat ends source collection. No automatic retry/rearm.
4. Inspect `Bhop live`/`Bhop trial stopped` lines: expected state names include jump_proposal on eligible ground contact, air, repeated_observation and activation_released_or_physical_jump. Check full local session/generation/known mask, observed tick, vz, proposal/takeoff/landing counts and native_input0. Proposals are calculations, not delivered jumps. Landings should increase only after a sampled air-to-ground transition. Sampling may miss intermediate ticks; skipped_ticks/repeats are reported rather than invented frames.
5. Release activation, press F12, Alt-Tab away, alter settings or stop the trial explicitly; it should stop/reset and require a fresh explicit start. Closing/exiting the menu must not leave collection running beyond its lease when rendering next resumes. Preserve the log and exact scene/control sequence. Existing Sound/Model Glow/actual DPI checks remain separate.

This provides a real-data decision-chain test. It does NOT verify jump delivery or complete Bunnyhop. Before input can be enabled, the remaining task is to establish a window-isolated input interface actually consumed by the installed CS2 input system, verify one jump and release, and resolve peer authorization. Do not infer input readiness from proposals, WM messages, CSV replay or a successful build.
# M1.4 local-value test after the successful r4 player-count probe

Use r5-m14's matching DLL/menu (settings v3). Close the old menu yourself first; preserve your config and r4 package. Keep testing in the same authorized isolated local/bot environment. No automation input is enabled. The previous successful five-player count is already accepted evidence; the next test concerns actual scalar values and transitions.

1. Start stdout capture as before (`Start-Process -FilePath .\OsirisMenu.exe -RedirectStandardOutput .\gameplay-probe.log`). Dashboard now has separate measured rows and scrolls to preserve all diagnostics and settings. Check100/125/150percent on your actual display; owned layout tests are separate evidence.
2. Observe at least64 callbacks, overlaps0/foreign0. Request120-frame probe. Inspect the exact local handle/session/generation, ground, velocity XYZ, observed simulation tick and QPC microseconds. Unknown is not zero. The probe records every accepted collection callback, even if the menu's polling misses intermediate states.
3. After automatic return to observation, click Save retained probe as CSV. A finished1/count120 trace is complete; finished2 is explicitly stopped/partial. Retained values are history, not the now-disabled collector's current state. Capture distinct named files while standing still, moving, jumping/landing, and after a deliberate disconnect/reconnect/map transition. At high FPS120callbacks may be short: start each probe while performing the intended action. Do not assume all four states fit one probe.
4. Expected checks, not preclaimed observations: local handle corresponds to you, not a bot; session changes on invalidation; known ground is usually1 while standing and0 in air; vertical velocity should show ascent/descent then settle on landing; horizontal velocity should change with movement. Check QPC nondecreasing and calculate intervals from qpc_us, not assumed tick rate. Compare repeated/advanced/rewound observed simulation ticks without treating them as a validated command sequence. Record dead/spectator conditions separately.
5. Validate no frame after invalidation presents old values as current, manual Observe/stop cancels, and end-of-probe logging reports retained count/completion. Keep CSV, stdout log, screenshot and exact release/game identity. Native input remains0. Report new crashes with exact toggle/transition and dump; no successful CSV substitutes for Sound/Model Glow post-fix runtime tests.

CSV known mask:1 local identity,2 QPC time,4 ground,8 velocity,16 observed simulation tick,32 eye angles,64 item ID,128 raw attack pair,256 alive. Empty cells mean unknown; zero with its bit present is valid. The capture timestamp is at collection start. Weapon attack ticks and simulation ticks are not QPC timestamps. No file operation occurs in the DLL render hook.
# M1.3-LIVE manual data probe — 2026-10-23

Use the matching r4-m13 DLL and menu (settings protocol v2). Close the old menu yourself before starting the new package; do not mix releases. Preserve your configuration. Use only an authorized isolated local/bot session, never a protected server. The agent has not run this procedure in CS2.

1. Use the existing launcher flow and distinguish successful DLL entry-point execution from functioning game hooks. Do not retry an uncertain or partially completed load in the same process.
2. On the native menu Dashboard choose Observe / stop probe. Confirm render calls advance, overlaps=0 and foreign render=0. Wait at least 64 callbacks. A missing/unsupported schema must remain unavailable, not be worked around with guessed offsets.
3. Choose Read-only 120-frame probe and confirm the local-session dialog. Rejection means lifecycle/observation/thread/violation prerequisites were not satisfied; do not weaken them. Accepted collection lasts at most120 accepted callbacks and then returns to observation. It enables no aim, trigger, jump, rotation or native input.
4. Capture schema count (expected9/9 for the inspected binary), snapshot status, players and known ground/velocity/item sample counts while the probe runs. The visible menu polls faster during the probe; after expiry collection is invalidated by the existing callback path. Zero counts in menus/dead/spectator states are not by themselves a defect. Record the scene and local-player state.
5. Repeat deliberately across menu/local-session, disconnect/reconnect and map/round transitions. Check stop cancels a running probe, counters never permit input, no ownership violations occur and shutdown is clean. Record crashes and frame-time change; a passed owned test is not a runtime sign-off.

To capture diagnostic lines, start the matching menu from PowerShell before probing (after closing any old menu):

```powershell
Start-Process -FilePath .\OsirisMenu.exe -WorkingDirectory (Get-Location).Path -RedirectStandardOutput .\gameplay-probe.log
```

Lines beginning Gameplay probe include mode, resolved fields, snapshot/sample counts, overlaps, foreign callbacks and native_input=0. Retain the package identity, log, screenshot and exact transition/toggle sequence. Absence of a line is not success. This does not verify missing camera/visibility/readiness/output contracts. Sound Visualize Footsteps and Model Glow retain their separate runtime checks below; do not infer their safety from this probe.
# Windows x64 test release r3.1 — installation and controlled verification

This is a test build. Original visuals/Panorama are preserved; the dump-backed Sound channel stride and current-client attribute signature are corrected. Offline movement modules, a separate Sound page and automatic menu startup are added. Live aim/trigger/bunnyhop/spin remain unavailable. The packaged observation DLL counts callbacks; collection and native input stay disabled.

## Prepare

Extract Osiris-CS2-Test-20261023-r3.1-x64.zip into a new directory. Preserve the previous release. Keep the DLL/PDB, executables and VC runtimes together. LICENSE and INJECTOR-LICENSE.txt cover the MIT sources; RUNTIME-NOTICE.txt covers Microsoft components. Windows supplies system/UCRT DLLs.

With CS2 closed, back up default.cfg under the actual Windows Documents known folder, OsirisCS2/configs. This tree uses Documents despite upstream documenting another location. Do not install the compatibility-test fixture: it deliberately enables features. Example profiles keep Input/Aim/Trigger/Bhop/Spin, Model Glow and all Sound effects off. Existing configs are preserved and may still enable Sound automatically: inspect Sound.Visualizations.{Footsteps,BombPlant,BombBeep,BombDefuse,WeaponScope,WeaponReload}.Enabled before loading. Opening the menu or packaging does not overwrite user configuration.

In PowerShell from the extracted directory:

    Get-Content .\HASHES.sha256 | ForEach-Object {
        $expected, $name = $_ -split '  ', 2
        $actual = (Get-FileHash -LiteralPath (Join-Path (Get-Location) $name) -Algorithm SHA256).Hash
        if ($actual -ne $expected) { throw "Hash mismatch: $name" }
    }
    .\OsirisLauncher.exe --verify-package

Hashes check integrity, not publisher authenticity. RELEASE_INFO.json identifies artifacts/source; FEATURE_STATUS.md records exact feature limits.

## Owned diagnostics, with CS2 closed

Run in PowerShell, one command at a time:

    .\OsirisLauncher.exe --self-test
    .\OsirisLauncher.exe --menu-integration-test
    .\OsirisLauncher.exe --integration-test ".\Injector-x64.exe" ".\TestPayload.dll"
    .\RegressionTests.exe
    .\OsirisMenu.exe --self-test
    .\OsirisMenu.exe --bridge-self-test
    .\OsirisInput.exe --self-test
    .\OsirisInput.exe --movement-self-test
    .\OsirisInput.exe --movement-simulate ".\profiles\safe-default.cfg"
    .\Injector-x64.exe --check ".\Osiris.dll"

The launcher integration test compares its shared CLI wrapper with direct invocation of the unchanged injector, using freshly spawned owned hosts with no flag, -insecure and -allow_third_party_software. It observes TestPayload initialization and orderly shutdown; missing-DLL cases must fail without initialization. No CS2 process is accessed. RegressionTests has 144 checks. File preflight executes no DLL code. Close any manual menu before the menu integration test: it starts, reuses and closes its own menu. Movement self-test expects five jump and 99 rotation proposals, zero native events; the safe profile remains inactive. None proves CS2 compatibility.

## Launcher and loading contract

Open OsirisLauncher.exe. Verify package reports hashes, reviewed PE compatibility and cached signature status. The launcher automatically starts or reuses the settings app, even with CS2 closed or without special game arguments. The menu is initially disconnected. Helper self-test is finite, not a live service. Running/exit status is distinct from readiness. Export report writes LocalAppData/OsirisCS2/launcher-last-report.txt. Close owned menu sends WM_CLOSE only to the child started here.

Manually establish your authorized isolated local CS2 test session. Launch flags are reported for diagnostics and are not a prerequisite imposed by the launcher. Loading uses the existing reviewed manual mapper, not LoadLibrary. The launcher never starts Steam/CS2 or maps silently. Refresh process reads PID/creation/image and launch arguments. No flag, third-party flags or unavailable command-line information do not block a validated attempt. Missing process identity, ambiguous targets, invalid files or a prior attempt still block before starting the injector. Arguments are not authoritative evidence of effective protection/server state: independently establish the local non-secured environment.

Explicit load test revalidates the unchanged process and files, asks for one local-session confirmation, records the attempt durably and starts the existing injector console. Cancel starts no injector. The Loading outcome line distinguishes a launcher block/no injector start, loading in progress, injector failure and reported entry-point completion. Exit 0 confirms the injector completed the DLL entrypoint; actual Osiris/menu/game readiness still needs runtime verification. Nonzero results preserve the injector error code and may mean partial initialization. Inspect menu/Panorama diagnostics separately. Never retry an uncertain/failed attempt in that process; close/restart CS2. The durable journal is LocalAppData/OsirisCS2/launcher-attempts.log; it fails closed on read/write/size errors. There is no general mapper unload/rollback or forced termination. Closing the launcher cannot detach mapped code. Use Osiris's orderly unload where valid, then close the game; do not reinject into that process.

[Valve Trusted Mode FAQ](https://help.steampowered.com/en/faqs/view/09A0-4879-4353-EF95) and [Osiris loading README](https://github.com/danielkrupinski/Osiris#loading--injecting-into-game-process) document the restrictions. Manual mapping/custom tooling is not evidence of being undetected. No bypass/evasion is supplied. VAC, server behavioral enforcement and Trust Factor differ; these tests establish no detection safety. No public/VAC-secured-session test is part of this release.

## Menu, configuration and callback baseline

Keep automation, Sound and Model Glow off initially. Inspect native Dashboard and Panorama Automation counters: render calls should advance; record overlaps/foreign render, errors and diagnostic mode. Opening/refreshing must not arm automation. Test staged edit → Apply → actual save status → refresh/restart, invalid/stale edits, profiles and unload/reconnect. Acceptance is not disk-save acknowledgment; an unanswered request can complete when rendering resumes.

Test physical Insert press/release/repeat, Escape/Close, Alt-Tab, fullscreen/DPI and held mouse buttons. Verify no stale clicks/stuck keys and correct focus/cursor restoration. MOD_NOREPEAT registration does not prove CS2 raw-input behavior. F12 queues global automation disable; it is not an out-of-band kill. Keep Panorama until the native replacement is verified.

Observe menu → local session → disconnect/reconnect → map/round/respawn/spectating → orderly unload. Use matching symbols and M1_2_RUNTIME_CHECKLIST.md for actual thread/original order/reentrancy/quiescence and frame/pool cost. No unit test or counter alone permits collection. The user reports visuals generally working; this exact package still needs per-feature verification.

## Sound crash retest

Visualize Footsteps crashed in the user's test. Existing Steam minidumps were located and read offline. The 17:25 dump's fault bytes match the r2 PDB/source filename read; the reader indexed 64-byte rows while the installed soundsystem uses 72. Row 1 read row 0 flags as an Sfx pointer. The corrected structure and layout-sensitive signature are backed by installed-file disassembly, an original/fixed owned crash probe and a permanent independent raw-byte regression. This establishes the stride defect, not post-fix CS2 behavior. Full Sfx/filename lifetime, concurrent mutation and render resource ownership still require runtime evidence. All six effects default off.

Inspected local Steam build: **26144732**; RELEASE_INFO.json records the module hashes. A later game update requires renewed compatibility verification. No agent game launch or injection occurred.

After establishing isolated runtime and diagnostics, verify Footsteps, Bomb Plant, Bomb Beep, Bomb Defuse, Weapon Scope and Weapon Reload separately and in combinations. Check correct icon/origin, expiry, independent disable/re-enable (especially Defuse versus Beep), loss of sound/time/reticle, map/disconnect/reconnect and shutdown. Panorama Sound status explains structural failures; structural success is not lifetime sign-off. Stop on a regression rather than repeatedly enabling a crashing effect. Capture exact package/DLL/game/module hashes, reproduction, Sound status, callback counters and a dump/stack when available. Source inspection/tests already cover the shared code; actual effects still need runtime evidence.

The obsolete client.dll signature is replaced by a unique entry fingerprint at RVA 0x16AE00. Nine call sites and the float4 copy support the expected ABI. Null/lifecycle guards remain. This is independent of the Sound channel defect. After the baseline, test Model Glow enable/disable, entity removal and scene transitions separately; actual corrected rendering/lifetime remains pending.

## Next development

R1/S1 controlled callback/Sound/Model Glow/menu verification; then M1.3-LIVE verified camera/eye/regions/visibility/weapon/readiness/clock/ground/capture sources. Authenticated gameplay transport and an isolating native output owner are separate blockers. Offline aim/trigger calculations remain intact; movement cannot run on missing facts/output. Full ambitions remain in FEATURE_STATUS.md. GPT-6.1 Sol High is suitable.

Movement settings are integrated with persistence, native/Panorama menus and the synthetic helper only. Ground, authoritative camera/timing, authenticated gameplay transport and isolated native delivery remain unavailable. Aim and trigger are still offline-tested calculations. Do not arm live collection or native input based on these simulations.
